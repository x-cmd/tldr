# minetestserver

> Αυτή η εντολή είναι ψευδώνυμο της εντολής `luanti --server`.

- Δείτε το εγχειρίδιο της αρχικής εντολής:

`tldr luanti`
