# pnmtoplainpnm

> Αυτή η εντολή είναι ψευδώνυμο της εντολής `pamtopnm -plain`.

- Δείτε το εγχειρίδιο της αρχικής εντολής:

`tldr pamtopnm`
