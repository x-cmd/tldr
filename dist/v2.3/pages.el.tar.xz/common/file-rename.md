# file-rename

> Αυτή η εντολή είναι ψευδώνυμο της εντολής `rename`.

- Δείτε το εγχειρίδιο της αρχικής εντολής:

`tldr {{[-p|--platform]}} common rename`
