# logcat

> Dump een logboek van systeemberichten, inclusief stacktraces wanneer er een fout is opgetreden, en informatieberichten die door applicaties zijn vastgelegd.
> Meer informatie: <https://developer.android.com/tools/logcat>.

- Toon systeemlogs:

`logcat`

- Schrijf systeemlogs naar een bestand ([f]):

`logcat -f {{pad/naar/bestand}}`

- Toon lijnen die overeenkomen met een `regex`:

`logcat --regex {{regex}}`

- Toon logs voor een specifieke PID:

`logcat --pid {{proces_id}}`

- Toon logs voor een proces van een specifiek pakket:

`logcat --pid $(pidof -s {{pakket}})`
