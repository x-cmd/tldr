# logname

> Toon de inlognaam van de gebruiker.
> Zie ook: `id`.
> Meer informatie: <https://www.gnu.org/software/coreutils/manual/html_node/logname-invocation.html>.

- Geef de momenteel aangemelde gebruikersnaam weer:

`logname`
