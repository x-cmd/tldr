# radare2

> Een set van reverse engineering tools.
> Meer informatie: <https://book.rada.re/first_steps/commandline_flags.html>.

- Open een bestand in schrijfmodus zonder het parsen van de bestandsformaatheaders:

`radare2 -nw {{pad/naar/binary}}`

- Debug een programma:

`radare2 -d {{pad/naar/binary}}`

- Voer een script uit voordat de interactieve CLI start:

`radare2 -i {{pad/naar/script.r2}} {{pad/naar/binary}}`

- [Interactief] Toon de helptekst voor ieder commando:

`{{radare2_commando}}?`

- [Interactief] Voer een shellcommando uit vanuit de interactieve CLI:

`!{{shell_commando}}`

- [Interactief] Dump raw bytes van het huidige block naar een bestand:

`pr >{{pad/naar/bestand.bin}}`
