# lpstat

> Bekijk de statusinformatie over printers.
> Zie ook: `lp`, `lpoptions`.
> Meer informatie: <https://manned.org/lpstat>.

- Toon alle printtaken die in de wachtrij staan:

`lpstat`

- Toon alle printers op de machine en of deze ingeschakeld zijn om te printen:

`lpstat -p`

- Toon de standaard printer:

`lpstat -d`

- Toon alle beschikbare statusinformatie:

`lpstat -t`

- Toon printtaken in de wachtrij voor een specifieke gebruiker:

`lpstat -u {{gebruiker}}`

- Toon met welke apparaten de printers verbonden zijn:

`lpstat -v`
