# age

> Een eenvoudige, moderne en veilige tool voor het versleutelen van bestanden.
> Zie ook: `age-keygen`, `age-inspect`.
> Meer informatie: <https://github.com/FiloSottile/age#usage>.

- Genereer een versleuteld bestand dat kan worden ontsleuteld met een wachtwoordzin:

`age {{[-p|--passphrase]}} {{[-o|--output]}} {{pad/naar/versleuteld_bestand}} {{pad/naar/niet-versleuteld_bestand}}`

- Versleutel een bestand met een of meer openbare sleutels die als letterlijke waarden worden ingevoerd (herhaal de `--recipient` flag om meerdere openbare sleutels op te geven):

`age {{[-r|--recipient]}} {{openbare_sleutel}} {{[-o|--output]}} {{pad/naar/versleuteld_bestand}} {{pad/naar/niet-versleuteld_bestand}}`

- Versleutel een bestand voor een of meer ontvangers van wie de openbare sleutels zijn opgegeven in een bestand (één per regel):

`age {{[-R|--recipients-file]}} {{pad/naar/ontvangers_bestand}} {{[-o|--output]}} {{pad/naar/versleuteld_bestand}} {{pad/naar/niet-versleuteld_bestand}}`

- Ontsleutel een bestand met een wachtwoordzin:

`age {{[-d|--decrypt]}} {{[-o|--output]}} {{pad/naar/ontsleuteld_bestand}} {{pad/naar/versleuteld_bestand}}`

- Ontsleutel een bestand met een privésleutelbestand:

`age {{[-d|--decrypt]}} {{[-i|--identity]}} {{pad/naar/privé_sleutel_bestand}} {{[-o|--output]}} {{pad/naar/ontsleuteld_bestand}} {{pad/naar/versleuteld_bestand}}`
