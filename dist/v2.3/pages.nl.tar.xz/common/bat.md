# bat

> Toon en voeg bestanden samen.
> Een `cat` kopie met syntax highlighting en Git integratie.
> Zie ook: `cat`.
> Meer informatie: <https://manned.org/bat>.

- Print de inhoud van een of meerdere bestanden met opmaak naar `stdout`:

`bat {{pad/naar/bestand1 pad/naar/bestand2 ...}}`

- Voeg verschillende bestanden samen in het doelbestand:

`bat {{pad/naar/bestand1 pad/naar/bestand2 ...}} >{{pad/naar/doelbestand}}`

- Verwijder decoraties en schakel paging uit:

`bat {{[-pp|--style plain --pager never]}} {{pad/naar/bestand}}`

- Highlight een specifieke regel of een reeks van regels met een andere achtergrondkleur:

`bat {{[-H|--highlight-line]}} {{10|5:10|:10|10:|10:+5}} {{pad/naar/bestand}}`

- Toon niet-printbare karakters zoals spatie, tab of regeleinde:

`bat {{[-A|--show-all]}} {{pad/naar/bestand}}`

- Verwijder alle decoraties behalve regelnummers in de uitvoer:

`bat {{[-n|--number]}} {{pad/naar/bestand}}`

- Highlight de syntax van een JSON-bestand door expliciet de taal in te stellen:

`bat {{[-l|--language]}} json {{pad/naar/bestand.json}}`

- Toon alle ondersteunde talen:

`bat {{[-L|--list-languages]}}`
