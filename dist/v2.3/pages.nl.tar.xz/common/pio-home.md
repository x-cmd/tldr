# pio home

> Lanceer de PlatformIO Home webserver.
> Meer informatie: <https://docs.platformio.org/en/latest/core/userguide/cmd_home.html>.

- Open PlatformIO Home in de standaard webbrowser:

`pio home`

- Gebruik een specifieke HTTP-poort (standaard 8008):

`pio home --port {{poort}}`

- Koppel aan een specifiek IP-adres (standaard 127.0.0.1):

`pio home --host {{ip_adres}}`

- Open niet automatisch PlatformIO Home in de standaard webbrowser:

`pio home --no-open`

- Sluit de server automatisch af na een timeout (in seconden) als er niemand verbonden is:

`pio home --shutdown-timeout {{tijd}}`

- Specificeer een unieke sessie-identificatie om PlatformIO Home geïsoleerd te houden van andere instances en beschermd tegen toegang van derde partijen:

`pio home --session-id {{sessie_id}}`
