# git cola

> Een krachtige Git GUI met een gelikte en intuïtieve gebruikersinterface.
> Meer informatie: <https://git-cola.readthedocs.io/en/latest/git-cola.html>.

- Start de GUI:

`git cola`

- Start de GUI in amend mode:

`git cola --amend`

- Vraag om een Git-repository. (Standaard de huidige map):

`git cola --prompt`

- Open de Git-repository op de genoemde plek:

`git cola {{[-r|--repo]}} {{pad/naar/git-repository}}`

- Pas het padfilter toe op de statuswidget:

`git cola {{[-s|--status-filter]}} {{filter}}`
