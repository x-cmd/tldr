# bmptopnm

> Converteer een BMP-bestand naar een PBM, PGM of PNM-afbeelding.
> Meer informatie: <https://netpbm.sourceforge.net/doc/bmptopnm.html>.

- Genereer de PBM, PGM of PNM-afbeelding als output, vanuit een Windows of OS/2 BMP-bestand als input:

`bmptopnm {{pad/naar/bestand.bmp}}`

- Rapporteer de inhoud van een BMP header naar `stderr`:

`bmptopnm {{[-verb|-verbose]}} {{pad/naar/bestand.bmp}}`

- Toon de versie:

`bmptopnm {{[-v|-version]}}`
