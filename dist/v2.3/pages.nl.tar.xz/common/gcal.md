# gcal

> Toon een kalender.
> Meer informatie: <https://www.gnu.org/software/gcal/manual/gcal.html#Invoking-Gcal>.

- Toon een kalender voor de huidige maand:

`gcal`

- Toon de kalender voor de maand februari van het jaar 2010:

`gcal 2 2010`

- Toon een kalender met weeknummers:

`gcal --with-week-number`

- Verander de startdag van de week naar de eerste dag van de week (maandag):

`gcal --starting-day=1`

- Toon de vorige, huidige en volgende maand rondom vandaag:

`gcal .`
