# 7za

> Bestandsarchiver met een hoge compressieverhouding.
> Vergelijkbaar met `7z`, behalve dat het minder bestandstypes ondersteunt, maar platformonafhankelijk is.
> Meer informatie: <https://manned.org/7za>.

- [a]rchiveer een bestand of map:

`7za a {{pad/naar/archief.7z}} {{pad/naar/bestand_of_map}}`

- Versleutel een bestaand archief (inclusief bestandsnamen):

`7za a {{pad/naar/versleuteld.7z}} -p{{wachtwoord}} -mhe={{on}} {{pad/naar/archief.7z}}`

- E[x]traheer een archief met behoud van de originele mapstructuur:

`7za x {{pad/naar/archief.7z}}`

- E[x]traheer een archief naar een specifieke map:

`7za x {{pad/naar/archief.7z}} -o{{pad/naar/uitkomst}}`

- E[x]traheer een archief naar `stdout`:

`7za x {{pad/naar/archief.7z}} -so`

- [a]rchiveer met een specifiek archieftype:

`7za a -t{{7z|bzip2|gzip|lzip|tar|...}} {{pad/naar/archief.7z}} {{pad/naar/bestand_of_map}}`

- Geef een [l]ijst met de inhoud van het archiefbestand:

`7za l {{pad/naar/archief.7z}}`

- Zet het niveau van compressie (hoger betekent meer compressie, maar langzamer):

`7za a {{pad/naar/archief.7z}} -mx={{0|1|3|5|7|9}} {{pad/naar/bestand_of_map}}`
