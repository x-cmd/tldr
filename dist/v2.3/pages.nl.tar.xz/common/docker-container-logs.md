# docker container logs

> Toon container logs.
> Meer informatie: <https://docs.docker.com/reference/cli/docker/container/logs/>.

- Toon logs van een container:

`docker {{[logs|container logs]}} {{naam|id}}`

- Toon logs en volg deze:

`docker {{[logs|container logs]}} {{naam|id}} {{[-f|--follow]}}`

- Toon de laatste 5 regels:

`docker {{[logs|container logs]}} {{naam|id}} {{[-n|--tail]}} 5`

- Toon logs en voorzie deze van timestamps:

`docker {{[logs|container logs]}} {{naam|id}} {{[-t|--timestamps]}}`

- Toon logs vanaf een bepaald tijdstip van de uitvoering van de container (bijv. 23m, 10s, 2013-01-02T13:23:37):

`docker {{[logs|container logs]}} {{naam|id}} --until {{time}}`
