# linode-cli account

> Beheer Linode accounts.
> Meer informatie: <https://techdocs.akamai.com/cloud-computing/docs/cli-commands-for-account-management>.

- Bekijk account:

`linode-cli account view`

- Bekijk accountinstellingen:

`linode-cli account settings`

- Maak een betaling:

`linode-cli account payment-create --cvv {{cvv}} --usd {{amount_in_dollars}}`

- Bekijk accountnotificaties:

`linode-cli account notifications-list`
