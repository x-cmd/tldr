# clamscan

> Een command-line virusscanner.
> Meer informatie: <https://docs.clamav.net/manual/Usage/Scanning.html#clamscan>.

- Scan een bestand op kwetsbaarheden:

`clamscan {{pad/naar/bestand}}`

- Scan alle bestanden recursief in een specifieke map:

`clamscan {{[-r|--recursive]}} {{pad/naar/map}}`

- Scan data van `stdin`:

`{{commando}} | clamscan -`

- Specificeer een virusdatabasebestand of map van bestanden:

`clamscan {{[-d|--database]}} {{pad/naar/database_bestand_of_map}}`

- Scan de huidige map en toon alleen geïnfecteerde bestanden:

`clamscan {{[-i|--infected]}}`

- Sla het scanrapport op in een logbestand:

`clamscan {{[-l|--log]}} {{pad/naar/log_bestand}}`

- Verplaats geïnfecteerde bestanden naar een specifieke map:

`clamscan --move {{pad/naar/quarantaine_map}}`

- Verwijder geïnfecteerde bestanden:

`clamscan --remove yes`
