# docker

> Beheer Docker-containers en -images.
> Sommige subcommando's zoals `container`, `image`, etc. hebben hun eigen documentatie.
> Meer informatie: <https://docs.docker.com/reference/cli/docker/>.

- Toon alle Docker-containers (actief en gestopt):

`docker {{[ps|container ls]}} {{[-a|--all]}}`

- Start een container van een image, met een aangepaste naam:

`docker {{[run|container run]}} --name {{container_naam}} {{image}}`

- Start of stop een bestaande container:

`docker container {{start|stop}} {{container_naam}}`

- Download een image uit een Docker register:

`docker {{[pull|image pull]}} {{image}}`

- Toon reeds gedownloade images:

`docker {{[images|image ls]}}`

- Open een interactieve tty met Bourne shell (`sh`) binnen een draaiende container:

`docker {{[exec|container exec]}} {{[-it|--interactive --tty]}} {{container_naam}} {{sh}}`

- Verwijder gestopte containers:

`docker {{[rm|container rm]}} {{container1 container2 ...}}`

- Toon de logs van een container en volg deze:

`docker {{[logs|container logs]}} {{[-f|--follow]}} {{container_naam}}`
