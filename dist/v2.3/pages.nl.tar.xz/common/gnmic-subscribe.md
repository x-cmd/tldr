# gnmic subscribe

> Abonneer op statusupdates van gnmic-netwerkapparaten.
> Meer informatie: <https://gnmic.openconfig.net/cmd/subscribe/>.

- Abonneer op statusupdates van een doel onder de subtree van een specifiek pad:

`gnmic {{[-a|--address]}} {{ip:poort}} {{[sub|subscribe]}} --path {{pad}}`

- Abonneer op een doel met een interval van 30 seconden (standaard is 10 seconden):

`gnmic {{[-a|--address]}} {{ip:poort}} {{[sub|subscribe]}} --path {{pad}} --sample-interval 30s`

- Abonneer op een doel met een interval en alleen op updates bij verandering:

`gnmic {{[-a|--address]}} {{ip:poort}} {{[sub|subscribe]}} --path {{pad}} --stream-mode on-change --heartbeat-interval {{1m}}`

- Abonneer op een doel voor alleen een update:

`gnmic {{[-a|--address]}} {{ip:poort}} {{[sub|subscribe]}} --path {{pad}} --mode once`

- Abonneer op een doel en specificeer de response codering (json_ietf):

`gnmic {{[-a|--address]}} {{ip:poort}} {{[sub|subscribe]}} --path {{pad}} {{[-e|--encoding]}} json_ietf`
