# rc

> Een moderne simplistische poortluisteraar en omgekeerde shell.
> Zie ook: `nc`.
> Meer informatie: <https://github.com/robiot/rustcat/wiki/Basic-Usage>.

- Start met luisteren op een specifieke poort:

`rc -lp {{poort}}`

- Start een omgekeerde shell:

`rc {{host}} {{poort}} -r {{shell}}`
