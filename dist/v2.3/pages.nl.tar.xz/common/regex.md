# regex

> Reguliere expressies (`regex`) zijn patronen die worden gebruikt om tekst te vergelijken, zoeken en manipuleren.
> Opmerking: `regex` is geen commando, maar syntax die gebruikt kan worden met andere commando's.
> Zie ook: `egrep`, `glob`.
> Meer informatie: <https://cheatography.com/davechild/cheat-sheets/regular-expressions/>.

- Zoek naar één willekeurig teken:

`.`

- Zoek naar het begin van een regel:

`^{{hallo}}`

- Zoek naar het einde van een regel:

`{{wereld}}$`

- Zoek naar nul of meer herhalende karakters:

`{{a}}*`

- Zoek naar één van de karakters in een verzameling:

`[{{abc}}]`

- Zoek naar karakters tussen bepaalde reeksen:

`[{{a-z}}][{{3-9}}]`

- Zoek naar iets anders dan het opgegeven karakter:

`[^{{a}}]`

- Zoek naar een grens om een woord:

`"\b{{tekst}}\b"`
