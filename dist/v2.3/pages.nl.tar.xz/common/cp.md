# cp

> Kopieer bestanden en mappen.
> Meer informatie: <https://www.gnu.org/software/coreutils/manual/html_node/cp-invocation.html>.

- Kopieer een bestand naar een andere locatie:

`cp {{pad/naar/bronbestand}} {{pad/naar/doelbestand}}`

- Kopieer een bestand naar een andere map, met behoud van de bestandsnaam:

`cp {{pad/naar/bronbestand}} {{pad/naar/doelmap}}`

- Kopieer de inhoud van een map recursief naar een andere locatie (als de bestemming bestaat, wordt de map erin gekopieerd):

`cp {{[-r|--recursive]}} {{pad/naar/bronmap}} {{pad/naar/doelmap}}`

- Kopieer een map recursief, in verbose modus (toont bestanden terwijl ze worden gekopieerd) en behoud rechten, tijdstempels en symlinks:

`cp {{[-vra|--verbose --recursive --archive]}} {{pad/naar/bronmap}} {{pad/naar/doelmap}}`

- Kopieer meerdere bestanden tegelijk naar een map:

`cp {{[-t|--target-directory]}} {{pad/naar/doelmap}} {{pad/naar/bestand1 pad/naar/bestand2 ...}}`

- Kopieer alle bestanden met een specifieke extensie naar een andere locatie, in interactieve modus (vraagt de gebruiker om bevestiging voordat overschrijven plaatsvindt):

`cp {{[-i|--interactive]}} {{*.ext}} {{pad/naar/doelmap}}`

- Volg symbolische links voordat je kopieert:

`cp {{[-L|--dereference]}} {{link}} {{pad/naar/doelmap}}`

- Gebruik het volledige pad van bronbestanden, maak eventuele missende tussenliggende mappen aan tijdens het kopiëren:

`cp --parents {{bron/pad/naar/bestand}} {{pad/naar/doelbestand}}`
