# luanti

> Sandbox-game met blokken en een oneindige wereld.
> Meer informatie: <https://manned.org/luanti>.

- Start Luanti in clientmodus:

`luanti`

- Toon gedownloade gamemodussen:

`luanti --gameid list`

- Start Luanti in servermodus door een specifieke gamemodus te hosten:

`luanti --server --gameid {{game_id}}`

- Start een server met de standaard wereld zodra deze is aangemaakt:

`luanti --server`

- Start een server met een specifieke wereld:

`luanti --server --world {{wereld_naam}}`

- Start een server op een specifieke poort:

`luanti --server --port {{poort}}`

- Schrijf logs naar een specifiek bestand:

`luanti --logfile {{pad/naar/bestand}}`

- Schrijf alleen fouten naar de console:

`luanti --quiet`
