# uv

> Een snelle Python pakket- en projectbeheerder.
> Sommige subcommando's zoals `tool`, `python`, etc. hebben hun eigen documentatie.
> Meer informatie: <https://docs.astral.sh/uv/reference/cli/>.

- Creëer een nieuw Python project in de huidige map:

`uv init`

- Creëer een nieuw Python project in het opgegeven pad:

`uv init {{pad/naar/map}}`

- Voeg een nieuwe afhankelijkheid toe aan het project:

`uv add {{pakket}}`

- Verwijder een afhankelijkheid van het project:

`uv remove {{pakket}}`

- Voer een script of commando uit in de projectomgeving:

`uv run {{pad/naar/script.py|commando}}`

- Update een projectomgeving vanuit `pyproject.toml`:

`uv sync`

- Creëer een lockbestand voor de afhankelijkheden van het project:

`uv lock`

- Bouw het project in bron- en binary distributies:

`uv build`
