# mkdir

> Maak mappen aan en stel hun permissies in.
> Meer informatie: <https://www.gnu.org/software/coreutils/manual/html_node/mkdir-invocation.html>.

- Maak specifieke mappen aan:

`mkdir {{pad/naar/map1 pad/naar/map2 ...}}`

- Maak specifieke mappen en hun bovenliggende mappen aan indien nodig:

`mkdir {{[-p|--parents]}} {{pad/naar/map1 pad/naar/map2 ...}}`

- Maak mappen aan met specifieke permissies:

`mkdir {{[-m|--mode]}} {{u=rwx,g=rw,o=r}} {{pad/naar/map1 pad/naar/map2 ...}}`

- Maak meerdere geneste mappen recursief:

`mkdir {{[-p|--parents]}} {{pad/naar/{a,b}/{x,y,z}/{h,i,j}}}`
