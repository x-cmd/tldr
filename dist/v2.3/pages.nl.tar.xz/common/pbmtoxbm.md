# pbmtoxbm

> Converteer een PBM afbeelding naar een X11 of X10 bitmap.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pbmtoxbm.html>.

- Converteer een PBM afbeelding naar een X11 XBM bestand:

`pbmtoxbm {{pad/naar/invoer_bestand.pbm}} >{{pad/naar/uitvoer_bestand.xbm}}`

- Specificeer expliciet of een X11 of X10 bitmap gegenereerd moet worden:

`pbmtoxbm -{{x11|x10}} {{pad/naar/invoer_bestand.pbm}} >{{pad/naar/uitvoer_bestand.xbm}}`
