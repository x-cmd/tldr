# zsh

> Z SHell, een Bash-compatibele commandoregel-interpreteerder.
> Zie ook: `bash`, `!`, `^`.
> Meer informatie: <https://zsh.sourceforge.io/Doc/Release/Invocation.html#Invocation>.

- Start een interactieve shellsessie:

`zsh`

- Voer specifieke [c]ommando's uit:

`zsh -c "{{echo 'zsh wordt uitgevoerd'}}"`

- Voer een specifiek script uit:

`zsh {{pad/naar/script.zsh}}`

- Controleer een specifiek script op syntax fouten zonder het uit te voeren:

`zsh {{[-n|--no-exec]}} {{pad/naar/script.zsh}}`

- Voer specifieke commando's uit van `stdin`:

`{{echo "echo 'zsh wordt uitgevoerd'"}} | zsh`

- Voer een specifiek script uit en toon elke opdracht in het script voordat deze wordt uitgevoerd:

`zsh {{[-x|--xtrace]}} {{pad/naar/script.zsh}}`

- Start een interactieve shellsessie in verbose modus en toon elke opdracht voordat deze wordt uitgevoerd:

`zsh {{[-v|--verbose]}}`

- Start Zsh zonder het laden van user-level configuratie (bijv. `~/.zshrc`):

`zsh {{[-f|--no-rcs]}}`
