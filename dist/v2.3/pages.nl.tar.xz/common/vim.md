# vim

> Vim (Vi IMproved), een command-line tekstbewerker, geeft toegang tot verschillende manieren van tekstmanipulatie.
> Drukken op `<i>` in de normale modus begint de invoegmodus. `<Esc>` gaat terug naar de normale modus, wat toegang geeft tot de Vim-commando's.
> Zie ook: `vimdiff`, `vimtutor`, `nvim`, `gvim`.
> Meer informatie: <https://www.vim.org/>.

- Open een bestand:

`vim {{pad/naar/bestand}}`

- Open een bestand bij een bepaald regelnummer:

`vim +{{regelnummer}} {{pad/naar/bestand}}`

- Bekijk de handleiding van Vim:

`<:>help<Enter>`

- Sla de huidige buffer op en sluit af:

`{{<Esc><Z><Z>|<Esc><:>x<Enter>|<Esc><:>wq<Enter>}}`

- Ga terug naar de normale modus en maak de laatste verandering ongedaan:

`<Esc><u>`

- Zoek een patroon in het bestand (druk op `<n>`/`<N>` om naar de volgende/vorige overeenkomst te gaan):

`</>{{zoek_patroon}}<Enter>`

- Voer een `regex`-substitutie uit in het hele bestand:

`<:>%s/{{regex}}/{{vervanging}}/g<Enter>`

- Geef de regelnummers weer:

`<:>set nu<Enter>`
