# pio update

> Update geïnstalleerde PlatformIO Core pakketten, ontwikkelplatformen en globale bibliotheken.
> Meer informatie: <https://docs.platformio.org/en/latest/core/userguide/cmd_update.html>.

- Voer een volledige update uit van alle pakketten, ontwikkelplatformen en globale bibliotheken:

`pio update`

- Update alleen kernpakketten (sla platformen en bibliotheken over):

`pio update --core-packages`

- Controleer op nieuwe versies van pakketten, platformen en bibliotheken, maar update ze niet:

`pio update --dry-run`
