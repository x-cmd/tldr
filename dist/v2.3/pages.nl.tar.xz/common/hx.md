# hx

> Helix, een postmoderne tekstbewerker, welke verschillende modi beschikbaar stelt voor verschillende manieren van tekstmanipulatie.
> Drukken op `<i>` begint invoegmodus. `<Esc>` begint normale modus, wat toegang geeft tot de Helix commando's.
> Meer informatie: <https://manned.org/man/debian-forky/hx>.

- Open een bestand:

`hx {{pad/naar/bestand}}`

- Open bestanden en toon ze naast elkaar:

`hx --vsplit {{pad/naar/bestand1 pad/naar/bestand2 ...}}`

- Toon de tutorial om Helix te leren (of open het binnen Helix door op `<Esc>` te drukken en `<:>tutor<Enter>` te typen):

`hx --tutor`

- Pas het Helix thema aan:

`<:>theme {{thema_naam}}`

- Sla op en sluit af:

`<:>wq<Enter>`

- Sluit geforceerd af zonder op te slaan:

`<:>q!<Enter>`

- Maak de laatste verandering ongedaan/opnieuw:

`{{<u>|<U>}}`

- Zoek een patroon in het bestand (druk op `<n>`/`<N>` om naar de volgende/vorige overeenkomst te gaan):

`</>{{zoek_patroon}}<Enter>`
