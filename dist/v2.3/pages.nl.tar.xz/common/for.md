# for

> Voer een commando meerdere keren uit.
> Meer informatie: <https://www.gnu.org/software/bash/manual/bash.html#Looping-Constructs>.

- Itereer over de commandoregelargumenten:

`for {{variabele}}; do {{echo $variabele}}; done`

- Voer de gegeven commando's uit voor elk van de opgegeven items:

`for {{variabele}} in {{item1 item2 ...}}; do {{echo "Loop wordt uitgevoerd"}}; done`

- Itereer over een gegeven reeks nummers:

`for {{variabele}} in {{{van..tot..stap}}}; do {{echo "Loop wordt uitgevoerd"}}; done`

- Itereer over een gegeven lijst van bestanden:

`for {{variabele}} in {{pad/naar/bestand1 pad/naar/bestand2 ...}}; do {{echo "Loop wordt uitgevoerd"}}; done`

- Itereer over een gegeven lijst van mappen:

`for {{variabele}} in {{pad/naar/map1/ pad/naar/map2/ ...}}; do {{echo "Loop wordt uitgevoerd"}}; done`

- Voer een gegeven commando uit in elke map:

`for {{variabele}} in */; do (cd "${{variabele}}" || continue; {{echo "Loop wordt uitgevoerd"}}) done`
