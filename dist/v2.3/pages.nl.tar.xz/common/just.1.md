# just

> Sla projectspecifieke commando's op en voer ze uit.
> Meer informatie: <https://manned.org/just>.

- Voer een recept uit dat gespecificeerd is in een justfile:

`just {{recept}}`

- Initialiseer nieuwe justfile in de beginmap van het project:

`just --init`

- Pas de justfile aan in de standaard tekstbewerker:

`just {{[-e|--edit]}}`

- Toon een lijst met beschikbare recepten in de justfile:

`just {{[-l|--list]}}`

- Toon de justfile:

`just --dump`
