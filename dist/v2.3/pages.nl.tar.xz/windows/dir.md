# dir

> Geeft de inhoud weer van een map.
> Meer informatie: <https://learn.microsoft.com/windows-server/administration/windows-commands/dir>.

- Geef de inhoud weer van de huidige map:

`dir`

- Geef de inhoud weer van een gegeven map:

`dir {{pad\naar\map}}`

- Geef de inhoud weer van de huidige map, inclusief verborgen bestanden:

`dir /a`

- Geef de inhoud weer van een gegeven map, inclusief verborgen bestanden:

`dir {{pad\naar\map}} /a`

- Toon een lijst met mappen en bestanden, zonder extra informatie:

`dir /b`

- Sorteer resultaten op datum/tijd, oudste eerst:

`dir /o:d`
