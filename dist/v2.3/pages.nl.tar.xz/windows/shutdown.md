# shutdown

> Een tool om een machine af te sluiten, te herstarten of af te melden.
> Meer informatie: <https://learn.microsoft.com/windows-server/administration/windows-commands/shutdown>.

- Sluit de huidige machine af:

`shutdown /s`

- Sluit de huidige machine geforceerd af, waarbij alle applicaties worden gesloten:

`shutdown /s /f`

- Herstart de huidige machine onmiddellijk:

`shutdown /r /t 0`

- Zet de huidige machine in slaapstand:

`shutdown /h`

- Meld de huidige machine af:

`shutdown /l`

- Zet een timer in aantal seconden voor het afsluiten van de huidige machine:

`shutdown /s /t {{8}}`

- Breek een afsluitsequentie af voordat de timer is afgelopen:

`shutdown /a`

- Sluit een machine af op afstand:

`shutdown /m {{\\hostnaam}}`
