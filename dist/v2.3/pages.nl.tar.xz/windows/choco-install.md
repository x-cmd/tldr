# choco install

> Installeer een of meerdere pakketten met Chocolatey.
> Meer informatie: <https://docs.chocolatey.org/en-us/choco/commands/install/>.

- Installeer een of meerdere pakketten:

`choco install {{pakket1 pakket2 ...}}`

- Installeer pakketten van een aangepast configuratiebestand:

`choco install {{pad\naar\pakketten_bestand.config}}`

- Installeer een specifiek `.nuspec` of `.nupkg` bestand:

`choco install {{pad\naar\bestand}}`

- Installeer een specifieke versie van een pakket:

`choco install {{pakket}} --version {{versie}}`

- Installeer geforceerd een pakket opnieuw:

`choco install {{pakket}} {{[-f|--force]}}`

- Bevestig alle prompts automatisch:

`choco install {{pakket}} {{[-y|--yes]}}`

- Specificeer een aangepaste bron om pakketten van te ontvangen:

`choco install {{pakket}} {{[-s|--source]}} {{source_url|alias}}`

- Geef een gebruikersnaam en wachtwoord voor authenticatie op:

`choco install {{pakket}} {{[-u|--user]}} {{gebruikersnaam}} {{[-p|--password]}} {{wachtwoord}}`
