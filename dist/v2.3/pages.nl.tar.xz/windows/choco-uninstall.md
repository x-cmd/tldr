# choco uninstall

> Verwijder een of meerdere pakketten met Chocolatey.
> Meer informatie: <https://docs.chocolatey.org/en-us/choco/commands/uninstall/>.

- Verwijder een of meerdere pakketten:

`choco uninstall {{pakket1 pakket2 ...}}`

- Verwijder een specifieke versie van een pakket:

`choco uninstall {{pakket}} --version {{versie}}`

- Bevestig alle prompts automatisch:

`choco uninstall {{pakket}} {{[-y|--yes]}}`

- Verwijder alle afhankelijkheden bij het verwijderen:

`choco uninstall {{pakket}} {{[-x|--remove-dependencies]}}`

- Verwijder alle pakketten:

`choco uninstall all`
