# chpass

> Gebruikersdatabase-informatie toevoegen of wijzigen, inclusief login shell en wachtwoord.
> Zie ook: `passwd`.
> Meer informatie: <https://man.netbsd.org/chpass.1>.

- Stel interactief een specifieke login shell in voor de huidige gebruiker:

`chpass`

- Stel een specifieke login [s]hell in voor de huidige gebruiker:

`chpass -s {{pad/naar/shell}}`

- Stel een login [s]hell in voor een specifieke gebruiker:

`chpass -s {{pad/naar/shell}} {{gebruikersnaam}}`

- Specificeer een gebruikersdatabasevermelding in het `passwd` bestandsformaat:

`su -c 'chpass -a {{gebruikersnaam:gecodeerd_wachtwoord:gebruiker_id:groep_id:...}} -s {{pad/naar/shell}}' {{gebruikersnaam}}`

- Pas alleen het [l]okale wachtwoordbestand aan:

`su -c 'chpass -l -s {{pad/naar/shell}}' {{gebruikersnaam}}`

- Pas geforceerd een database [y]P wachtwoord databasevermelding aan:

`su -c 'chpass -y -s {{pad/naar/shell}}' {{gebruikersnaam}}`
