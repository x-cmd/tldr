# df

> Toon een overzicht van het gebruik van het bestandssysteem op het gebied van schijfruimte.
> Meer informatie: <https://keith.github.io/xcode-man-pages/df.1.html>.

- Toon alle bestandssystemen en hun schijfgebruik (met behulp van 512-byte eenheden):

`df`

- Gebruik leesbare eenheden ([h], gebaseerd op de macht van 1024) en toon het grote totaal:

`df -h -c`

- Gebruik leesbare eenheden ([H], gebaseerd op de macht van 1000):

`df {{[-H|--si]}}`

- Toon het bestandssysteem dat het opgegeven bestand of de opgegeven map bevat:

`df {{pad/naar/bestand_of_map}}`

- Neem statistieken op over het aantal beschikbare en gebruikte [i]-knooppunten, inclusief de bestandssysteemt[Y]pes:

`df -iY`

- Gebruik [k]ibibyte-eenheden (1024 byte) voor het weergeven van de groottecijfers:

`df -k`

- Toon informatie op een draagbare wijze ([P]):

`df -P`
