# apt-get

> Hulpprogramma voor pakketbeheer van Debian en Ubuntu.
> Zoek naar pakketten met `apt-cache`.
> Het is aanbevolen om `apt` te gebruiken wanneer het interactief wordt gebruikt in Ubuntu versies 16.04 en later.
> Meer informatie: <https://manned.org/apt-get.8>.

- Werk de lijst van beschikbare pakketten en versies bij (het wordt aanbevolen dit uit te voeren voor elk ander `apt-get` commando):

`sudo apt-get update`

- Installeer specifieke pakketten of werk ze bij naar de nieuwste beschikbare versies:

`sudo apt-get install {{pakket1 pakket2 ...}}`

- Verwijder specifieke pakketten:

`sudo apt-get remove {{pakket1 pakket2 ...}}`

- Verwijder specifieke pakketten en hun configuratiebestanden:

`sudo apt-get purge {{pakket1 pakket2 ...}}`

- Upgrade alle geïnstalleerde pakketten naar hun nieuwste beschikbare versies:

`sudo apt-get upgrade`

- Schoon de lokale repository op - verwijder pakketbestanden (`.deb`) van onderbroken downloads die niet langer kunnen worden gedownload:

`sudo apt-get autoclean`

- Verwijder alle pakketten die niet meer nodig zijn:

`sudo apt-get autoremove`

- Upgrade geïnstalleerde pakketten (zoals `upgrade`), maar verwijder verouderde pakketten en installeer aanvullende pakketten om aan nieuwe dependencies te voldoen:

`sudo apt-get dist-upgrade`
