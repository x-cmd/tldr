# bspwm

> Een tegelvensterbeheerder gebaseerd op binaire ruimtepartitionering.
> Zie ook: `bspc`.
> Meer informatie: <https://github.com/baskerville/bspwm/blob/master/doc/bspwm.1.asciidoc>.

- Start `bspwm` (houd er rekening mee dat een reeds bestaande vensterbeheerder niet geopend mag zijn wanneer dit commando wordt uitgevoerd):

`bspwm -c {{pad/naar/config}}`
