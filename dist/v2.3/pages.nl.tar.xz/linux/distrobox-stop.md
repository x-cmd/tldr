# distrobox-stop

> Stop een Distrobox container.
> Zie ook: `distrobox`.
> Meer informatie: <https://distrobox.it/usage/distrobox-stop/>.

- Stop een Distrobox container:

`distrobox-stop {{container_naam}}`

- Stop een Distrobox container zonder bevestiging:

`distrobox-stop {{container_naam}} {{[-Y|--yes]}}`
