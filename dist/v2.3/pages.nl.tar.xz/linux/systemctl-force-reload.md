# systemctl force-reload

> Dit commando is een alias van `systemctl try-reload-or-restart`.

- Bekijk de documentatie van het originele commando:

`tldr systemctl try-reload-or-restart`
