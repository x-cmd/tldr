# xbps-install

> XBPS hulpprogramma om pakketten te (her)installeren en bij te werken.
> Zie ook: `xbps`.
> Meer informatie: <https://manned.org/xbps-install>.

- Installeer een nieuw pakket:

`xbps-install {{pakket}}`

- Synchroniseer en update alle pakketten:

`xbps-install {{[-Su|--sync --update]}}`
