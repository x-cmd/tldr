# nmcli

> Beheer de netwerk configuratie via NetworkManager.
> Zie ook: `nmtui`, `iw`, `iwctl`.
> Meer informatie: <https://networkmanager.pages.freedesktop.org/NetworkManager/NetworkManager/nmcli.html>.

- Bekijk de documentatie voor het beheren van netwerkinterfaces en het opzetten van nieuwe Wi-Fi-verbindingen:

`tldr nmcli device`

- Bekijk de documentatie voor het beheren van netwerkverbindingen:

`tldr nmcli connection`

- Bekijk de documentatie voor het draaien van `nmcli` als een NetworkManager secret/polkit agent:

`tldr nmcli agent`

- Bekijk de documentatie voor het beheren van algemene instellingen van NetworkManager:

`tldr nmcli general`

- Bekijk de documentatie voor NetworkManager's activiteitenmonitor:

`tldr nmcli monitor`

- Bekijk de documentatie voor de status van netwerken in/uit te schakelen en te controleren:

`tldr nmcli networking`

- Bekijk de documentatie voor het beheren van radioschakelaars:

`tldr nmcli radio`
