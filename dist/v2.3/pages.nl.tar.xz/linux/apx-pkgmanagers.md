# apx pkgmanagers

> Beheer pakketmanagers in `apx`.
> Opmerking: door gebruikers gecreëerde pakketbeheerconfiguraties worden opgeslagen in `~/.local/share/apx/pkgmanagers`.
> Meer informatie: <https://docs.vanillaos.org/docs/en/apx-manpage#pkgmanagers>.

- Maak interactief een nieuwe configuratie voor een pakketbeheer:

`apx pkgmanagers create`

- Toon alle beschikbare pakketbeheerconfiguraties:

`apx pkgmanagers list`

- Verwijder een configuratie van een pakketbeheer:

`apx pkgmanagers rm --name {{string}}`

- Geef informatie weer over een specifieke pakketbeheer:

`apx pkgmanagers show {{naam}}`
