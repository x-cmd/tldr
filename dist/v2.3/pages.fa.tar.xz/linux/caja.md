# caja

> مدیریت فایلها و پوشه ها در محیط دسکتاپ MATE.
> همچنین : `nautilus`, `dolphin`, `thunar`, `ranger`.
> اطلاعات بیشتر: <https://manned.org/caja>.

- باز کردن پوشه خانگی کاربر کنونی:

`caja`

- بازکردن پوشه های مشخص شده در پنجره جداگانه:

`caja {{path/to/directory1 path/to/directory2 ...}}`

- بازکردن پوشه های مشخص شده در تب ها:

`caja {{[-t|--tabs]}} {{path/to/directory1 path/to/directory2 ...}}`

- بازکدن یک پوشه در یک پنجره با اندازه مشخص:

`caja {{[-g|--geometry]}} {{600}}x{{400}} {{path/to/directory}}`

- بستن همه پنجره ها:

`caja {{[-q|--quit]}}`
