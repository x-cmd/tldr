# qm move-disk

> Este comando é um alias de `qm disk move`.

- Ver documentação do comando original:

`tldr qm disk`
