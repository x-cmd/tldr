# oomctl

> Przeanalizuj stan przechowywany w `systemd-oomd`.
> Więcej informacji: <https://www.freedesktop.org/software/systemd/man/latest/oomctl.html>.

- Wyświetl aktualny stan cgroups i kontekstów systemowych przechowywany przez `systemd-oomd`:

`oomctl`
