# qm move-disk

> To polecenie jest aliasem `qm disk move`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr qm disk`
