# systemd-run

> Uruchamiaj programy w przejściowych jednostkach zakresu, jednostkach usługowych lub jednostkach usługowych uruchamianych przez ścieżkę, gniazdo lub timer.
> Więcej informacji: <https://www.freedesktop.org/software/systemd/man/latest/systemd-run.html>.

- Uruchom przejściową usługę:

`sudo systemd-run {{komenda}} {{argument1 argument2 ...}}`

- Uruchom przejściową usługę pod menedżerem usług aktualnego użytkownika (bez uprawnień):

`systemd-run --user {{komenda}} {{argument1 argument2 ...}}`

- Uruchom przejściową usługę z podaną nazwą jednostki i opisem:

`sudo systemd-run {{[-u|--unit]}} {{nazwa}} --description {{string}} {{komenda}} {{argument1 argument2 ...}}`

- Uruchom przejściową usługę, która nie jest czyszczona po jej zakończeniu z podaną zmienną środowiskową:

`sudo systemd-run {{[-r|--remain-after-exit]}} --set-env={{nazwa}}={{wartość}} {{komenda}} {{argument1 argument2 ...}}`

- Uruchom przejściowy timer, który okresowo uruchamia swoją przejściową usługę (zobacz `man systemd.time`, aby zapoznać się z formatem wydarzeń kalendarza):

`sudo systemd-run --on-calendar={{wydarzenie_kalendarza}} {{komenda}} {{argument1 argument2 ...}}`

- Udostępnij terminal programowi (umożliwiając interaktywne wejście/wyjście) i zapewnij, że szczegóły wykonania pozostaną po zakończeniu programu:

`systemd-run {{[-r|--remain-after-exit]}} --pty {{komenda}}`

- Ustaw właściwości (np. CPUQuota, MemoryMax) procesu i poczekaj, aż się zakończy:

`systemd-run {{[-p|--property]}} MemoryMax={{pamięć_w_bajtach}} {{[-p|--property]}} CPUQuota={{procent_czasu_cpu}}% --wait {{komenda}}`

- Użyj programu w potoku powłoki:

`{{komenda1}} | systemd-run {{[-P|--pipe]}} {{komenda2}} | {{komenda3}}`
