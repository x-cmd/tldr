# systemctl force-reload

> To polecenie jest aliasem `systemctl try-reload-or-restart`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr systemctl try-reload-or-restart`
