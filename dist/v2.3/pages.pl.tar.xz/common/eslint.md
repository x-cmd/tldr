# eslint

> Rozszerzalne narzędzie lintowania dla JavaScript i JSX.
> Więcej informacji: <https://eslint.org/docs/latest/use/command-line-interface>.

- Stwórz plik konfiguracyjny ESlint:

`eslint --init`

- Lintuj jeden lub więcej plików:

`eslint {{ścieżka/do/pliku1.js ścieżka/do/pliku2.js ...}}`

- Napraw wykryte problemy:

`eslint --fix`

- Lintuj używając podanego pliku konfiguracyjnego:

`eslint {{[-c|--config]}} {{ścieżka/do/pliku_konfiguracyjnego}} {{ścieżka/do/pliku1.js ścieżka/do/pliku2.js}}`
