# tig

> Interfejs tekstowy dla Gita.
> Zobacz także: `gitui`, `git-gui`.
> Więcej informacji: <https://jonas.github.io/tig/doc/manual.html>.

- Pokaż listę commitów w odwrotnej kolejności chronologicznej, zaczynając od najnowszego:

`tig`

- Pokaż historię wybranej gałęzi:

`tig {{gałąź}}`

- Pokaż historię wybranych plików lub katalogów:

`tig {{ścieżka1 ścieżka2 ...}}`

- Pokaż różnice pomiędzy dwiema referencjami (np. gałęziami lub tagami):

`tig {{bazowa_ref}}..{{porównywana_ref}}`

- Wyświetl comity ze wszystkich gałęzi i stash:

`tig --all`

- Rozpocznij w widoku stash, wyświetlając wszystkie zmiany w stash:

`tig stash`
