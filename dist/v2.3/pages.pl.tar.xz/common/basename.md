# basename

> Usuwa wiodące nazwy katalogów ze ścieżki.
> Zobacz także: `dirname`.
> Więcej informacji: <https://www.gnu.org/software/coreutils/manual/html_node/basename-invocation.html>.

- Wyświetl wyłącznie nazwę pliku ze ścieżki:

`basename {{ścieżka/do/pliku}}`

- Wyświetl wyłącznie nazwę skrajnie prawego katalogu ze ścieżki:

`basename {{ścieżka/do/katalogu/}}`

- Wyświetl wyłącznie nazwę pliku ze ścieżki, z usuniętym przyrostkiem:

`basename {{ścieżka/do/pliku}} {{przyrostek}}`
