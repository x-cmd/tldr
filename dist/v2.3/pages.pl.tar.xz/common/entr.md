# entr

> Uruchom dowolną komendę, gdy zmieni się plik.
> Zobacz także: `watchexec`.
> Więcej informacji: <https://eradman.com/entrproject/>.

- Przebuduj projekt używając `make`, jeżeli zmiemi się którykolwiek z plików w podkatalogu:

`{{ag --files-with-matches}} | entr {{make}}`

- Jeżeli zmieni się którykowliek z plików źródłowych `.c` w obecnym katalogu, przebuduj i uruchom testy używając `make`:

`{{ls *.c}} | entr {{'make && make test'}}`

- Wyślij `SIGTERM` do wszystkich uruchomionych poprzednio podprocesów ruby przed wykonaniem `ruby main.rb`:

`{{ls *.rb}} | entr -r {{ruby main.rb}}`

- Uruchom komendę przekazując zmieniony plik (`/_`) jako jej argument:

`{{ls *.sql}} | entr {{psql -f}} /_`
