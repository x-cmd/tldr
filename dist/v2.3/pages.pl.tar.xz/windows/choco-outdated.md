# choco outdated

> Sprawdzenie nieaktualnych pakietów zarządzanych przez Chocolatey.
> Więcej informacji: <https://docs.chocolatey.org/en-us/choco/commands/outdated/>.

- Wyświetlanie listy nieaktualnych pakietów w formie tabeli:

`choco outdated`

- Pominięcie/ignorowanie obecnie przypiętych pakietów:

`choco outdated --ignore-pinned`

- Ustawienie określonego źródła do sprawdzenia aktualności pakietów:

`choco outdated {{[-s|--source]}} {{adres_url|alias}}`

- Podanie nazwy użytkownika i hasła do uwierzytelnienia:

`choco outdated {{[-u|--user]}} {{nazwa_użytkownika}} {{[-p|--password]}} {{hasło}}`
