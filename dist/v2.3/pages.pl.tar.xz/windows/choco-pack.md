# choco pack

> Pakowanie specyfikacji NuGet do pliku `.nupkg`.
> Więcej informacji: <https://docs.chocolatey.org/en-us/create/commands/pack/>.

- Spakuj specyfikację NuGet do pliku `.nupkg`:

`choco pack {{ścieża/do/specyfikacji}}`

- Spakuj specyfikację NuGet podajęc wersję pliku wyjściowego:

`choco pack {{ścieża/do/specyfikacji}} --version {{wersja}}`

- Spakuj specyfikację NuGet do konkretnego katalogu wyjściowego:

`choco pack {{ścieża/do/specyfikacji}} {{[--out|--output-directory]}} {{ścieżka/do/katalogu/wyjściowego}}`
