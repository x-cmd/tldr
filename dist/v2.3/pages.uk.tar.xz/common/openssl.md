# openssl

> Набір кріптографічних інструментів OpenSSL.
> Деякі підкоманди, такі як `openssl req` мають власну документацію щодо використання.
> Більше інформації: <https://docs.openssl.org/master/man1/openssl/>.

- Вивести список доступних підкоманд:

`openssl help`

- Вивести параметри для певної команди:

`openssl help {{x509}}`

- Вивести версію OpenSSL:

`openssl version`
