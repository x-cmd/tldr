# shntool split

> Ця команда є псевдонімом для `shnsplit`.

- Дивись документацію для оригінальної команди:

`tldr shnsplit`
