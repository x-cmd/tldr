# apt-key

> Утиліта керування ключами для диспетчера пакетів APT в Debian та Ubuntu.
> Примітка: `apt-key` застарілий (за винятком використання `apt-key del` у сценаріях підтримки).
> Більше інформації: <https://manned.org/apt-key>.

- Список довірених ключів:

`apt-key list`

- Додати ключ до довіреного сховища ключів:

`apt-key add {{public_key_file.asc}}`

- Видалити ключ з довіреного сховища ключів:

`apt-key del {{key_id}}`

- Додайте віддалений ключ до надійного сховища ключів:

`wget {{[-qO|--quiet --output-document]}} - {{https://host.tld/filename.key}} | apt-key add -`

- Додати ключ із сервера ключів лише з ідентифікатором ключа:

`apt-key adv --keyserver {{pgp.mit.edu}} --recv {{KEYID}}`
