# unalias

> Fjern aliaser.
> Se også: `alias`.
> Mer informasjon: <https://www.gnu.org/software/bash/manual/bash.html#index-unalias>.

- Fjern et alias:

`unalias {{alias_navn}}`

- Fjern alle aliaser:

`unalias -a`
