# ii

> यह आदेश `Invoke-Item` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr invoke-item`
