# ii

> यह आदेश `Invoke-Item` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr invoke-item`
