# SaRAcmd OutlookCalendarCheckTask

> यह आदेश `GetHelpCmd.exe -S OutlookCalendarCheckTask` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr gethelpcmd-outlookcalendarchecktask`
