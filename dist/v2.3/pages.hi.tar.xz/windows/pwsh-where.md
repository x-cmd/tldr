# pwsh where

> यह आदेश `Where-Object` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr Where-Object`
