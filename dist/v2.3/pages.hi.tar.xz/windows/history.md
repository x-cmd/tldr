# history

> यह आदेश `Get-History` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr Get-History`
