# cinst

> यह आदेश `choco install` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr choco install`
