# scoop

> स्कूप पैकेज मैनेजर।
> अधिक जानकारी: <https://github.com/ScoopInstaller/Scoop/wiki/Commands>।

- एक पैकेज स्थापित करें:

`scoop install {{पैकेज}}`

- एक पैकेज निकालें:

`scoop uninstall {{पैकेज}}`

- सभी स्थापित पैकेजों को अद्यतन करें:

`scoop update --all`

- स्थापित पैकेजों की सूची बनाएं:

`scoop list`

- किसी पैकेज के बारे में जानकारी प्रदर्शित करें:

`scoop info {{पैकेज}}`

- एक पैकेज खोजें:

`scoop search {{पैकेज}}`

- सभी पैकेजों के पुराने संस्करण हटाएँ और डाउनलोड कैश साफ़ करें:

`scoop cleanup --cache --all`
