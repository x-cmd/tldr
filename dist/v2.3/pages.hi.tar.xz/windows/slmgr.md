# slmgr

> यह आदेश `slmgr.vbs` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr slmgr.vbs`
