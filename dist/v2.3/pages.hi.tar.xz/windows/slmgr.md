# slmgr

> यह आदेश `slmgr.vbs` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr slmgr.vbs`
