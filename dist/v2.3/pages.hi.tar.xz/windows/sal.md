# sal

> यह आदेश `Set-Alias` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr set-alias`
