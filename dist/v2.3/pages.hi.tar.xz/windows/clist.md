# clist

> यह आदेश `choco list` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr choco list`
