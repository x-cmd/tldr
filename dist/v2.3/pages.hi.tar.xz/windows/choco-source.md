# choco source

> चॉकलेटी वाले पैकेजों के लिए स्रोत प्रबंधित करें।
> अधिक जानकारी: <https://docs.chocolatey.org/en-us/choco/commands/source/>।

- वर्तमान में उपलब्ध स्रोतों की सूची बनाएं:

`choco source list`

- एक नया पैकेज स्रोत जोड़ें:

`choco source add {{[-n|--name]}} {{नाम}} {{[-s|--source]}} {{यूआरएल}}`

- क्रेडेंशियल्स के साथ एक नया पैकेज स्रोत जोड़ें:

`choco source add {{[-n|--name]}} {{नाम}} {{[-s|--source]}} {{यूआरएल}} {{[-u|--user]}} {{उपयोगकर्ता_नाम}} {{[-p|--password]}} {{पासवर्ड}}`

- क्लाइंट प्रमाणपत्र के साथ एक नया पैकेज स्रोत जोड़ें:

`choco source add {{[-n|--name]}} {{नाम}} {{[-s|--source]}} {{यूआरएल}} --cert {{प्रमाणपत्र_फ़ाइल\का\पथ}}`

- पैकेज स्रोत सक्षम करें:

`choco source enable {{[-n|--name]}} {{नाम}}`

- पैकेज स्रोत को अक्षम करें:

`choco source disable {{[-n|--name]}} {{नाम}}`

- पैकेज स्रोत हटाएँ:

`choco source remove {{[-n|--name]}} {{नाम}}`
