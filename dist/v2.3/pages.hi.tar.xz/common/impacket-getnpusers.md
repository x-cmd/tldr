# impacket-GetNPUsers

> यह आदेश `GetNPUsers.py` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr GetNPUsers.py`
