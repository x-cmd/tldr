# docker rm

> यह आदेश `docker container rm` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr docker container rm`
