# unxz

> यह आदेश `xz --decompress` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr xz`
