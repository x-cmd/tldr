# bunzip2

> यह आदेश `bzip2 --decompress` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr bzip2`
