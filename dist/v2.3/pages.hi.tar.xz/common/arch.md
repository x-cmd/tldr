# arch

> यह आदेश `uname --machine` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr uname`
