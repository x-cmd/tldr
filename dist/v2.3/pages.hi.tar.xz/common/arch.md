# arch

> यह आदेश `uname --machine` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr uname`
