# docker pull

> यह आदेश `docker image pull` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr docker image pull`
