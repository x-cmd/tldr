# lzdiff

> यह आदेश `xzdiff` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr xzdiff`
