# lzdiff

> यह आदेश `xzdiff` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr xzdiff`
