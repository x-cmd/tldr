# impacket-GetUserSPNs

> यह आदेश `GetUserSPNs.py` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr GetUserSPNs.py`
