# impacket-GetUserSPNs

> यह आदेश `GetUserSPNs.py` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr GetUserSPNs.py`
