# trash-cli

> यह आदेश `trash` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr trash`
