# gh a11y

> यह आदेश `gh accessibility` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr gh accessibility`
