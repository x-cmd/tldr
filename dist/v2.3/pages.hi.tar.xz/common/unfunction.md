# unfunction

> यह आदेश `unhash -f` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr unhash`
