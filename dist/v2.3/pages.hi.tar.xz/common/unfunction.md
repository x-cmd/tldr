# unfunction

> यह आदेश `unhash -f` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr unhash`
