# docker cp

> यह आदेश `docker container cp` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr docker container cp`
