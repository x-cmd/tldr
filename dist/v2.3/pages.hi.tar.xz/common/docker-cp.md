# docker cp

> यह आदेश `docker container cp` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr docker container cp`
