# fgrep

> यह आदेश `grep --fixed-strings` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr grep`
