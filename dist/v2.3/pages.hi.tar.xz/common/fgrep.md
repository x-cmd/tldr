# fgrep

> यह आदेश `grep --fixed-strings` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr grep`
