# pushln

> यह आदेश `print -nz` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr print`
