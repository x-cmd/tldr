# llvm-objdump

> यह आदेश `objdump` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr objdump`
