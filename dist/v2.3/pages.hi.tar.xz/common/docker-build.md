# docker build

> यह आदेश `docker buildx build` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr docker buildx build`
