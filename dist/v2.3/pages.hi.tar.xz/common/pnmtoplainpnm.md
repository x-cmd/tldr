# pnmtoplainpnm

> यह आदेश `pamtopnm -plain` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr pamtopnm`
