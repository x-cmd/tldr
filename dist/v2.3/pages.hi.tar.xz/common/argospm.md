# argospm

> यह आदेश `argos-translate` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr argos-translate`
