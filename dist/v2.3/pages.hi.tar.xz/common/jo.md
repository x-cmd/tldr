# jo

> यह आदेश `autojump` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr autojump`
