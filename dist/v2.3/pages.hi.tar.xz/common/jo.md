# jo

> यह आदेश `autojump` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr autojump`
