# brew abv

> यह आदेश `brew info` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr brew info`
