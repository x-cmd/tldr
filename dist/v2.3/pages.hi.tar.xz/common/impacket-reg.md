# impacket-reg

> यह आदेश `reg.py` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr reg.py`
