# llvm-strings

> यह आदेश `strings` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr strings`
