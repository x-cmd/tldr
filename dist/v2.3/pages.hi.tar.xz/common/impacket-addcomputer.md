# impacket-addcomputer

> यह आदेश `addcomputer.py` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr addcomputer.py`
