# impacket-rpcdump

> यह आदेश `rpcdump.py` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr rpcdump.py`
