# docker-slim

> यह आदेश `slim` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr slim`
