# impacket-ping

> यह आदेश `ping.py` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr ping.py`
