# impacket-sambaPipe

> यह आदेश `sambaPipe.py` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr sambaPipe.py`
