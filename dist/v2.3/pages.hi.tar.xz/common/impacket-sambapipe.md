# impacket-sambaPipe

> यह आदेश `sambaPipe.py` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr sambaPipe.py`
