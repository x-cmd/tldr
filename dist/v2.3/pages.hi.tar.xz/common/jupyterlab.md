# jupyterlab

> यह आदेश `jupyter lab` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr jupyter lab`
