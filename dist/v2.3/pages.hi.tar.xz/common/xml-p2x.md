# xml p2x

> यह आदेश `xml depyx` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr xml depyx`
