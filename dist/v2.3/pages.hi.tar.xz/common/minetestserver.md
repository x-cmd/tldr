# minetestserver

> यह आदेश `luanti --server` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr luanti`
