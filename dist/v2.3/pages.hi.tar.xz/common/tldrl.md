# tldrl

> यह आदेश `tldr-lint` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr tldr-lint`
