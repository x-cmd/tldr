# import

> यह आदेश `magick import` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr magick import`
