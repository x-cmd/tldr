# impacket-getTGT

> यह आदेश `getTGT.py` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr getTGT.py`
