# mapfile

> यह आदेश `readarray` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr readarray`
