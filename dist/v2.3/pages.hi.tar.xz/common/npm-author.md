# npm author

> यह आदेश `npm owner` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr npm owner`
