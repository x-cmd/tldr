# pnmdepth

> यह आदेश `pamdepth` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr pamdepth`
