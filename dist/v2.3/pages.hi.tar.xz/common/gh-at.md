# gh at

> यह आदेश `gh attestation` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr gh attestation`
