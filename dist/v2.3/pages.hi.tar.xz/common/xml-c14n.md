# xml c14n

> यह आदेश `xml canonic` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr xml canonic`
