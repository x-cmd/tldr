# rgrep

> यह आदेश `grep --recursive` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr grep`
