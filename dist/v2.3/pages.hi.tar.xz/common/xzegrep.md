# xzegrep

> यह आदेश `xzgrep --extended-regexp` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr xzgrep`
