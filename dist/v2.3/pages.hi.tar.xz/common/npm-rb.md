# npm-rb

> यह आदेश `npm-rebuild` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr npm-rebuild`
