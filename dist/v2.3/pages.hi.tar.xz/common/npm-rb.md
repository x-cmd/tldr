# npm-rb

> यह आदेश `npm-rebuild` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr npm-rebuild`
