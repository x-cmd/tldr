# bun rm

> यह आदेश `bun remove` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr bun remove`
