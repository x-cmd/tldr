# rbash

> यह आदेश `bash --restricted` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr bash`
