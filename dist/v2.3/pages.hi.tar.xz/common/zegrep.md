# zegrep

> यह आदेश `zgrep --extended-regexp` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr zgrep`
