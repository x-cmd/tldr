# impacket-ticketConverter

> यह आदेश `ticketConverter.py` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr ticketConverter.py`
