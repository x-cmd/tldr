# impacket-ticketConverter

> यह आदेश `ticketConverter.py` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr ticketConverter.py`
