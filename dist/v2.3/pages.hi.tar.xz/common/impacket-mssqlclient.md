# impacket-mssqlclient

> यह आदेश `mssqlclient.py` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr mssqlclient.py`
