# impacket-mssqlclient

> यह आदेश `mssqlclient.py` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr mssqlclient.py`
