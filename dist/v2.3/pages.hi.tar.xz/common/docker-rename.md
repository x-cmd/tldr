# docker rename

> यह आदेश `docker container rename` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr docker container rename`
