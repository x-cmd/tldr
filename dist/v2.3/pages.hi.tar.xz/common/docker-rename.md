# docker rename

> यह आदेश `docker container rename` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr docker container rename`
