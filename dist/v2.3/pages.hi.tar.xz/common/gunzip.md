# gunzip

> यह आदेश `gzip --decompress` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr gzip`
