# gunzip

> यह आदेश `gzip --decompress` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr gzip`
