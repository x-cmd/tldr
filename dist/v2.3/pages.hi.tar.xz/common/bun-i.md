# bun i

> यह आदेश `bun install` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr bun install`
