# crane cp

> यह आदेश `crane copy` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr crane copy`
