# kr

> यह आदेश `kiterunner` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr kiterunner`
