# bzfgrep

> यह आदेश `bzgrep --fixed-strings` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr bzgrep`
