# ic

> यह आदेश `ibmcloud` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr ibmcloud`
