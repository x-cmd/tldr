# lzcat

> यह आदेश `xz --format lzma --decompress --stdout` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr xz`
