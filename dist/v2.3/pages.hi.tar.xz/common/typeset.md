# typeset

> यह आदेश `declare` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr declare`
