# typeset

> यह आदेश `declare` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr declare`
