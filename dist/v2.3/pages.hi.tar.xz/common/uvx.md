# uvx

> यह आदेश `uv tool run` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr uv tool`
