# docker stats

> यह आदेश `docker container stats` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr docker container stats`
