# libreoffice

> यह आदेश `soffice` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr soffice`
