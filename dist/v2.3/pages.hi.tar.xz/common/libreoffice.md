# libreoffice

> यह आदेश `soffice` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr soffice`
