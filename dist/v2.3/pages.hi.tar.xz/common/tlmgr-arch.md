# tlmgr arch

> यह आदेश `tlmgr platform` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr tlmgr platform`
