# zfgrep

> यह आदेश `zgrep --fixed-strings` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr zgrep`
