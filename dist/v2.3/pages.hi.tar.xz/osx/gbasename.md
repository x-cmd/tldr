# gbasename

> यह आदेश `basename` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr basename`
