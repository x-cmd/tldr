# gshuf

> यह आदेश `shuf` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr {{[-p|--platform]}} common shuf`
