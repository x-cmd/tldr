# gchroot

> यह आदेश `chroot` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr chroot`
