# gfactor

> यह आदेश `factor` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr factor`
