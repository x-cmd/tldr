# greadlink

> यह आदेश `readlink` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr readlink`
