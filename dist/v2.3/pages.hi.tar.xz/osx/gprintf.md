# gprintf

> यह आदेश `printf` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr printf`
