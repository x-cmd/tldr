# ghostname

> यह आदेश `hostname` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr hostname`
