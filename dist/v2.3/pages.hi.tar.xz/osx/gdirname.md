# gdirname

> यह आदेश `dirname` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr dirname`
