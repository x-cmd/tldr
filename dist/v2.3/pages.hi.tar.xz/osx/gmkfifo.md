# gmkfifo

> यह आदेश `mkfifo` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr mkfifo`
