# gexpand

> यह आदेश `expand` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr expand`
