# gstdbuf

> यह आदेश `stdbuf` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr stdbuf`
