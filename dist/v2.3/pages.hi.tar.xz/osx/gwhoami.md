# gwhoami

> यह आदेश `whoami` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr whoami`
