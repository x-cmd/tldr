# gdate

> यह आदेश `date` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr {{[-p|--platform]}} common date`
