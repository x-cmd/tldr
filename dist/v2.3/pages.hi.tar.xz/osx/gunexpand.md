# gunexpand

> यह आदेश `unexpand` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr unexpand`
