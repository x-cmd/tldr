# grealpath

> यह आदेश `realpath` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr realpath`
