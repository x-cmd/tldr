# gsplit

> यह आदेश `split` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr {{[-p|--platform]}} common split`
