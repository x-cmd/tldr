# gtraceroute

> यह आदेश `traceroute` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr traceroute`
