# gbasenc

> यह आदेश `basenc` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr basenc`
