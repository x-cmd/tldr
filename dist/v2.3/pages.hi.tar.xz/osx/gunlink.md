# gunlink

> यह आदेश `unlink` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr unlink`
