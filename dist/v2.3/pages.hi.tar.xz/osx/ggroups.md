# ggroups

> यह आदेश `groups` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr groups`
