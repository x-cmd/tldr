# nmtui-hostname

> यह आदेश `nmtui hostname` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr nmtui`
