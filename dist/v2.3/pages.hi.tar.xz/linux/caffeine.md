# caffeine

> फ़ुल-स्क्रीन मोड में डेस्कटॉप निष्क्रियता को रोकें।
> अधिक जानकारी: <https://manned.org/caffeine>।

- कैफीन सर्वर प्रारंभ करें:

`caffeine`

- मदद प्रदर्शित करें:

`caffeine {{[-h|--help]}}`

- संस्करण दिखाएं:

`caffeine {{[-V|--version]}}`
