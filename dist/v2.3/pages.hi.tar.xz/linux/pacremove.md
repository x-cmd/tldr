# pacremove

> यह आदेश `pactrans --remove` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr pactrans`
