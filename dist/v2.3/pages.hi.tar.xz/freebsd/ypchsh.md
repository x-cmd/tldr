# ypchsh

> यह आदेश `chpass` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr chpass`
