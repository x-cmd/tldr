# ypchsh

> यह आदेश `chpass` का उपनाम है।

- मूल आदेश के लिए प्रलेखन देखें:

`tldr chpass`
