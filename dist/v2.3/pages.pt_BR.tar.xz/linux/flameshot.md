# flameshot

> Função de captura da tela com uma Interface Gráfica do Usuário.
> Suporta edição básica de imagens, como texto, formas, cores e imgur.
> Mais informações: <https://flameshot.org/docs/advanced/commandline-options/>.

- Cria uma captura da tela completa:

`flameshot full`

- Cria uma captura da tela interativamente:

`flameshot gui`

- Cria uma captura da tela e salva em um caminho específico:

`flameshot gui {{[-p|--path]}} {{caminho/para/diretório}}`

- Cria uma captura da tela interativamente em um modo simplificado:

`flameshot launcher`

- Cria uma captura da tela a partir de um monitor específico:

`flameshot screen {{[-n|--number]}} {{2}}`

- Cria uma captura da tela e imprime na saída padrão:

`flameshot gui {{[-r|--raw]}}`

- Cria uma captura da tela e copia para a área de transferência:

`flameshot gui {{[-c|--clipboard]}}`

- Cria uma captura da tela com um atraso específico em milissegundos:

`flameshot full {{[-d|--delay]}} {{5000}}`
