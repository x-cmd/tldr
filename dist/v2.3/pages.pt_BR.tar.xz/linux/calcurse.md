# calcurse

> Um calendário e agenda baseados em texto para a linha de comando.
> Mais informações: <https://github.com/lfos/calcurse/blob/pu/doc/calcurse.1.txt>.

- Inicia o calcurse em modo interativo:

`calcurse`

- Mostra os agendamentos e eventos para o presente dia:

`calcurse {{[-a|--appointment]}}`

- Apaga todos os objetos gravados localmente e importa os objetos remotos:

`calcurse-caldav --init=keep-remote`

- Apaga todos os objetos remotos e envia os objetos gravados localmente:

`calcurse-caldav --init=keep-local`

- Copia os objetos gravados localmente para o servidor CalDAV e vice-versa:

`calcurse-caldav --init=two-way`
