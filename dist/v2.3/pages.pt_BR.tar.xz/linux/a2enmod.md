# a2enmod

> Ativa um módulo do Apache em sistemas operacionais baseados no Debian.
> Mais informações: <https://manned.org/a2enmod>.

- Ativa um módulo:

`sudo a2enmod {{módulo}}`

- Não mostra mensagens informativas:

`sudo a2enmod {{[-q|--quiet]}} {{module}}`
