# alien

> Converter diferentes pacotes de instalação para outros formatos.
> Veja também: `debtap`.
> Mais informações: <https://manned.org/alien>.

- Converte um arquivo de instalação específico para o formato Debian (extensão `.deb`):

`sudo alien {{[-d|--to-deb]}} {{caminho/para/arquivo}}`

- Converte um arquivo de instalação específico para o formato Red Hat (extensão `.rpm`):

`sudo alien {{[-r|--to-rpm]}} {{caminho/para/arquivo}}`

- Converte um arquivo de instalação específico para um arquivo de instalação do Slackware (extensão `.tgz`):

`sudo alien {{[-t|--to-tgz]}} {{caminho/para/arquivo}}`

- Converte um arquivo de instalação específico para o formato Debian e instala no sistema:

`sudo alien {{[-d|--to-deb]}} {{[-i|--install]}} {{caminho/para/arquivo}}`
