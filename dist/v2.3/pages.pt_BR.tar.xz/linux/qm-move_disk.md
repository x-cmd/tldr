# qm move_disk

> Este comando é um apelido de `qm disk move`.

- Veja documentação sobre o comando original:

`tldr qm disk`
