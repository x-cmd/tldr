# x11docker

> Executar aplicativos de GUI e interfaces de desktop seguramente em contêineres do Docker.
> Veja também: `xephyr`.
> Mais informações: <https://github.com/mviereck/x11docker#terminal-syntax>.

- Inicia o VLC em um contêiner:

`x11docker {{[-p|--pulseaudio]}} --share {{$HOME/Videos}} {{jess/vlc}}`

- Inicia o Xfce em uma janela:

`x11docker {{[-d|--desktop]}} {{x11docker/xfce}}`

- Inicia o GNOME em uma janela:

`x11docker {{[-d|--desktop]}} {{[-g|--gpu]}} --init={{systemd}} {{x11docker/gnome}}`

- Inicia o KDE Plasma em uma janela:

`x11docker {{[-d|--desktop]}} {{[-g|--gpu]}} --init={{systemd}} {{x11docker/kde-plasma}}`

- Mostra ajuda:

`x11docker --help`
