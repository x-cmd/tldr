# wikit

> Um programa de linha de comando para obter resumos da Wikipédia facilmente.
> Mais informações: <https://github.com/KorySchneider/wikit#usage>.

- Mostra um pequeno resumo de um tópico específico da Wikipédia:

`wikit {{tópico}}`

- Especifica uma linguagem (código de linguagem ISO 639-1):

`wikit {{tópico}} {{[-l|--lang]}} {{código_de_linguagem}}`

- Abre o artigo completo no navegador padrão:

`wikit {{tópico}} -b`

- Abre um menu de desambiguação:

`wikit {{tópico}} -d`
