# passwd

> Passwd é uma ferramenta usada para alterar a senha de um usuário.
> Veja também: `chpasswd`.
> Mais informações: <https://manned.org/passwd>.

- Altera a senha do usuário atual interativamente:

`passwd`

- Altera a senha de um usuário específico:

`passwd {{nome do usuário}}`

- Obtém o status atual do usuário:

`passwd {{[-S|--status]}}`

- Deixa a senha da conta em branco (isso definirá a conta nomeada como sem senha):

`passwd {{[-d|--delete]}}`
