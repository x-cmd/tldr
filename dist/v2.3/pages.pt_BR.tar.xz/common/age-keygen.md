# age-keygen

> Gera par de chaves `age`.
> Veja também: `age`, `age-inspect`.
> Mais informações: <https://manned.org/age-keygen>.

- Gera um par de chaves, salva em um arquivo não criptografado e imprime a chave pública para `stdout`:

`age-keygen {{[-o|--output]}} {{caminho/para/arquivo}}`

- Converte uma identidade para um destinatário e imprime a chave pública para `stdout`:

`age-keygen -y {{caminho/para/arquivo}}`
