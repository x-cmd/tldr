# clangd

> Servidor de linguagem que fornece recursos semelhantes aos de IDE aos editores.
> Deve ser usado por meio de um plugin do editor em vez de ser invocado diretamente.
> Mais informações: <https://manned.org/clangd-22>.

- Exibe as opções disponíveis:

`clangd --help`

- Lista as opções disponíveis:

`clangd --help-list`

- Exibe a versão:

`clangd --version`
