# nth

> Name That Hash - Nomeia o tipo de um hash em um instante.
> Mais informações: <https://github.com/bee-san/Name-That-Hash>.

- Nomeia o hash:

`nth {{[-t|--text]}} {{5f4dcc3b5aa765d61d8327deb882cf99}}`

- Nomeia hashes em um arquivo:

`nth {{[-f|--file]}} {{caminho/para/hashes}}`

- Saída no formato JSON:

`nth {{[-t|--text]}} {{5f4dcc3b5aa765d61d8327deb882cf99}} {{[-g|--greppable]}}`

- Decodifica o hash em Base64 e nomeia:

`nth {{[-t|--text]}} {{NWY0ZGNjM2I1YWE3NjVkNjFkODMyN2RlYjg4MmNmOTkK}} {{[-b64|--base64]}}`
