# gnurmdir

> This command is an alias of GNU `rmdir`.

- View documentation for the original command:

`tldr rmdir`
