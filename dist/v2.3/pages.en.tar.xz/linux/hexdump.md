# hexdump

> An ASCII, decimal, hexadecimal, octal dump.
> See also: `hexyl`, `od`, `xxd`.
> More information: <https://manned.org/hexdump>.

- Print the hexadecimal representation of a file, replacing duplicate lines by '*':

`hexdump {{path/to/file}}`

- Display the input offset in hexadecimal and its ASCII representation in two columns:

`hexdump {{[-C|--canonical]}} {{path/to/file}}`

- Display the hexadecimal representation of a file, but interpret only n bytes of the input:

`hexdump {{[-C|--canonical]}} {{[-n|--length]}} {{number_of_bytes}} {{path/to/file}}`

- Don't replace duplicate lines with '*':

`hexdump {{[-v|--no-squeezing]}} {{path/to/file}}`
