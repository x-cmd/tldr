# systemctl import-environment

> Import environment variables from the shell into systemd's environment.
> See also: `systemctl show-environment`, `systemctl unset-environment`.
> More information: <https://www.freedesktop.org/software/systemd/man/latest/systemctl.html#import-environment%20VARIABLE%E2%80%A6>.

- Import a variable:

`systemctl import-environment {{variable}}`

- Import multiple variables:

`systemctl import-environment {{variable_1 variable_2 ...}}`

- Import variables for user services:

`systemctl import-environment {{variable}} --user`
