# nmcli

> Manage the network configuration using NetworkManager.
> See also: `nmtui`, `iw`, `iwctl`.
> More information: <https://networkmanager.pages.freedesktop.org/NetworkManager/NetworkManager/nmcli.html>.

- View documentation for managing network interfaces and establishing new Wi-Fi connections:

`tldr nmcli device`

- View documentation for managing network connections:

`tldr nmcli connection`

- View documentation for running `nmcli` as a NetworkManager secret/polkit agent:

`tldr nmcli agent`

- View documentation for managing general settings of NetworkManager:

`tldr nmcli general`

- View documentation for NetworkManager's activity monitor:

`tldr nmcli monitor`

- View documentation for enabling/disabling and checking the status of networking:

`tldr nmcli networking`

- View documentation for managing radio switches:

`tldr nmcli radio`
