# gnuod

> This command is an alias of GNU `od`.

- View documentation for the original command:

`tldr od`
