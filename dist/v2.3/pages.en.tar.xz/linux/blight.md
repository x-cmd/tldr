# blight

> Utility for changing the display brightness.
> More information: <https://github.com/gutjuri/blight#usage>.

- Set display brightness to 50%:

`blight set {{50}} {{[-r|--relative]}}`

- Show current display brightness:

`blight show`

- Print maximum display brightness:

`blight max`

- Increase display brightness in %:

`blight inc {{number}} {{[-r|--relative]}}`

- Decrease display brightness with internal units:

`blight dec {{number}}`
