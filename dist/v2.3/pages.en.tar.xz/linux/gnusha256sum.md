# gnusha256sum

> This command is an alias of GNU `sha256sum`.

- View documentation for the original command:

`tldr sha256sum`
