# talk

> A visual communication program which copies lines from your terminal to that of another user.
> More information: <https://www.gnu.org/software/inetutils/manual/inetutils.html#talk-invocation>.

- Start a talk session with a user on the same machine:

`talk {{username}}`

- Start a talk session with a user on the same machine, who is logged in on tty3:

`talk {{username}} {{tty3}}`

- Start a talk session with a user on a remote machine:

`talk {{username}}@{{hostname}}`

- Clear text on both terminal screens:

`<Ctrl d>`

- Exit the talk session:

`<Ctrl c>`
