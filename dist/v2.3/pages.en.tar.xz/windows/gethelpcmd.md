# GetHelpCmd

> Analyze and fix common problems in Microsoft 365 Enterprise installations.
> Formerly Microsoft Support and Recovery Assistant (SaRA), command-line version (`SaRAcmd.exe`).
> Note: This command is deprecated, use the GUI troubleshooters available within Windows Settings instead. It is not related to PowerShell (`Get-Help`).
> Some subcommands such as `OutlookCalendarCheckTask`, `ExpertExperienceAdminTask`, etc. have their own usage documentation.
> More information: <https://learn.microsoft.com/troubleshoot/microsoft-365/admin/miscellaneous/get-help-command-line-overview>.

- View documentation for PowerShell's `Get-Help` command:

`tldr get-help`

- View documentation for the `ExpertExperienceAdminTask` scenario:

`tldr gethelpcmd-expertexperienceadmintask`

- View documentation for the `OutlookCalendarCheckTask` scenario:

`tldr gethelpcmd-outlookcalendarchecktask`
