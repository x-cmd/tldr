# choco outdated

> Check for outdated packages with Chocolatey.
> More information: <https://docs.chocolatey.org/en-us/choco/commands/outdated/>.

- Display a list of outdated packages in table format:

`choco outdated`

- Ignore pinned packages in the output:

`choco outdated --ignore-pinned`

- Specify a custom source to check packages from:

`choco outdated {{[-s|--source]}} {{source_url|alias}}`

- Provide a username and password for authentication:

`choco outdated {{[-u|--user]}} {{username}} {{[-p|--password]}} {{password}}`
