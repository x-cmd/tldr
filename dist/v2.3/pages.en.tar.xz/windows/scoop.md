# scoop

> The Scoop package manager.
> Some subcommands such as `bucket` have their own usage documentation.
> More information: <https://github.com/ScoopInstaller/Scoop/wiki/Commands>.

- Install a package:

`scoop install {{package}}`

- Remove a package:

`scoop uninstall {{package}}`

- Update all installed packages:

`scoop update --all`

- List installed packages:

`scoop list`

- Display information about a package:

`scoop info {{package}}`

- Search for a package:

`scoop search {{package}}`

- Remove old versions of all packages and clear the download cache:

`scoop cleanup --cache --all`
