# choco pack

> Package a NuGet specification into a `.nupkg` file.
> More information: <https://docs.chocolatey.org/en-us/create/commands/pack/>.

- Package a NuGet specification to a `.nupkg` file:

`choco pack {{path\to\specification_file}}`

- Package a NuGet specification specifying the version of the resulting file:

`choco pack {{path\to\specification_file}} --version {{version}}`

- Package a NuGet specification to a specific directory:

`choco pack {{path\to\specification_file}} {{[--out|--output-directory]}} {{path\to\output_directory}}`
