# dvdmaker

> Create and burn video DVDs.
> Note: This command is deprecated.
> More information: <https://learn.microsoft.com/previous-versions/windows/desktop/wmmdvdm/command-line-options-for-windows-dvd-maker>.

- Launch Windows DVD Maker:

`dvdmaker`

- Specify the DVD disk burner drive:

`dvdmaker -drive:{{F}}`

- Import assets predefined by a Windows DVD Maker import file list XML file:

`dvdmaker {{path\to\file.xml}}`

- Reset Windows DVD Maker configuration to factory settings (Warning: This will reset your app settings):

`dvdmaker _clear_`
