# choco install

> Install one or more packages with Chocolatey.
> More information: <https://docs.chocolatey.org/en-us/choco/commands/install/>.

- Install one or more packages:

`choco install {{package1 package2 ...}}`

- Install packages from a custom configuration file:

`choco install {{path\to\packages_file.config}}`

- Install a specific `.nuspec` or `.nupkg` file:

`choco install {{path\to\file}}`

- Install a specific version of a package:

`choco install {{package}} --version {{version}}`

- Force reinstallation of a package:

`choco install {{package}} {{[-f|--force]}}`

- Confirm all prompts automatically:

`choco install {{package}} {{[-y|--yes]}}`

- Specify a custom source to receive packages from:

`choco install {{package}} {{[-s|--source]}} {{source_url|alias}}`

- Provide a username and password for authentication:

`choco install {{package}} {{[-u|--user]}} {{username}} {{[-p|--password]}} {{password}}`
