# choco feature

> Interact with features with Chocolatey.
> More information: <https://docs.chocolatey.org/en-us/choco/commands/feature/>.

- Display a list of available features:

`choco feature list`

- Enable a feature:

`choco feature enable {{[-n|--name]}} {{name}}`

- Disable a feature:

`choco feature disable {{[-n|--name]}} {{name}}`
