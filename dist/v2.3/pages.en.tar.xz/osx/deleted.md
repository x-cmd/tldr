# deleted

> Keep track of purgeable space and ask clients to purge when space is low.
> Note: It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/deleted.8.html>.

- Start the daemon:

`deleted`
