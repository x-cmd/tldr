# quilt

> Manage a series of patches.
> More information: <https://manned.org/quilt>.

- Import an existing patch from a file:

`quilt import {{path/to/file.patch}}`

- Create a new patch:

`quilt new {{filename.patch}}`

- Add a file to the current patch:

`quilt add {{path/to/file}}`

- After editing the file, refresh the current patch with the changes:

`quilt refresh`

- Apply all the patches in the series file:

`quilt push -a`

- Remove all applied patches:

`quilt pop -a`
