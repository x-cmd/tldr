# ng analytics

> Manage Angular CLI analytics settings.
> More information: <https://angular.dev/cli/analytics>.

- Enable analytics for the current project:

`ng analytics {{[on|enable]}}`

- Enable analytics globally:

`ng analytics {{[on|enable]}} {{[-g|--global]}}`

- Disable analytics for the current project:

`ng analytics {{[off|disable]}}`

- Disable analytics globally:

`ng analytics {{[off|disable]}} {{[-g|--global]}}`

- Display the current analytics configuration and status:

`ng analytics info`

- Prompt interactively to configure analytics settings:

`ng analytics prompt`
