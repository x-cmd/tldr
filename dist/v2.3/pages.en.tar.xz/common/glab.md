# glab

> Work seamlessly with GitLab.
> Some subcommands such as `repo` have their own usage documentation.
> More information: <https://gitlab.com/gitlab-org/cli/-/tree/main/docs/source>.

- Clone a GitLab repository locally:

`glab repo clone {{owner}}/{{repository}}`

- Create a new issue:

`glab issue create`

- View and filter the open issues of the current repository:

`glab issue list`

- View an issue in the default browser:

`glab issue view {{[-w|--web]}} {{issue_number}}`

- Create a merge request:

`glab mr create`

- View a pull request in the default web browser:

`glab mr view {{[-w|--web]}} {{pr_number}}`

- Check out a specific pull request locally:

`glab {{[co|mr checkout]}} {{pr_number}}`
