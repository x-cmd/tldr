# pio update

> Update installed PlatformIO Core packages, development platforms, and global libraries.
> More information: <https://docs.platformio.org/en/latest/core/userguide/cmd_update.html>.

- Perform a full update of all packages, development platforms, and global libraries:

`pio update`

- Update core packages only (skips platforms and libraries):

`pio update --core-packages`

- Simulate an update, checking for new versions of packages, platforms, and libraries without updating them:

`pio update --dry-run`
