# pacman -D

> 이 명령은 `pacman --database`의 별칭입니다.

- 자세한 내용은 원본 명령을 참고하세요:

`tldr pacman database`
