# top

> 실행 중인 프로세스에 대한 동적 실시간 정보를 표시합니다.
> 관련 항목: `htop`, `atop`, `glances`, `btop`, `btm`.
> 더 많은 정보: <https://manned.org/top>.

- `top` 시작:

`top`

- 유휴 또는 좀비 프로세스를 표시하지 않음:

`top {{[-i|--idle-toggle]}}`

- 특정 사용자 소유의 프로세스만 표시:

`top {{[-u|--filter-only-euser]}} {{사용자명}}`

- 특정 필드로 프로세스 정렬:

`top {{[-o|--sort-override]}} {{필드_이름}}`

- 특정 프로세스의 개별 스레드 표시:

`top {{[-Hp|--threads-show --pid]}} {{프로세스_ID}}`

- 쉼표로 구분된 목록으로 전달된 특정 PID의 프로세스만 표시 (일반적으로 PID를 즉석에서 알 수 없습니다. 이 예는 프로세스 이름에서 PID를 선택합니다):

`top {{[-p|--pid]}} $(pgrep {{[-d|--delimiter]}} ',' {{프로세스_이름}})`

- 대화형 명령에 대한 도움말 표시:

`<?>`
