# distrobox-list

> 모든 Distrobox 컨테이너 나열.
> Distrobox 컨테이너는 일반 Podman 또는 Docker 컨테이너와 별도로 나열됩니다.
> 관련 항목: `distrobox`.
> 더 많은 정보: <https://distrobox.it/usage/distrobox-list/>.

- 모든 Distrobox 컨테이너 나열:

`distrobox-list`

- 자세한 정보를 포함하여 모든 Distrobox 컨테이너 나열:

`distrobox-list {{[-v|--verbose]}}`
