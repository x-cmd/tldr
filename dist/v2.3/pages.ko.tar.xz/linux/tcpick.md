# tcpick

> 패킷 스니핑 및 네트워크 트래픽 분석 도구.
> TCP 연결 및 데이터를 캡처하고 표시할 수 있습니다. 또한 인터페이스, 호스트, 포트의 네트워크 트래픽을 모니터링할 수 있습니다.
> 더 많은 정보: <https://manned.org/tcpick>.

- 특정 [i]인터페이스, 포트 및 호스트의 트래픽 캡처:

`sudo tcpick {{[-i|--interface]}} {{인터페이스}} {{[-C|--colors]}} -h {{호스트}} -p {{포트}}`

- 특정 호스트의 포트 80(HTTP) 트래픽 캡처:

`sudo tcpick {{[-i|--interface]}} {{eth0}} {{[-C|--colors]}} -h {{192.168.1.100}} -p {{80}}`

- 도움말 표시:

`tcpick --help`
