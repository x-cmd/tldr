# yum config-manager

> 이 명령은 `dnf config-manager`의 별칭입니다.

- 자세한 내용은 원본 명령을 참고하세요:

`tldr dnf config-manager`
