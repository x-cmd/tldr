# cron

> 작업이나 작업을 무인으로 실행하기 위한 시스템 스케줄러.
> `cron`에 항목을 제출, 편집 또는 삭제하는 명령을 `crontab`이라고 함.
> 더 많은 정보: <https://manned.org/cron>.

- `cron` 항목 관리에 대한 문서 보기:

`tldr crontab`
