# ic

> 이 명령은 `ibmcloud`의 별칭입니다.

- 원래 명령의 문서 보기:

`tldr ibmcloud`
