# now

> 서버리스 배포를 위한 클라우드 플랫폼.
> 이 명령어는 더 이상 사용되지 않습니다. 이 도구의 업데이트된 버전인 `vercel`을 참조하세요.
> 더 많은 정보: <https://vercel.com/home>.

- 현재 디렉토리 배포:

`now`

- 배포 목록 표시:

`now list`

- 배포와 관련된 정보 표시:

`now inspect {{배포_url}}`

- 배포 제거:

`now remove {{배포_id}}`

- 계정에 로그인하거나 새 계정 생성:

`now login`

- 예제 프로젝트 초기화 (새 디렉토리가 생성됩니다):

`now init`
