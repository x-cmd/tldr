# audacious

> 오픈 소스 오디오 플레이어.
> 관련 항목: `audtool`, `clementine`, `mpc`, `ncmpcpp`.
> 더 많은 정보: <https://manned.org/audacious>.

- 프로그램 실행:

`audacious`

- 새로운 인스턴스를 시작하고 오디오를 재생:

`audacious {{[-N|--new-instance]}} {{경로/대상/오디오}}`

- 오디오 파일의 특정 디렉터리를 대기열에 삽입:

`audacious {{[-e|--enqueue]}} {{경로/대상/디렉터리}}`

- 재생 시작 또는 중지:

`audacious {{[-t|--play-pause]}}`

- 재생 목록에서 앞으로 또는 뒤로 건너뛰기:

`audacious --{{fwd|rew}}`

- 재생 중지:

`audacious {{[-s|--stop]}}`

- 헤드리스 버전 시작:

`audacious {{[-H|--headless]}}`

- 재생이 중지되거나 재생할 내용이 없으면 즉시 종료:

`audacious {{[-q|--quit-after-play]}}`
