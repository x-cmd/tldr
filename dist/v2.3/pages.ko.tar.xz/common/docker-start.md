# docker start

> 이 명령은 `docker container start`의 별칭입니다.

- 원래 명령의 문서 보기:

`tldr docker container start`
