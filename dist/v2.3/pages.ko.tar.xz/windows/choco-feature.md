# choco feature

> Chocolatey를 통해 기능과 상호작용.
> 더 많은 정보: <https://docs.chocolatey.org/en-us/choco/commands/feature/>.

- 사용 가능한 기능 목록 표시:

`choco feature list`

- 기능 활성화:

`choco feature enable {{[-n|--name]}} {{이름}}`

- 기능 비활성화:

`choco feature disable {{[-n|--name]}} {{이름}}`
