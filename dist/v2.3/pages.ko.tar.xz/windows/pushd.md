# pushd

> 디렉토리를 스택에 배치하여 나중에 액세스할 수 있습니다.
> 같이 보기: `popd`.
> 더 많은 정보: <https://learn.microsoft.com/windows-server/administration/windows-commands/pushd>.

- 디렉토리로 전환하고 스택에 배치:

`pushd {{경로\대상\디렉토리}}`
