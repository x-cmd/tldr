# iwr

> 이 명령은 `invoke-webrequest`의 별칭입니다.

- 자세한 내용은 원본 명령을 참고하세요:

`tldr invoke-webrequest`
