# gdd

> 이 명령어는 GNU `dd`의 별칭.

- 원래 명령의 문서 보기:

`tldr {{[-p|--platform]}} linux dd`
