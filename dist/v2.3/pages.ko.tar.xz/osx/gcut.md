# gcut

> 이 명령은 `cut`의 별칭입니다.

- 원래 명령의 문서 보기:

`tldr {{[-p|--platform]}} common cut`
