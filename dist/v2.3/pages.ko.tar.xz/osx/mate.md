# mate

> macOS용 범용 텍스트 편집기.
> 더 많은 정보: <https://macromates.com/textmate/manual/opening-files#mate>.

- TextMate 시작:

`mate`

- 특정 파일 열기:

`mate {{경로/대상/파일1 경로/대상/파일2 ...}}`

- 파일의 파일 유형 지정:

`mate {{[-t|--type]}} {{파일유형}} {{경로/대상/파일}}`

- 특정 파일을 열고 편집이 완료될 때까지 대기:

`mate {{[-w|--wait]}} {{경로/대상/파일}}`

- 파일을 열고 특정 줄과 열에 커서를 위치시키기:

`mate {{[-l|--line]}} {{줄_번호}}:{{열_번호}} {{경로/대상/파일}}`
