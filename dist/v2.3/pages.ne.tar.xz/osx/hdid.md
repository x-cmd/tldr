# hdid

> यो आदेश `hdiutil attach` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr hdiutil`
