# ren

> यो आदेश `Rename-Item` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr Rename-Item`
