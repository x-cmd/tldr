# clist

> यो आदेश `choco list` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr choco list`
