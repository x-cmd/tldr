# h

> यो आदेश `Get-History` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr Get-History`
