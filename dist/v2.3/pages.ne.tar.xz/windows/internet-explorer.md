# internet-explorer

> यो आदेश `iexplore` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr {{[-p|--platform]}} windows iexplore`
