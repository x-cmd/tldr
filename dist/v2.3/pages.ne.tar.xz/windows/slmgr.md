# slmgr

> यो आदेश `slmgr.vbs` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr slmgr.vbs`
