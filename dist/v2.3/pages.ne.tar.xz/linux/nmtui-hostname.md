# nmtui-hostname

> यो आदेश `nmtui hostname` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr nmtui`
