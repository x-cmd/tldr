# dnf deplist

> यो आदेश `dnf repoquery --deplist` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr dnf repoquery`
