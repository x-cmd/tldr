# pw-record

> यो आदेश `pw-cat --record` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr pw-cat`
