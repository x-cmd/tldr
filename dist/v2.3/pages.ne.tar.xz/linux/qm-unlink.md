# qm unlink

> यो आदेश `qm disk unlink` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr qm disk`
