# steamos-boot-install

> यो आदेश `steamos-finalize-install` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr steamos-finalize-install`
