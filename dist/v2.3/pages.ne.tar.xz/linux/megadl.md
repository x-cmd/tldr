# megadl

> यो आदेश `megatools-dl` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr megatools-dl`
