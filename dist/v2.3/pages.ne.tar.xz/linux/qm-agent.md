# qm agent

> यो आदेश `qm guest cmd` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr qm guest`
