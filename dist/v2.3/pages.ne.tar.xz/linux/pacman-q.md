# pacman -Q

> यो आदेश `pacman --query` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr pacman query`
