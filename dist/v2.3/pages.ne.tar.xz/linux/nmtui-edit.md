# nmtui-edit

> यो आदेश `nmtui edit` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr nmtui`
