# pct move_volume

> यो आदेश `pct move-volume` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr pct move-volume`
