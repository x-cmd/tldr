# systemd-umount

> यो आदेश `systemd-mount --umount` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr systemd-mount`
