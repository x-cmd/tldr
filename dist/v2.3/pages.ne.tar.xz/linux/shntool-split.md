# shntool split

> यो आदेश `shnsplit` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr shnsplit`
