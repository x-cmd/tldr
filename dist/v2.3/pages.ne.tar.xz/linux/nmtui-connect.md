# nmtui-connect

> यो आदेश `nmtui connect` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr nmtui`
