# avahi-resolve-host-name

> यो आदेश `avahi-resolve --name` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr avahi-resolve`
