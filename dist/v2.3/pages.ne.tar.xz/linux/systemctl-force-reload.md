# systemctl force-reload

> यो आदेश `systemctl try-reload-or-restart` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr systemctl try-reload-or-restart`
