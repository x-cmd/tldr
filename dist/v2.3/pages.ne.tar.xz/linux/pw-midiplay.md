# pw-midiplay

> यो आदेश `pw-cat --playback --midi` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr pw-cat`
