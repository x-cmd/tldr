# pacman -F

> यो आदेश `pacman --files` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr pacman files`
