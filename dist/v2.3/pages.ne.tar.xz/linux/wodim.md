# wodim

> यो आदेश `cdrecord` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr cdrecord`
