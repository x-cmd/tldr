# mkfs.vfat

> यो आदेश `mkfs.fat` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr mkfs.fat`
