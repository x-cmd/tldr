# pacman -U

> यो आदेश `pacman --upgrade` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr pacman upgrade`
