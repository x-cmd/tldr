# impacket-rpcmap

> यो आदेश `rpcmap.py` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr rpcmap.py`
