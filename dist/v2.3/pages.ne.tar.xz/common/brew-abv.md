# brew abv

> यो आदेश `brew info` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr brew info`
