# tldrl

> यो आदेश `tldr-lint` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr tldr-lint`
