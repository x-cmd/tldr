# compare

> यो आदेश `magick compare` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr magick compare`
