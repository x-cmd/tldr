# lzfgrep

> यो आदेश `xzgrep --fixed-strings` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr xzgrep`
