# fgrep

> यो आदेश `grep --fixed-strings` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr grep`
