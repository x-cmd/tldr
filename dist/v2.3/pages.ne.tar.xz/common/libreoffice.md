# libreoffice

> यो आदेश `soffice` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr soffice`
