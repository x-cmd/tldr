# npm run-script

> यो आदेश `npm run` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr npm run`
