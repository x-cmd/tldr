# impacket-sniff

> यो आदेश `sniff.py` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr sniff.py`
