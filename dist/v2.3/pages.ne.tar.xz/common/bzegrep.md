# bzegrep

> यो आदेश `bzgrep --extended-regexp` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr bzgrep`
