# bun i

> यो आदेश `bun install` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr bun install`
