# pnmtopnm

> यो आदेश `pamtopnm` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr pamtopnm`
