# rbash

> यो आदेश `bash --restricted` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr bash`
