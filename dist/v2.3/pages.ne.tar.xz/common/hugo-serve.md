# hugo serve

> यो आदेश `hugo server` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr hugo server`
