# fossil rm

> यो आदेश `fossil delete` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr fossil delete`
