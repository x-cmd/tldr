# llvm-strings

> यो आदेश `strings` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr strings`
