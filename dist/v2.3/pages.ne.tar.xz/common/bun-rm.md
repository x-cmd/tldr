# bun rm

> यो आदेश `bun remove` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr bun remove`
