# impacket-getArch

> यो आदेश `getArch.py` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr getArch.py`
