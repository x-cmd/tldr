# docker rmi

> यो आदेश `docker image rm` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr docker image rm`
