# luantiserver

> यो आदेश `luanti --server` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr luanti`
