# bunzip2

> यो आदेश `bzip2 --decompress` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr bzip2`
