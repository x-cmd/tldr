# unfunction

> यो आदेश `unhash -f` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr unhash`
