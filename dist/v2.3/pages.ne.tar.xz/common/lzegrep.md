# lzegrep

> यो आदेश `xzgrep --extended-regexp` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr xzgrep`
