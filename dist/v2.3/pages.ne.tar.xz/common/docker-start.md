# docker start

> यो आदेश `docker container start` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr docker container start`
