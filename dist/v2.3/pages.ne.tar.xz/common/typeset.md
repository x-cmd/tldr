# typeset

> यो आदेश `declare` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr declare`
