# docker exec

> यो आदेश `docker container exec` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr docker container exec`
