# zstdcat

> यो आदेश `zstd --decompress --stdout --force` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr zstd`
