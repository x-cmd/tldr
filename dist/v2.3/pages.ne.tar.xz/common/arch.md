# arch

> यो आदेश `uname --machine` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr uname`
