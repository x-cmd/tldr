# impacket-smbserver

> यो आदेश `smbserver.py` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr smbserver.py`
