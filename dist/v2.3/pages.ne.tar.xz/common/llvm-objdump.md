# llvm-objdump

> यो आदेश `objdump` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr objdump`
