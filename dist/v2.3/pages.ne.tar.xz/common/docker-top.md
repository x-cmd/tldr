# docker top

> यो आदेश `docker container top` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr docker container top`
