# pulumi down

> यो आदेश `pulumi destroy` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr pulumi destroy`
