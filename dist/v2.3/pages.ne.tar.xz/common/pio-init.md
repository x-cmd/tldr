# pio init

> यो आदेश `pio project init` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr pio project`
