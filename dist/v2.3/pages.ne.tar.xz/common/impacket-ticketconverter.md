# impacket-ticketConverter

> यो आदेश `ticketConverter.py` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr ticketConverter.py`
