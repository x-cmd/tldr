# fmtutil-user

> यो आदेश `fmtutil --user` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr fmtutil`
