# impacket-getST

> यो आदेश `getST.py` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr getST.py`
