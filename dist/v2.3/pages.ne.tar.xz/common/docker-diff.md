# docker diff

> यो आदेश `docker container diff` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr docker container diff`
