# impacket-GetNPUsers

> यो आदेश `GetNPUsers.py` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr GetNPUsers.py`
