# npm test

> यो आदेश `npm run test` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr npm run`
