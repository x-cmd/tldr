# ug

> यो आदेश `ugrep --config --pretty --sort` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr ugrep`
