# docker rm

> यो आदेश `docker container rm` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr docker container rm`
