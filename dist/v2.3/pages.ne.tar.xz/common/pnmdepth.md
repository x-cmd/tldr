# pnmdepth

> यो आदेश `pamdepth` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr pamdepth`
