# docker logs

> यो आदेश `docker container logs` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr docker container logs`
