# mapfile

> यो आदेश `readarray` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr readarray`
