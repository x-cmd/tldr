# gnmic sub

> यो आदेश `gnmic subscribe` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr gnmic subscribe`
