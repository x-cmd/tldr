# egrep

> यो आदेश `grep --extended-regexp` को उपनाम हो।
> हेर्नुहोस् पनि: `regex`।
> थप जानकारी: <https://manned.org/egrep>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr grep`
