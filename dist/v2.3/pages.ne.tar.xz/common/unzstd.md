# unzstd

> यो आदेश `zstd --decompress` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr zstd`
