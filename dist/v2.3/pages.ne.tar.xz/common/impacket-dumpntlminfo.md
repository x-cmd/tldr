# impacket-DumpNTLMInfo

> यो आदेश `DumpNTLMInfo.py` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr DumpNTLMInfo.py`
