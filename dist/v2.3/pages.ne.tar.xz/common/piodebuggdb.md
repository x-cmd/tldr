# piodebuggdb

> यो आदेश `pio debug --interface gdb` को उपनाम हो।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr pio debug`
