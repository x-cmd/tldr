# egrep

> هذا الأمر هو اسم مستعار لـ `grep --extended-regexp`.
> انظر أيضًا: `regex`.
> لمزيد من التفاصيل: <https://manned.org/egrep>.

- اعرض التوثيقات للأمر الأصلي:

`tldr grep`
