# ypchpass

> هذا الأمر هو اسم مستعار لـ `chpass`.

- اعرض التوثيقات للأمر الأصلي:

`tldr chpass`
