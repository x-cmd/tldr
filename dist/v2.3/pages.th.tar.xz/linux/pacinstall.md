# pacinstall

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `pactrans --install`

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr pactrans`
