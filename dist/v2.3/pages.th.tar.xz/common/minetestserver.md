# minetestserver

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `luanti --server`

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr luanti`
