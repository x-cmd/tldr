# file-rename

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `rename`

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr {{[-p|--platform]}} common rename`
