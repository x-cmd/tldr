# pnmtoplainpnm

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `pamtopnm -plain`

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr pamtopnm`
