# lzcat

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `xz --format lzma --decompress --stdout`

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr xz`
