# identify

> இக்கட்டளை `magick identify` கட்டளையின் மற்றொருப் பெயர்.

- அக்கட்டளையின் விளக்கத்தைக் காண:

`tldr magick identify`
