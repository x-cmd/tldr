# docker run

> இக்கட்டளை `docker container run` கட்டளையின் மற்றொருப் பெயர்.

- அக்கட்டளையின் விளக்கத்தைக் காண:

`tldr docker container run`
