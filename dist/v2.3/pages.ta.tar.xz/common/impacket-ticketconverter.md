# impacket-ticketConverter

> இக்கட்டளை `ticketConverter.py` கட்டளையின் மற்றொருப் பெயர்.

- அக்கட்டளையின் விளக்கத்தைக் காண:

`tldr ticketConverter.py`
