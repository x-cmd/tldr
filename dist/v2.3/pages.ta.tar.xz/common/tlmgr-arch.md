# tlmgr arch

> இக்கட்டளை `tlmgr platform` கட்டளையின் மற்றொருப் பெயர்.

- அக்கட்டளையின் விளக்கத்தைக் காண:

`tldr tlmgr platform`
