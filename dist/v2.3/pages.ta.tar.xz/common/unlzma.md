# unlzma

> இக்கட்டளை `xz --format lzma --decompress` கட்டளையின் மற்றொருப் பெயர்.

- அக்கட்டளையின் விளக்கத்தைக் காண:

`tldr xz`
