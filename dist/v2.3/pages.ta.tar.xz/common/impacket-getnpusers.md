# impacket-GetNPUsers

> இக்கட்டளை `GetNPUsers.py` கட்டளையின் மற்றொருப் பெயர்.

- அக்கட்டளையின் விளக்கத்தைக் காண:

`tldr GetNPUsers.py`
