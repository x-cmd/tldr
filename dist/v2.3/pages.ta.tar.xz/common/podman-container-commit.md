# podman container commit

> இக்கட்டளை `podman commit` கட்டளையின் மற்றொருப் பெயர்.

- அக்கட்டளையின் விளக்கத்தைக் காண:

`tldr podman commit`
