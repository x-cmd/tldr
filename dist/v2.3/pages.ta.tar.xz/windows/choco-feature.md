# choco feature

> சாக்லேட்டியுடன் அம்சங்களுடன் தொடர்பு கொள்ளுங்கள்.
> மேலும் விவரத்திற்கு: <https://docs.chocolatey.org/en-us/choco/commands/feature/>.

- கிடைக்கக்கூடிய அம்சங்களின் பட்டியலைக் காண்பி:

`choco feature list`

- ஒரு அம்சத்தை இயக்கு:

`choco feature enable {{[-n|--name]}} {{பெயர்}}`

- ஒரு அம்சத்தை முடக்கு:

`choco feature disable {{[-n|--name]}} {{பெயர்}}`
