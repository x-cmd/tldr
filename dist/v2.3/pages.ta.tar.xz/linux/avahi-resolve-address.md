# avahi-resolve-address

> இக்கட்டளை `avahi-resolve --address` கட்டளையின் மற்றொருப் பெயர்.

- அக்கட்டளையின் விளக்கத்தைக் காண:

`tldr avahi-resolve`
