# pw-encplay

> இக்கட்டளை `pw-cat --playback --encoded` கட்டளையின் மற்றொருப் பெயர்.

- அக்கட்டளையின் விளக்கத்தைக் காண:

`tldr pw-cat`
