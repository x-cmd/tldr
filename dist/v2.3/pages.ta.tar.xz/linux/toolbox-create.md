# toolbox create

> புதிய Toolbx கொள்கலனை உருவாக்கவும்.
> மேலும் விவரத்திற்கு: <https://manned.org/toolbox-create>.

- ஒரு குறிப்பிட்ட விநியோகத்திற்காக Toolbx கொள்கலனை உருவாக்கவும்:

`toolbox create --distro {{விநியோகம்}}`

- தற்போதைய விநியோகத்தின் குறிப்பிட்ட வெளியீட்டிற்கு Toolbx கொள்கலனை உருவாக்கவும்:

`toolbox create --release {{வெளியீடு}}`

- தனிப்பயன் படத்துடன் Toolbx கொள்கலனை உருவாக்கவும்:

`toolbox create --image {{பெயர்}}`

- தனிப்பயன் ஃபெடோரா படத்திலிருந்து Toolbx கொள்கலனை உருவாக்கவும்:

`toolbox create --image {{registry.fedoraproject.org/fedora-toolbox:39}}`

- ஃபெடோரா 39க்கான இயல்புநிலை படத்தைப் பயன்படுத்தி Toolbx கொள்கலனை உருவாக்கவும்:

`toolbox create --distro {{fedora}} --release {{f39}}`
