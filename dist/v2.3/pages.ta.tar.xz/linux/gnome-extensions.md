# gnome-extensions

> டெர்மினலில் இருந்து க்னோம் நீட்டிப்புகளை நிர்வகிக்கவும்.
> மேலும் விவரத்திற்கு: <https://wiki.gnome.org/Projects/GnomeShell/Extensions>.

- நிறுவப்பட்ட அனைத்து நீட்டிப்புகளையும் பட்டியலிடுங்கள்:

`gnome-extensions list`

- ஒரு குறிப்பிட்ட நீட்டிப்பு பற்றிய தகவலைக் காட்டு:

`gnome-extensions info "{{நீட்டிப்பு_ஐடி}}"`

- ஒரு குறிப்பிட்ட நீட்டிப்பை இயக்கு:

`gnome-extensions enable "{{நீட்டிப்பு_ஐடி}}"`

- ஒரு குறிப்பிட்ட நீட்டிப்பை முடக்கு:

`gnome-extensions disable "{{நீட்டிப்பு_ஐடி}}"`

- ஒரு குறிப்பிட்ட நீட்டிப்பை நிறுவல் நீக்கு:

`gnome-extensions uninstall "{{நீட்டிப்பு_ஐடி}}"`

- துணைக் கட்டளைக்கான உதவியைக் காண்பி (`list` போன்றவை):

`gnome-extensions help {{துணை_கட்டளை}}`

- பதிப்பைக் காட்டு:

`gnome-extensions version`
