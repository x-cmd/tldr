# systemctl force-reload

> Det här kommandot är ett alias för `systemctl try-reload-or-restart`.

- Se dokumentationen för originalkommandot:

`tldr systemctl try-reload-or-restart`
