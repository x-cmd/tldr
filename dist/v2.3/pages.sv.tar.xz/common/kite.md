# kite

> Det här kommandot är ett alias för `kiterunner`.

- Se dokumentationen för originalkommandot:

`tldr kiterunner`
