# pushd

> Tilføj en mappe til mappe-stakken, så den kan tilgås på et senere tidspunkt.
> Se også: `popd`, `dirs`.
> Mere information: <https://www.gnu.org/software/bash/manual/bash.html#index-pushd>.

- Skift til mappe og tilføj den til mappe-stakken:

`pushd {{mappe}}`

- Byt om på første og anden mappe i mappe-stakken:

`pushd`

- Rotér mappe-stakken ved at gøre det femte element til det første i mappe-stakken:

`pushd +4`
