# pw-midiplay

> Тази команда е псевдоним на `pw-cat --playback --midi`.

- Виж документацията за оригиналната команда:

`tldr pw-cat`
