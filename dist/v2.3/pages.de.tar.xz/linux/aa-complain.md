# aa-complain

> Setze eine AppArmor-Richtlinie in den Beschwerde-Modus.
> Siehe auch: `aa-disable`, `aa-enforce`, `aa-status`.
> Weitere Informationen: <https://gitlab.com/apparmor/apparmor/-/wikis/manpage_aa-complain.8>.

- Setze eine Richtlinie in den Beschwerde-Modus:

`sudo aa-complain {{pfad/zu/profil}}`

- Setze Richtlinien in den Beschwerde-Modus:

`sudo aa-complain {{[-d|--dir]}} {{pfad/zu/profil}}`
