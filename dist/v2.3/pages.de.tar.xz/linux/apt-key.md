# apt-key

> Schlüssel-Management-Tool für den APT-Paket-Manager auf Debian und Ubuntu.
> Notiz: `apt-key` ist veraltet (außer für `apt-key del` in Maintainerskripten).
> Weitere Informationen: <https://manned.org/apt-key>.

- Liste alle vertrauten Schlüssel auf:

`apt-key list`

- Füge einen Schlüssel hinzu:

`apt-key add {{public_key_file.asc}}`

- Lösche einen Schlüssel:

`apt-key del {{key_id}}`

- Füge einen Remote-Schlüssel hinzu:

`wget {{[-qO|--quiet --output-document]}} - {{https://host.tld/filename.key}} | apt-key add -`

- Füge einen Schlüssel von einem Schlüsselserver hinzu nur mit der Schlüssel-ID:

`apt-key adv --keyserver {{pgp.mit.edu}} --recv {{key_id}}`
