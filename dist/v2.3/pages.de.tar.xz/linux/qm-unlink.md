# qm unlink

> Dieser Befehl ist ein Alias von `qm disk unlink`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr qm disk`
