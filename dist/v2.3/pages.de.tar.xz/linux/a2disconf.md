# a2disconf

> Deaktiviert eine Apache-Konfigurationsdatei auf Debian-basierten Betriebssystemen.
> Weitere Informationen: <https://manned.org/a2disconf>.

- Deaktiviere eine Konfigurationsdatei:

`sudo a2disconf {{konfigurationsdatei}}`

- Zeige keine Informationsnachrichten an:

`sudo a2disconf {{[-q|--quiet]}} {{konfigurationsdatei}}`
