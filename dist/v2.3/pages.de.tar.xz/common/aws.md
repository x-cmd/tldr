# aws

> Das offizielle CLI für Amazon Web Services.
> Manche Unterbefehle wie `s3` sind separat dokumentiert.
> Weitere Informationen: <https://docs.aws.amazon.com/cli/latest/reference/>.

- Konfiguriere die AWS Kommandozeile:

`aws configure wizard`

- Konfiguriere die AWS Kommandozeile mithilfe von SSO:

`aws configure sso`

- Zeige Informationen über die eigene angenommene Identität (häufig benutzt zur Fehlersuche):

`aws sts get-caller-identity`

- Liste alle AWS Ressourcen in einer Region mit YAML Formatierung auf:

`aws dynamodb list-tables --region {{us-east-1}} --output yaml`

- Erstelle einen IAM Benutzer mit Ausführungsassistent:

`aws iam create-user --cli-auto-prompt`

- Öffne einen Assistenten für eine AWS Ressource:

`aws dynamodb wizard {{neue_tabelle}}`

- Erstelle einen JSON CLI-Aufbau (hilfreich für Infrastruktur-Automation):

`aws dynamodb update-table --generate-cli-skeleton`

- Zeige Hilfe für ein Kommando an:

`aws {{befehl}} help`
