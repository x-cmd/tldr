# traefik

> Ein HTTP-Reverse-Proxy und Load-Balancer.
> Weitere Informationen: <https://doc.traefik.io/traefik/v3.4/operations/cli/>.

- Starte den Server mit der Standardkonfiguration:

`traefik`

- Starte den Server mit einer benutzerdefinierten Konfigurationsdatei:

`traefik --ConfigFile {{konfigurationsdatei.toml}}`

- Starte den Server mit aktiviertem Cluster-Modus:

`traefik --cluster`

- Starte den Server mit dem Web-UI:

`traefik --web`
