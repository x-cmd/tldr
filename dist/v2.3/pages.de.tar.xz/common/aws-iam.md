# aws iam

> CLI für AWS IAM.
> Weitere Informationen: <https://docs.aws.amazon.com/cli/latest/reference/iam/>.

- Liste aller Benutzer auf:

`aws iam list-users`

- Liste aller Richtlinien auf:

`aws iam list-policies`

- Liste aller Gruppen auf:

`aws iam list-groups`

- Liste aller Benutzer zu einer Gruppe auf:

`aws iam get-group --group-name {{gruppe}}`

- Liste einer IAM Richtlinie detailliert auf:

`aws iam get-policy --policy-arn arn:aws:iam::aws:policy/{{richtlinie}}`

- Liste alle Zugriffsschlüssel auf:

`aws iam list-access-keys`

- Liste alle Zugriffsschlüssel für einen Benutzer auf:

`aws iam list-access-keys --user-name {{benutzername}}`

- Zeige Hilfe an:

`aws iam help`
