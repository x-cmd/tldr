# docker service

> Verwalte Docker Services.
> Weitere Informationen: <https://docs.docker.com/reference/cli/docker/service/>.

- Liste alle Services auf:

`docker service ls`

- Erstelle einen neuen Service:

`docker service create --name {{service_name}} {{image}}:{{tag}}`

- Zeige detaillierte Informationen der mit Leerzeichen separierten Services an:

`docker service inspect {{service_name|id}}`

- Liste die Tasks der mit Leerzeichen separierten Services auf:

`docker service ps {{service_name|id}}`

- Skaliere die angegebenen Services auf eine bestimmte Anzahl an Replikaten:

`docker service scale {{service_name}}={{anzahl_an_replikaten}}`

- Lösche die mit Leerzeichen separierten Services:

`docker service rm {{service_name|id}}`
