# choco pack

> Verpacke eine NuGet-Spezifikation in eine `.nupkg`-Datei.
> Weitere Informationen: <https://docs.chocolatey.org/en-us/create/commands/pack/>.

- Verpacke eine NuGet-Spezifikation in eine `.nupkg`-Datei:

`choco pack {{pfad/zu/spezifikation}}`

- Verpacke eine NuGet-Spezifikation in eine `.nupkg`-Datei und bestimme die Version der ausgegebenen Datei:

`choco pack {{pfad/zu/spezifikation}} --version {{version}}`

- Verpacke eine NuGet-Spezifikation in eine `.nupkg`-Datei, welche in einem bestimmten Verzeichnis gespeichert wird:

`choco pack {{pfad/zu/spezifikation}} {{[--out|--output-directory]}} {{pfad/zu/ausgabe_verzeichnis}}`
