# choco outdated

> Überprüfe mit Chocolatey, ob Pakete veraltet sind.
> Weitere Informationen: <https://docs.chocolatey.org/en-us/choco/commands/outdated/>.

- Zeige eine Liste von veralteten Paketen im Tabellen-Format:

`choco outdated`

- Ignoriere angeheftete Pakete in der Ausgabe:

`choco outdated --ignore-pinned`

- Gib eine eigene Quelle an, mit der die Aktualität der Pakete überprüft wird:

`choco outdated {{[-s|--source]}} {{source_url|alias}}`

- Gib einen Benutzernamen und ein Passwort für die Authentifizierung an:

`choco outdated {{[-u|--user]}} {{benutzername}} {{[-p|--password]}} {{passwort}}`
