# choco upgrade

> Aktualisiere mit Chocolatey ein oder mehrere Pakete.
> Weitere Informationen: <https://docs.chocolatey.org/en-us/choco/commands/upgrade/>.

- Aktualisiere ein oder mehrere Pakete, deren Namen mit Leerzeichen getrennt sind:

`choco upgrade {{paket(e)}}`

- Aktualisiere auf eine bestimmte Version des Pakets:

`choco upgrade {{paket}} --version {{version}}`

- Aktualisiere alle Pakete:

`choco upgrade all`

- Aktualisiere alle außer den angegebenen, durch Kommas getrennten Paketen:

`choco upgrade all --except "{{paket(e)}}"`

- Stimme allen Fragen automatisch zu:

`choco upgrade {{paket}} {{[-y|--yes]}}`

- Gib eine eigene Quelle an, von der Pakete aktualisiert werden:

`choco upgrade {{paket}} {{[-s|--source]}} {{quell_url|alias}}`

- Gib einen Benutzernamen und ein Passwort für die Authentifizierung an:

`choco upgrade {{paket}} {{[-u|--user]}} {{benutzername}} {{[-p|--password]}} {{passwort}}`
