# fzf

> Recherche approximative en ligne de commande.
> Similaire à `sk`.
> Plus d'informations : <https://github.com/junegunn/fzf#usage>.

- Lance `fzf` sur tous les fichiers du répertoire spécifié :

`find {{chemin/vers/répertoire}} -type f | fzf`

- Démarre `fzf` pour les processus en cours :

`ps aux | fzf`

- Sélectionne plusieurs fichiers avec `<Shift Tab>` et écrit dans un fichier :

`find {{chemin/vers/répertoire}} -type f | fzf {{[-m|--multi]}} > {{chemin/vers/fichier}}`

- Lance `fzf` avec une requête donnée :

`fzf {{[-q|--query]}} "{{query}}"`

- Lance `fzf` sur les entrées qui commencent par `core` et se terminent par `go`, `rb`, ou `py` :

`fzf {{[-q|--query]}} "^core go$ | rb$ | py$"`

- Lance `fzf` sur les entrées qui ne correspondent pas à pyc et qui correspondent exactement à travis :

`fzf {{[-q|--query]}} '!pyc travis'`
