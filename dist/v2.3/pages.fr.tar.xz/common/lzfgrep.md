# lzfgrep

> Cette commande est un alias de `xzgrep --fixed-strings`.

- Affiche la documentation de la commande originale :

`tldr xzgrep`
