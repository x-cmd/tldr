# git show-ref

> Commande Git pour lister les références.
> Plus d'informations : <https://git-scm.com/docs/git-show-ref>.

- Affiche toutes les références dans le dépôt :

`git show-ref`

- Affiche seulement les références des têtes de branches :

`git show-ref --branches`

- Affiche seulement les références de tags :

`git show-ref --tags`

- Vérifie l'existence d'une référence :

`git show-ref --verify {{chemin/vers/reference}}`
