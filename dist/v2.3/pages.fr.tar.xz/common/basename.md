# basename

> Retourne la portion ne contenant pas de dossiers d'un chemin complet.
> Voir aussi : `dirname`.
> Plus d'informations : <https://www.gnu.org/software/coreutils/manual/html_node/basename-invocation.html>.

- N'affiche que le nom du fichier depuis un chemin :

`basename {{chemin/vers/fichier}}`

- N'affiche que le nom du dernier répertoire depuis un chemin :

`basename {{chemin/vers/répertoire/}}`

- N'affiche que le nom du fichier depuis un chemin, en ôtant un préfixe donné :

`basename {{chemin/vers/fichier}} {{suffixe}}`
