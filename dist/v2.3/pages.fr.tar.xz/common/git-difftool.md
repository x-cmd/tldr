# git difftool

> Affiche les modifications apportées aux fichiers à l'aide d'outils de comparaison externes. Accepte les mêmes options et arguments que Git diff.
> Voir aussi : `git diff`.
> Plus d'informations : <https://git-scm.com/docs/git-difftool>.

- Liste les outils de comparaison disponibles :

`git difftool --tool-help`

- Configure Meld comme outil de comparaison par défaut :

`git config --global diff.tool "{{meld}}"`

- Utilise l'outil de comparaison par défaut pour afficher les fichiers modifiés :

`git difftool --staged`

- Utilise un outil de comparaison spécifique (opendiff) pour afficher les changements depuis une validation :

`git difftool {{[-t|--tool]}} {{opendiff}} {{validation}}`
