# nix build

> Construit une expression Nix (télécharge depuis le cache si possible).
> Voir aussi : `nix-build`, `nix flake`.
> Plus d'informations : <https://nix.dev/manual/nix/stable/command-ref/new-cli/nix3-build.html>.

- Construit un paquet depuis nixpkgs, en liant le résultat symboliquement à `./result` :

`nix build {{nixpkgs#pkg}}`

- Construit un paquet depuis un flake du répertoire actuel, en affichant les journaux du processus :

`nix build {{[-L|--print-build-logs]}} {{.#pkg}}`

- Construit le paquet par défaut d'un flake depuis un dossier quelconque :

`nix build {{chemin/vers/dossier}}`

- Construit un paquet sans lier symboliquement le résultat, mais affiche le chemin de stockage dans le `stdout` :

`nix build --no-link --print-out-paths`
