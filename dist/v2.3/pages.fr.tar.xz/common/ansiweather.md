# ansiweather

> Un script Shell pour afficher les conditions météo actuelles dans votre terminal.
> Plus d'informations : <https://github.com/fcambus/ansiweather#usage>.

- Affiche une prévision avec le système métrique pour les 7 prochains jours dans la ville de Paris, France :

`ansiweather -u metric -f 7 -l {{Paris,FR}}`

- Affiche une prévision avec des symboles et les données d'ensoleillement pour votre position actuelle :

`ansiweather -F -s true -d true`

- Affiche une prévision avec les données sur le vent et l'humidité pour votre position actuelle :

`ansiweather -w true -h true`
