# cmus

> Lecteur de musique en ligne de commande.
> Utiliser `<ArrowKeys>` pour naviguer, `<Enter>` pour sélectionner, et les nombres `<1>`-`<8>` pour se déplacer dans les différentes vues.
> Voir aussi : `ncmpcpp`, `clementine`, `qmmp`.
> Plus d'informations : <https://manned.org/cmus>.

- Ouvre cmus dans le dossier spécifié (celui-ci deviendra le dossier de travail) :

`cmus {{chemin/vers/dossier}}`

- Ajoute un fichier/dossier à la bibliothèque :

`<:>add {{chemin/vers/fichier_ou_dossier}}`

- Mets en pause/relancer la musique actuelle :

`<c>`

- Active/désactive le mode aléatoire :

`<s>`

- Quitte cmus :

`<q>`
