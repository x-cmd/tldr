# sh

> Bourne SHell, l'interpréteur de ligne de commande classique.
> Voir aussi : `!`, `^`.
> Plus d'informations : <https://manned.org/sh>.

- Démarre une session shell interactive :

`sh`

- Exécute une commande, puis termine la session :

`sh -c "{{commande}}"`

- Exécute un script :

`sh {{chemin/vers/le/script.sh}}`

- Lit et exécute des commandes depuis l'entrée standard `stdin` :

`sh -s`
