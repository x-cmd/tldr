# antibody

> Le gestionnaire de modules shell "le plus rapide".
> Plus d'informations : <https://getantibody.github.io/#Usage>.

- Regroupe tous les modules pour un chargement statique :

`antibody <{{~/.zsh_modules.txt}} bundle >{{~/.zsh_modules.sh}}`

- Mets à jour tous les modules :

`antibody update`

- Liste tous les modules installés :

`antibody list`
