# code

> Éditeur de code multiplateforme et extensible.
> Plus d'informations : <https://code.visualstudio.com/docs/configure/command-line>.

- Démarre Visual Studio Code :

`code`

- Ouvre des fichiers/répertoires spécifiques :

`code {{chemin/vers/fichier_ou_répertoire1 chemin/vers/fichier_ou_répertoire2 ...}}`

- Compare deux fichiers spécifiques :

`code {{[-d|--diff]}} {{chemin/vers/fichier1}} {{chemin/vers/fichier2}}`

- Ouvre des fichiers/répertoires spécifiques dans une nouvelle fenêtre :

`code {{[-n|--new-window]}} {{chemin/vers/fichier_ou_répertoire1 chemin/vers/fichier_ou_répertoire2 ...}}`

- Installe/désinstalle une extension spécifique :

`code --{{install|uninstall}}-extension {{éditeur.extension}}`

- Affiche les informations de diagnostic et de processus de la fenêtre de code en cours d’exécution :

`code {{[-s|--status]}}`

- Affiche les extensions installées avec leurs versions :

`code --list-extensions --show-versions`

- Démarre l'éditeur en tant que super utilisateur (root) tout en stockant les données utilisateur dans un répertoire spécifique :

`sudo code --user-data-dir {{chemin/vers/répertoire}}`
