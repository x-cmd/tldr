# agate

> Un serveur simple pour le protocole réseau Gemini.
> Plus d'informations : <https://github.com/mbrubeck/agate>.

- Exécute et génère une clé privée et un certificat :

`agate --content {{chemin/vers/contenu}}/ --addr {{[::]:1965}} --addr {{0.0.0.0:1965}} --hostname {{example.com}} --lang {{fr-FR}}`

- Lance le serveur :

`agate {{chemin/vers/fichier}}`

- Affiche l'aide :

`agate {{[-h|--help]}}`
