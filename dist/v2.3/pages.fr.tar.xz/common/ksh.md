# ksh

> Korn SHell, un interpréteur de ligne de commande compatible avec Bash.
> Voir aussi : `!`, `^`.
> Plus d'informations : <https://manned.org/ksh>.

- Démarre une session shell interactive :

`ksh`

- Exécute une commande, puis termine la session :

`ksh -c "{{commande}}"`

- Exécute un script :

`ksh {{chemin/vers/le/script.ksh}}`

- Exécute un script en affichant chaque commande avant de l'exécuter :

`ksh -x {{chemin/vers/le/script.ksh}}`
