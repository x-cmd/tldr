# apktool

> Outil de Rétro-ingénierie pour les fichier APK.
> Plus d'informations : <https://ibotpeaches.github.io/Apktool/>.

- Décode un fichier APK :

`apktool d {{chemin/vers/fichier}}.apk`

- Construit un fichier APK depuis un répertoire :

`apktool b {{chemin/vers/répertoire}}`

- Installe et enregistre le framework :

`apktool if {{framework}}.apk`
