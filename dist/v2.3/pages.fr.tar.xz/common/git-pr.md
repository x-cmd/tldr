# git pr

> Récupère les pull-requests GitHub localement.
> Fait partie de `git-extras`.
> Plus d'informations : <https://github.com/tj/git-extras/blob/main/Commands.md#git-pr>.

- Récupère une pull-request spécifique :

`git pr {{pr_number}}`

- Récupère une pull-request d'un dépôt spécifique :

`git pr {{pr_number}} {{distant}}`

- Récupère une pull-request depuis son URL :

`git pr {{url}}`

- Nettoie les branches de pull-requests terminées :

`git pr clean`
