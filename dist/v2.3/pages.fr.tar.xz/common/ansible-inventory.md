# ansible-inventory

> Affiche ou énumère le contenu d'un inventaire Ansible.
> Voir aussi : `ansible`.
> Plus d'informations : <https://docs.ansible.com/projects/ansible/latest/cli/ansible-inventory.html>.

- Affiche l'inventaire par défaut :

`ansible-inventory --list`

- Affiche un inventaire spécifique :

`ansible-inventory --list {{[-i|--inventory-file]}} {{chemin/vers/fichier_ou_script_ou_répertoire}}`

- Affiche l'inventaire par défaut en YAML :

`ansible-inventory --list {{[-y|--yaml]}}`

- Sauvegarde l'inventaire par défaut dans un fichier :

`ansible-inventory --list --output {{chemin/vers/fichier}}`
