# avrdude

> Pilotes pour programmer les microcontrôleurs Atmel AVR.
> Plus d'informations : <https://www.nongnu.org/avrdude/user-manual/avrdude_3.html#Option-Descriptions>.

- Lire le contenu du microcontrôleur AVR :

`avrdude -p {{part_id}} -c {{programmeur}} -U flash:r:{{fichier.hex}}:i`

- Programme le microcontrôleur AVR :

`avrdude -p {{part_id}} -c {{programmeur}} -U flash:w:{{fichier.hex}}`

- Affiche les appareils AVR disponibles :

`avrdude -p \?`

- Affiche les programmeurs AVR disponibles :

`avrdude -c \?`
