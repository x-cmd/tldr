# sudo

> Exécute une commande unique en tant que super-utilisateur (super-user) ou un autre utilisateur.
> Voir aussi : `pkexec`, `run0`, `doas`.
> Plus d'informations : <https://www.sudo.ws/sudo.html>.

- Exécute une commande en tant que super-utilisateur :

`sudo {{less /var/log/syslog}}`

- Édite un fichier en tant que super-utilisateur avec votre éditeur par défaut :

`sudo {{[-e|--edit]}} {{/etc/fstab}}`

- Exécute une commande en tant qu'un autre utilisateur et/ou groupe :

`sudo {{[-u|--user]}} {{utilisateur}} {{[-g|--group]}} {{groupe}} {{id -a}}`

- Répète la dernière commande préfixée de `sudo` (uniquement dans Bash, Zsh, etc.) :

`sudo !!`

- Lance le terminal par défaut avec des privilèges de super-utilisateur et exécute des fichiers à profil spécifique (`.profile`, `.bash_profile`, etc.) :

`sudo {{[-i|--login]}}`

- Lance le terminal par défaut avec des privilèges de super-utilisateur sans modifier l'environnement :

`sudo {{[-s|--shell]}}`

- Lance le terminal par défaut en tant que l'utilisateur spécifié, en chargeant l'environnement de cet utilisateur et en lisant les fichiers à profil spécifique de cet utilisateur (`.profile`, `.bash_profile`, etc.) :

`sudo {{[-i|--login]}} {{[-u|--user]}} {{utilisateur}}`

- Liste les commandes autorisées (et interdites) pour l'utilisateur actuel :

`sudo {{[-ll|--list --list]}}`
