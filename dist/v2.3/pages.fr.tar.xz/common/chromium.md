# chromium

> Navigateur Web open source principalement développé et maintenu par Google.
> Remarque : Vous devrez peut-être remplacer la commande `chromium` par le navigateur web de votre choix, tel que `brave`, `google-chrome`, `opera`, ou `vivaldi`.
> Plus d'informations : <https://www.chromium.org/developers/how-tos/run-chromium-with-flags/>.

- Ouvre une URL ou un fichier spécifique :

`chromium {{https://example.com|chemin/vers/fichier.html}}`

- Ouvre en mode navigation privée :

`chromium --incognito {{example.com}}`

- Ouvre dans une nouvelle fenêtre :

`chromium --new-window {{example.com}}`

- Ouvre en mode application (sans barres d'outils, barre d'URL, boutons, etc) :

`chromium --app={{https://example.com}}`

- Utilise un serveur proxy :

`chromium --proxy-server="{{://hostname:66}}" {{example.com}}`

- Ouvre dans un répertoire de profil personnalisé :

`chromium --user-data-dir={{chemin/vers/répertoire}}`

- Ouvre sans validation CORS (utile pour tester une API) :

`chromium --user-data-dir={{chemin/vers/répertoire}} --disable-web-security`

- Ouvre avec une fenêtre outils de développement pour chaque onglet ouvert :

`chromium --auto-open-devtools-for-tabs`
