# docker container diff

> Inspecte les changements apportés aux fichiers ou dossiers sur le système de fichiers d'un conteneur.
> Plus d'informations : <https://docs.docker.com/reference/cli/docker/container/diff/>.

- Inspecte les changements apportés à un conteneur depuis sa création :

`docker {{[diff|container diff]}} {{conteneur}}`

- Affiche l'aide :

`docker {{[diff|container diff]}} --help`
