# atuin

> Enregistre votre historique shell dans une base de donnée.
> Peut également synchroniser votre historique chiffré entre plusieurs machines.
> Plus d'informations : <https://docs.atuin.sh/>.

- Installe atuin dans votre shell :

`eval "$(atuin init {{bash|zsh|fish}})"`

- Importe l'historique du shell par défaut :

`atuin import auto`

- Recherche dans l'historique shell une commande spécifique :

`atuin search {{commande}}`

- Inscrire un compte sur le serveur de synchronisation par défaut :

`atuin register {{[-u|--username]}} {{nom_utilisateur}} {{[-e|--email]}} {{email}} {{[-p|--password]}} {{mot_de_passe}}`

- Connexion au serveur de synchronisation par défaut :

`atuin login {{[-u|--username]}} {{nom_utilisateur}} {{[-p|--password]}} {{mot_de_passe}}`

- Synchronise l'historique avec le serveur :

`atuin sync`
