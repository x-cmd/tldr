# git gc

> Optimise le dépôt local git en nettoyant les fichiers inutiles.
> Plus d'informations : <https://git-scm.com/docs/git-gc>.

- Optimise le dépôt :

`git gc`

- Optimise le dépôt plus agressivement, plus long :

`git gc --aggressive`

- Affiche les objets à supprimer :

`git gc --no-prune`

- Supprime tout les objets trouvés sans les afficher sur la sortie standard :

`git gc --quiet`

- Affiche l'aide :

`git gc --help`
