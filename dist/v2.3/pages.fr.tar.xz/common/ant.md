# ant

> Apache Ant : outil pour construire et gérer les projets basés sur du Java.
> Plus d'informations : <https://ant.apache.org/manual/index.html>.

- Construit un projet avec le fichier de construction `build.xml` :

`ant`

- Construit un projet en utilisant un autre fichier que `build.xml` :

`ant {{[-f|-buildfile]}} {{fichier_de_construction.xml}}`

- Affiche les informations sur les cibles possibles pour ce projet :

`ant {{[-p|-projecthelp]}}`

- Affiche les informations de débogage :

`ant {{[-d|-debug]}}`

- Exécute toutes les cibles qui ne dépendent pas d'une ou plusieurs cibles en erreur :

`ant {{[-k|-keep-going]}}`
