# nix

> Un puissant gestionnaire de paquets qui rend la gestion des paquets fiable, reproductible et déclarative.
> `nix` est expérimental et doit être activé avec les fonctionnalités expérimentales.
> Certaines sous-commandes comme `build`, `develop`, `flake`, `registry`, `profile`, `search`, `repl`, `store`, `edit`, `why-depends`, etc., ont leur propre documentation d'utilisation.
> Voir aussi : `nix classic`.
> Plus d'informations : <https://nix.dev/manual/nix/stable/command-ref/new-cli/nix>.

- Active la commande `nix ` :

`mkdir {{[-p|--parents]}} ~/.config/nix; echo 'experimental-features = nix-command flakes' >~/.config/nix/nix.conf`

- Recherche un paquet dans `nixpkgs` par son nom ou sa description :

`nix search nixpkgs {{terme_recherché}}`

- Lance un terminal avec les paquets spécifiés disponibles depuis `nixpkgs` :

`nix shell {{nixpkgs#pkg1 nixpkgs#pkg2 nixpkgs#pkg3 ...}}`

- Installe des paquets depuis `nixpkgs` de manière permanente :

`nix profile install {{nixpkgs#pkg1 nixpkgs#pkg2 nixpkgs#pkg3 ...}}`

- Nettoie les chemins inutilisés dans l'espace de stockage de Nix (Nix store) pour libérer de l'espace :

`nix store gc`

- Lance un environnement interactif pour évaluer des expressions Nix :

`nix repl`

- Affiche l'aide pour une sous-commande spécifique :

`nix help {{sous-commande}}`
