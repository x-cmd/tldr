# a2dissite

> Désactive un hôte virtuel Apache sur une distribution Debian.
> Plus d'informations : <https://manned.org/a2dissite>.

- Désactive un hôte virtuel :

`sudo a2dissite {{virtual_host}}`

- N'affiche aucun message (mode silencieux) :

`sudo a2dissite {{[-q|--quiet]}} {{virtual_host}}`
