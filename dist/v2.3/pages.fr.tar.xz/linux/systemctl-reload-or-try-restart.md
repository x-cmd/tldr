# systemctl reload-or-try-restart

> Cette commande est un alias de `systemctl try-reload-or-restart`.

- Affiche la documentation de la commande originale :

`tldr systemctl try-reload-or-restart`
