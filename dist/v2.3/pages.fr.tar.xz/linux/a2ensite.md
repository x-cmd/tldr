# a2ensite

> Active un hôte virtuel Apache sur des systèmes d'exploitation (SE) basés sur Debian.
> Plus d'informations : <https://manned.org/a2ensite>.

- Active un hôte virtuel :

`sudo a2ensite {{hote_virtuel}}`

- N'affiche aucun message (mode silencieux) :

`sudo a2ensite {{[-q|--quiet]}} {{hote_virtuel}}`
