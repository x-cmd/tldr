# alien

> Convertit différents paquets d'installation vers d'autres formats.
> Voir aussi : `debtap`.
> Plus d'informations : <https://manned.org/alien>.

- Convertit un fichier d'installation spécifique vers le format Debian (extension `.deb`) :

`sudo alien {{[-d|--to-deb]}} {{chemin/vers/fichier}}`

- Convertit un fichier d'installation spécifique vers le format Red Hat (extension `.rpm`) :

`sudo alien {{[-r|--to-rpm]}} {{chemin/vers/fichier}}`

- Convertit un fichier d'installation spécifique en un fichier d'installation Slackware (extension `.tgz`) :

`sudo alien {{[-t|--to-tgz]}} {{chemin/vers/fichier}}`

- Convertit un fichier d'installation spécifique vers le format Debian et l'installe sur le système :

`sudo alien {{[-d|--to-deb]}} {{[-i|--install]}} {{chemin/vers/fichier}}`
