# a2disconf

> Désactive un fichier de configuration sur une distribution Debian.
> Plus d'informations : <https://manned.org/a2disconf>.

- Désactive un fichier de configuration :

`sudo a2disconf {{fichier_de_configuration}}`

- N'affiche aucun message (mode silencieux) :

`sudo a2disconf {{[-q|--quiet]}} {{fichier_de_configuration}}`
