# git cola

> Tampilan antarmuka grafis (GUI) untuk Git yang kuat, apik, dan intuitif.
> Informasi lebih lanjut: <https://git-cola.readthedocs.io/en/latest/git-cola.html>.

- Jalankan program GUI:

`git cola`

- Jalankan GUI pada mode perubahan (amend):

`git cola --amend`

- Jalankan dengan meminta program menanyakan repositori Git yang akan dilihat. Jika tidak didefinisikan, maka program ini akan melihat direktori saat ini:

`git cola --prompt`

- Jalankan dengan membuka repositori Git dengan alamat yang ditentukan:

`git cola {{[-r|--repo]}} {{jalan/menuju/repositori-git}}`

- Terapkan filter jalur ke dalam widget status:

`git cola {{[-s|--status-filter]}} {{filter}}`
