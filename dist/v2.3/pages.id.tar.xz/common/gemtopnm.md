# gemtopnm

> Ubah suatu berkas gambar GEM menjadi gambar PNM.
> Informasi lebih lanjut: <https://netpbm.sourceforge.net/doc/gemtopnm.html>.

- Ubah suatu berkas gambar GEM menjadi gambar PNM:

`gemtopnm {{jalan/menuju/berkas.img}} >{{path/menuju/output.pnm}}`

- Tampilkan deskripsi isi dari suatu berkas gambar GEM:

`gemtopnm {{[-d|-debug]}} {{path/menuju/berkas.img}}`

- Tampilkan versi:

`gemtopnm -version`
