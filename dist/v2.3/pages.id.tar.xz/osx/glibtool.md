# glibtool

> Perintah ini merupakan alias dari GNU `libtool`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr {{[-p|--platform]}} linux libtool`
