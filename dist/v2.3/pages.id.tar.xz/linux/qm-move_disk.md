# qm move_disk

> Perintah ini merupakan alias dari `qm disk move`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr qm disk`
