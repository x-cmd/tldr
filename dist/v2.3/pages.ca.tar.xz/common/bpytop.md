# bpytop

> Mostra informació del sistema en temps real sobre processos executant-se, amb gràfics. Similar a `gtop` i `htop`.
> Més informació: <https://github.com/aristocratos/bpytop#command-line-options>.

- Inicia bpytop:

`bpytop`

- Inicia en mode minimalista sense recuadres de memòria y xarxes:

`bpytop -m`

- Canvia a mode minimalista:

`<m>`

- Busca processos o programes executant-se:

`<f>`

- Canvia ajustaments:

`<M>`

- Mostra la versió:

`bpytop -v`
