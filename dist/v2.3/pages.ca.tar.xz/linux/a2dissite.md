# a2dissite

> Desactiva un host virtual d'Apache en sistemes operatius basats en Debian.
> Més informació: <https://manned.org/a2dissite>.

- Desactiva un host virtual:

`sudo a2dissite {{host_virtual}}`

- No mostris missatges informatius:

`sudo a2dissite {{[-q|--quiet]}} {{host_virtual}}`
