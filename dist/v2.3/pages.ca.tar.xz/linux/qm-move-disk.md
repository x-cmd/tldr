# qm move-disk

> Aquest comandament és un àlies de `qm disk move`.

- Veure documentació pel comandament original:

`tldr qm disk`
