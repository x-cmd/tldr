# a2disconf

> Desactiva un fitxer de configuració d'Apache en sistemes operatius basats en Debian.
> Més informació: <https://manned.org/a2disconf>.

- Desactiva un fitxer de configuració:

`sudo a2disconf {{fitxer_configuració}}`

- No mostris missatges informatius:

`sudo a2disconf {{[-q|--quiet]}} {{fitxer_configuració}}`
