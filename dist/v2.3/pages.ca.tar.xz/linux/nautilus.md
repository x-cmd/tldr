# nautilus

> Explorador de fitxers per defecte en l'escriptori GNOME.
> També conegut com a Fitxers.
> Vegeu també: `dolphin`, `caja`, `thunar`, `vifm`.
> Més informació: <https://manned.org/nautilus>.

- Obre Nautilus:

`nautilus`

- Obre Nautilus com a root:

`nautilus admin:/`

- Obre Nautilus en un directori específic:

`nautilus {{camí/al/directori}}`

- Obre nautilus amb un directori o fitxer específic seleccionat:

`nautilus --select {{camí/al/fitxer_o_directori}}`

- Obre Nautilus en una finestra separada:

`nautilus --new-window`

- Tanca totes les instàncies de Nautilus:

`nautilus --quit`

- Mostra ajuda:

`nautilus --help`
