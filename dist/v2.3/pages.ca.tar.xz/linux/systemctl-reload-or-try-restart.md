# systemctl reload-or-try-restart

> Aquest comandament és un àlies de `systemctl try-reload-or-restart`.

- Veure documentació pel comandament original:

`tldr systemctl try-reload-or-restart`
