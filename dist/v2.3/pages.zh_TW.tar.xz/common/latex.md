# latex

> 從 LaTeX 原始檔編譯 DVI 文件。
> 更多資訊：<https://texdoc.org/serve/tex.man1.pdf/0>。

- 編譯 DVI 文件：

`latex {{tex 檔案}}`

- 編譯 DVI 文件，指定輸出位置：

`latex -output-directory={{輸出目錄位置}} {{tex 檔案}}`

- 編譯 DVI 文件，出錯時退出：

`latex -halt-on-error {{tex 檔案}}`
