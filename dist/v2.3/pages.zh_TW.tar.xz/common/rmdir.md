# rmdir

> 移除目錄。
> 另請參閱：`rm`。
> 更多資訊：<https://www.gnu.org/software/coreutils/manual/html_node/rmdir-invocation.html>。

- 若為空目錄則移除目錄（如果目錄非空，可用 `rm -r` 移除目錄及其所包含的檔案）：

`rmdir {{目錄/完整/路徑}}`

- 移除目錄與其所有上層目錄：

`rmdir -p {{目錄/完整/路徑}}`
