# j

> 此命令為 `autojump` 的別名。

- 檢視原命令的文件：

`tldr autojump`
