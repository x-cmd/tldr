# rm

> 移除檔案或目錄。
> 另請參閱：`rmdir`, `trash`。
> 更多資訊：<https://www.gnu.org/software/coreutils/manual/html_node/rm-invocation.html>。

- 移除位於指定路徑的檔案：

`rm {{檔案一/完整/路徑 檔案二/完整/路徑 ...}}`

- 移除檔案，且每次移除都會進行確認：

`rm -i {{檔案一}} {{檔案二}}`

- 移除目錄中的所有檔案，並顯示每個檔案的移除資訊：

`rm -v {{目錄/完整/路徑/*}}`

- 遞迴移除目錄與其所有子目錄：

`rm -r {{目錄/完整/路徑}}`
