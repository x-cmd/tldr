# fossil rm

> 此命令為 `fossil delete` 的別名。

- 檢視原命令的文件：

`tldr fossil delete`
