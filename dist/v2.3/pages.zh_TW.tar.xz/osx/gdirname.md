# gdirname

> 此命令為 `dirname` 的別名。

- 檢視原命令的文件：

`tldr dirname`
