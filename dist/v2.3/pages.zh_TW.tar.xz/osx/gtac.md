# gtac

> 此命令為 `tac` 的別名。

- 檢視原命令的文件：

`tldr tac`
