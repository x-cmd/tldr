# gls

> 此命令為 `ls` 的別名。

- 檢視原命令的文件：

`tldr ls`
