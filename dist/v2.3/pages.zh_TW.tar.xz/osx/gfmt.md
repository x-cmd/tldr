# gfmt

> 此命令為 `fmt` 的別名。

- 檢視原命令的文件：

`tldr fmt`
