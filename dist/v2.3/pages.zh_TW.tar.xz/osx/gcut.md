# gcut

> 此命令為 `cut` 的別名。

- 檢視原命令的文件：

`tldr {{[-p|--platform]}} common cut`
