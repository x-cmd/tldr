# gchmod

> 此命令為 `chmod` 的別名。

- 檢視原命令的文件：

`tldr chmod`
