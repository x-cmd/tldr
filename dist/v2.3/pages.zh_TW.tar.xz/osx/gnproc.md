# gnproc

> 此命令為 `nproc` 的別名。

- 檢視原命令的文件：

`tldr nproc`
