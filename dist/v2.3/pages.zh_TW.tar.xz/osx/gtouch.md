# gtouch

> 此命令為 `touch` 的別名。

- 檢視原命令的文件：

`tldr touch`
