# gstty

> 此命令為 `stty` 的別名。

- 檢視原命令的文件：

`tldr stty`
