# rename.ul

> এই কমান্ডটি `rename.util` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr rename.util`
