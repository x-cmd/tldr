# ip6tables-restore

> এই কমান্ডটি IPv6 ফায়ারওয়ালের জন্য `iptables-restore` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr iptables-restore`
