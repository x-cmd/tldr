# pacman -F

> এই কমান্ডটি `pacman --files` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr pacman files`
