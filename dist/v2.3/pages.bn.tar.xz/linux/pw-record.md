# pw-record

> এই কমান্ডটি `pw-cat --record` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr pw-cat`
