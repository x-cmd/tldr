# lrzuntar

> এই কমান্ডটি `lrztar --decompress` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr lrztar`
