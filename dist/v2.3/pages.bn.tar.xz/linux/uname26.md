# uname26

> এই কমান্ডটি `setarch uname26` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr setarch`
