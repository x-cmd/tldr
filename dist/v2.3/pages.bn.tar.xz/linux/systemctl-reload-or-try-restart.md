# systemctl reload-or-try-restart

> এই কমান্ডটি `systemctl try-reload-or-restart` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr systemctl try-reload-or-restart`
