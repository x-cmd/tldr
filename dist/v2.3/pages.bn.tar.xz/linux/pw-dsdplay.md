# pw-dsdplay

> এই কমান্ডটি `pw-cat --playback --dsd` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr pw-cat`
