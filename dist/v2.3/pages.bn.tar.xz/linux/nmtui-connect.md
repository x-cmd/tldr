# nmtui-connect

> এই কমান্ডটি `nmtui connect` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr nmtui`
