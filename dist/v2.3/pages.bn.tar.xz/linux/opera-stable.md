# opera-stable

> এই কমান্ডটি `chromium` - এর একটি উপনাম।
> আরও তথ্য পাবেন: <https://www.opera.com/>।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr chromium`
