# linux64

> এই কমান্ডটি `setarch linux64` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr setarch`
