# impacket-getTGT

> এই কমান্ডটি `getTGT.py` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr getTGT.py`
