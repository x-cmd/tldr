# npm-rb

> এই কমান্ডটি `npm-rebuild` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr npm-rebuild`
