# gh cs

> এই কমান্ডটি `gh codespace` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr gh codespace`
