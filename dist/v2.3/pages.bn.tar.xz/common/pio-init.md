# pio init

> এই কমান্ডটি `pio project init` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr pio project`
