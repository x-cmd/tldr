# llvm-strings

> এই কমান্ডটি `strings` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr strings`
