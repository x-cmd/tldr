# pnmdepth

> এই কমান্ডটি `pamdepth` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr pamdepth`
