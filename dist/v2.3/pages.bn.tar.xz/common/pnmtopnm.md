# pnmtopnm

> এই কমান্ডটি `pamtopnm` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr pamtopnm`
