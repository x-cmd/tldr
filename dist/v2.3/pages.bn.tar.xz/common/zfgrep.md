# zfgrep

> এই কমান্ডটি `zgrep --fixed-strings` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr zgrep`
