# impacket-getST

> এই কমান্ডটি `getST.py` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr getST.py`
