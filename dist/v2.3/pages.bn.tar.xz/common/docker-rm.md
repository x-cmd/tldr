# docker rm

> এই কমান্ডটি `docker container rm` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr docker container rm`
