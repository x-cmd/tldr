# docker pull

> এই কমান্ডটি `docker image pull` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr docker image pull`
