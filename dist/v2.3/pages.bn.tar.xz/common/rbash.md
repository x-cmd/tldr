# rbash

> এই কমান্ডটি `bash --restricted` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr bash`
