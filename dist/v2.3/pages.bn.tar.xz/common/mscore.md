# mscore

> এই কমান্ডটি `musescore` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr musescore`
