# zcat

> এই কমান্ডটি `gzip --stdout --decompress` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr gzip`
