# ptpython3

> এই কমান্ডটি `ptpython` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr ptpython`
