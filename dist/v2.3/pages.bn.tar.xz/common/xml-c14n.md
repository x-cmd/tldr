# xml c14n

> এই কমান্ডটি `xml canonic` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr xml canonic`
