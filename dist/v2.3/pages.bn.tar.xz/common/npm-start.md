# npm start

> এই কমান্ডটি `npm run start` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr npm run`
