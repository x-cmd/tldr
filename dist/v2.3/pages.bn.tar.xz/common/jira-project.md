# jira project

> Jira প্রজেক্ট ম্যানেজ করুন।
> আরও তথ্য পাবেন: <https://github.com/ankitpokhrel/jira-cli#other-commands>।

- সমস্ত প্রজেক্ট তালিকাভুক্ত করুন:

`jira project {{[ls|list]}}`

- সাহায্য প্রদর্শন:

`jira project {{[-h|--help]}}`
