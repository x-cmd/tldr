# jira navigate

> এই কমান্ডটি `jira open` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr jira open`
