# llvm-objdump

> এই কমান্ডটি `objdump` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr objdump`
