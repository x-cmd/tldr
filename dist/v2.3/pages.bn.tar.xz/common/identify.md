# identify

> এই কমান্ডটি `magick identify` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr magick identify`
