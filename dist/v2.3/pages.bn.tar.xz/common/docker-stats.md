# docker stats

> এই কমান্ডটি `docker container stats` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr docker container stats`
