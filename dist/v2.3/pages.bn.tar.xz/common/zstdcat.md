# zstdcat

> এই কমান্ডটি `zstd --decompress --stdout --force` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr zstd`
