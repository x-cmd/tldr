# kite

> এই কমান্ডটি `kiterunner` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr kiterunner`
