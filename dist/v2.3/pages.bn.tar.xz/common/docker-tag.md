# docker tag

> এই কমান্ডটি `docker image tag` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr docker image tag`
