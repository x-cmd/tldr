# unlzma

> এই কমান্ডটি `xz --format lzma --decompress` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr xz`
