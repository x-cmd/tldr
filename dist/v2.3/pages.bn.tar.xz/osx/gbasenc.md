# gbasenc

> এই কমান্ডটি GNU `basenc` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr basenc`
