# gbasename

> এই কমান্ডটি GNU `basename` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr basename`
