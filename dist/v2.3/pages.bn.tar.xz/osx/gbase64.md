# gbase64

> এই কমান্ডটি GNU `base64` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr {{[-p|--platform]}} common base64`
