# SaRAcmd TeamsAddinScenario

> এই কমান্ডটি `GetHelpCmd.exe -S TeamsAddinScenario` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr gethelpcmd-teamsaddinscenario`
