# cpush

> এই কমান্ডটি `choco push` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr choco push`
