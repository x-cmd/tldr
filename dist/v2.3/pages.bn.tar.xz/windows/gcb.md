# gcb

> এই কমান্ডটি `Get-Clipboard` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr get-clipboard`
