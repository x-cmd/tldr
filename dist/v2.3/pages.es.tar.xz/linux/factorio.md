# Factorio

> Crea e inicia un servidor Factorio sin interfaz gráfica.
> Más información: <https://wiki.factorio.com/Multiplayer>.

- Crea un nuevo archivo de guardado:

`{{ruta/a}}/factorio --create {{ruta/al/archivo_guardado.zip}}`

- Inicia un servidor de Factorio:

`{{ruta/a}}/factorio --start-server {{ruta/al/archivo_guardado.zip}}`

- Crea un nuevo archivo de guardado con ajustes específicos:

`{{ruta/a}}/factorio --create {{ruta/para/guardar.zip}} --map-gen-settings {{ruta/a/map_gen_settings.json}} --map-settings {{ruta/a/map_settings.json}}`

- [Interactivo] Cierra el servidor correctamente:

`/quit`

- Muestra la ayuda:

`{{ruta/a}}/factorio {{[-h|--help]}}`
