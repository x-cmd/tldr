# distrobox-upgrade

> Actualiza uno o varios contenedores Distrobox.
> Vea también: `distrobox`.
> Más información: <https://distrobox.it/usage/distrobox-upgrade/>.

- Actualiza un contenedor usando el administrador de paquetes nativo del contenedor:

`distrobox-upgrade {{nombre_del_contenedor}}`

- Actualiza todos los contenedores utilizando los administradores de paquetes nativos de cada contenedor:

`distrobox-upgrade {{[-a|--all]}}`

- Actualiza contenedores específicos a través del administrador de paquetes nativo de cada contenedor:

`distrobox-upgrade {{contenedor1 contenedor2 ...}}`
