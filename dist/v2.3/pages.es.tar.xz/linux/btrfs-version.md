# btrfs version

> Muestra la versión de btrfs-progs.
> Más información: <https://btrfs.readthedocs.io/en/latest/btrfs.html>.

- Muestra ayuda:

`btrfs {{[v|version]}} --help`

- Muestra la versión de btrfs-progs:

`btrfs {{[v|version]}}`
