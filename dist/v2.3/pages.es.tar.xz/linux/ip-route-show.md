# ip route show

> Este comando es un alias de `ip route list`.

- Vea la documentación del comando original:

`tldr ip route list`
