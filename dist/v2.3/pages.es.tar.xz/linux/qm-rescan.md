# qm rescan

> Este comando es un alias de `qm disk rescan`.

- Vea la documentación del comando original:

`tldr qm disk`
