# qm pending

> Obtiene la configuración de la máquina virtual con valores actuales y pendientes.
> Más información: <https://pve.proxmox.com/pve-docs/qm.1.html#cli_qm_pending>.

- Obtiene la configuración de la máquina virtual de una máquina virtual (mv) específica:

`qm {{[p|pending]}} {{100}}`
