# shntool split

> Este comando es un alias de `shnsplit`.

- Vea la documentación del comando original:

`tldr shnsplit`
