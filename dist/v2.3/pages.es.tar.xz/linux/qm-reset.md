# qm reset

> Reinicia una máquina virtual en el administrador de máquinas virtuales QEMU/KVM.
> Más información: <https://pve.proxmox.com/pve-docs/qm.1.html#cli_qm_reset>.

- Restablece una máquina virtual:

`qm reset {{100}}`

- Reinicia una máquina virtual y omite cualquier bloqueo (solo el root puede usar esta opción):

`qm reset {{100}} --skiplock {{true}}`
