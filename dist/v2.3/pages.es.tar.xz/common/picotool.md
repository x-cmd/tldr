# picotool

> Gestiona las placas Raspberry Pi Pico.
> Más información: <https://github.com/raspberrypi/picotool#overview>.

- Muestra información sobre el programa cargado actualmente en un Pico:

`picotool info`

- Carga un binario en un Pico:

`picotool load {{ruta/al/binario}}`

- Convierte un archivo ELF o BIN a UF2:

`picotool uf2 convert {{ruta/a/elf_o_bin}} {{ruta/a/salida}}`

- Reinicia un Pico:

`picotool reboot`

- Lista todos los registros conocidos:

`picotool otp list`

- Muestra la ayuda:

`picotool help`

- Muestra la versión:

`picotool version`
