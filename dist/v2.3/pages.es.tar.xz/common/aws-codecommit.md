# aws codecommit

> Un servicio de control de versión capaz de alojar repositorios de Git privados.
> Más información: <https://docs.aws.amazon.com/cli/latest/reference/codecommit/>.

- Muestra la ayuda:

`aws codecommit help`

- Muestra la ayuda de un comando:

`aws codecommit {{comando}} help`
