# basename

> Remueve nombres de directorios al inicio de una ruta.
> Vea también: `dirname`.
> Más información: <https://www.gnu.org/software/coreutils/manual/html_node/basename-invocation.html>.

- Imprime el nombre de un fichero a partir de su ruta:

`basename {{ruta/al/archivo}}`

- Imprime el componente terminal de la ruta de un directorio:

`basename {{ruta/al/directorio}}`

- Imprime el nombre de un fichero sin un sufijo:

`basename {{ruta/al/archivo}} {{sufijo}}`
