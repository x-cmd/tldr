# git am

> Aplica archivos de parche. Útil cuando se reciben commits por correo electrónico.
> Vea también: `git format-patch`.
> Más información: <https://git-scm.com/docs/git-am>.

- Aplica un archivo de parche:

`git am {{ruta/al/archivo.patch}}`

- Aplica un archivo de parche remoto:

`curl {{[-L|--location]}} {{https://example.com/file.patch}} | git am`

- Aborta el proceso de aplicar un archivo de parche:

`git am --abort`

- Aplica todo lo posible de un archivo de parche y guarda los fragmentos fallidos para rechazar archivos:

`git am --reject {{ruta/al/archivo.patch}}`
