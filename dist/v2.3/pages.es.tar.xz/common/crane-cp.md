# crane cp

> Este comando es un alias de `crane copy`.

- Vea la documentación del comando original:

`tldr crane copy`
