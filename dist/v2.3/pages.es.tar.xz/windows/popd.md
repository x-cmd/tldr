# popd

> Cambia el directorio actual al directorio almacenado por el comando `pushd`.
> Vea también: `pushd`.
> Más información: <https://learn.microsoft.com/windows-server/administration/windows-commands/popd>.

- Cambia al directorio en la parte superior de la pila:

`popd`
