# rdpsign

> Una herramienta para firmar archivos del Protocolo de Escritorio Remoto (RDP).
> Más información: <https://learn.microsoft.com/windows-server/administration/windows-commands/rdpsign>.

- Firma un archivo RDP:

`rdpsign {{ruta\al\archivo.rdp}}`

- Firma un archivo RDP utilizando un hash sha256 específico:

`rdpsign {{ruta\al\archivo.rdp}} /sha265 {{hash}}`

- Habilita salida silenciosa:

`rdpsign {{ruta\al\archivo.rdp}} /q`

- Muestra advertencias, mensajes y estados detallados:

`rdpsign {{ruta\al\archivo.rdp}} /v`

- Prueba la firma mostrando la salida en `stdout` sin actualizar el archivo:

`rdpsign {{ruta\al\archivo.rdp}} /l`
