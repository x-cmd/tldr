# rpcinfo

> Lista programas vía RPC en computadoras remotas.
> Más información: <https://learn.microsoft.com/windows-server/administration/windows-commands/rpcinfo>.

- Lista todos los programas registrados en la computadora local:

`rpcinfo`

- Lista todos los programas registrados en una computadora remota:

`rpcinfo /p {{nombre_de_computadora}}`

- Llama a un programa específico en una computadora remota usando TCP:

`rpcinfo /t {{nombre_de_computadora}} {{nombre_del_programa}}`

- Llama a un programa específico en una computadora remota usando UDP:

`rpcinfo /u {{nombre_de_computadora}} {{nombre_del_programa}}`
