# move

> Mueve o renombra archivos y directorios.
> En PowerShell, este comando es un alias de `Move-Item`. Esta documentación se basa en la versión de `move` del Símbolo del sistema (`cmd`).
> Más información: <https://learn.microsoft.com/windows-server/administration/windows-commands/move>.

- Vea la documentación del comando equivalente de PowerShell:

`tldr move-item`

- Renombra un archivo o directorio cuando el destino no es un directorio existente:

`move {{ruta\al\origen}} {{ruta\al\destino}}`

- Mueve un archivo o directorio a un directorio existente:

`move {{ruta\al\origen}} {{ruta\al\directorio_existente}}`

- Mueve un archivo o directorio entre unidades:

`move {{C:\ruta\al\origen}} {{D:\ruta\al\destino}}`

- No solicita confirmación antes de sobrescribir archivos existentes:

`move /Y {{ruta\al\origen}} {{ruta\al\directorio_existente}}`

- Solicita confirmación antes de sobrescribir archivos existentes, independientemente de los permisos de archivo:

`move /-Y {{ruta\al\origen}} {{ruta\al\directorio_existente}}`
