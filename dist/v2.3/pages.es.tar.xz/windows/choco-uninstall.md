# choco uninstall

> Desinstala paquetes con Chocolatey.
> Más información: <https://docs.chocolatey.org/en-us/choco/commands/uninstall/>.

- Desinstala uno o más paquetes:

`choco uninstall {{paquete1 paquete2 ...}}`

- Desinstala una versión específica de un paquete:

`choco uninstall {{paquete}} --version {{versión}}`

- Confirma automáticamente todos los mensajes:

`choco uninstall {{paquete}} {{[-y|--yes]}}`

- Elimina todas las dependencias al desinstalar:

`choco uninstall {{paquete}} {{[-x|--remove-dependencies]}}`

- Desinstala todos los paquetes:

`choco uninstall all`
