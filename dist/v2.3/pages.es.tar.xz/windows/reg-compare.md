# reg compare

> Compara claves y sus valores en el registro.
> Más información: <https://learn.microsoft.com/windows-server/administration/windows-commands/reg-compare>.

- Compara todos los valores bajo una clave específica con otra clave:

`reg compare {{nombre_clave1}} {{nombre_clave2}}`

- Compara un [v]alor específico bajo dos claves:

`reg compare {{nombre_clave1}} {{nombre_clave2}} /v {{valor}}`

- Compara todos los [s]ubclaves y valores para dos claves:

`reg compare {{nombre_clave1}} {{nombre_clave2}} /s`

- Solo genera un resultad[o] con las coincidencias ([s]imilares) entre las claves especificadas:

`reg compare {{nombre_clave1}} {{nombre_clave2}} /os`

- Genera un resultad[o] con las diferencias y coincidencias ([a]mbas) entre las claves especificadas:

`reg compare {{nombre_clave1}} {{nombre_clave2}} /oa`

- Compara dos claves, [o]utputando [n]ada:

`reg compare {{nombre_clave1}} {{nombre_clave2}} /on`
