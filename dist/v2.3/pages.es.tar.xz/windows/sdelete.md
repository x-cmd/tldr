# sdelete

> Elimina de forma segura archivos/directorios del disco, o limpia el espacio libre en un volumen/disco físico.
> Más información: <https://learn.microsoft.com/sysinternals/downloads/sdelete>.

- Elimina archivos con 3 [p]asadas:

`sdelete -p 3 {{ruta\al\archivo1 ruta\al\archivo2 ...}}`

- Elimina carpetas y sus [s]ubdirectorios con 1 pasada (por defecto):

`sdelete -s {{ruta\al\directorio1 ruta\al\directorio2 ...}}`

- Limpia el espacio libre del volumen D: con 3 [p]asadas:

`sdelete -p 3 D:`

- Limpia el espacio libre con ceros [z] del disco físico 2, que no debe contener volúmenes a limpiar:

`sdelete -z 2`
