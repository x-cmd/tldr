# color

> Establece los colores de primer plano y fondo de la consola.
> Más información: <https://learn.microsoft.com/windows-server/administration/windows-commands/color>.

- Establece los colores de la consola a los valores predeterminados:

`color`

- Lista los valores de color disponibles y la información detallada:

`color /?`

- Establece el primer plano y el fondo de la consola a un color específico utilizando números hexadecimales (`1-9,a-f`):

`color {{código_de_primer_plano}}{{código_de_fondo}}`
