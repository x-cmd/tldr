# repair-bde

> Intenta reparar o descifra un volumen cifrado con BitLocker dañado.
> Más información: <https://learn.microsoft.com/windows-server/administration/windows-commands/repair-bde>.

- Intenta reparar un volumen especificado:

`repair-bde {{C:}}`

- Intenta reparar un volumen especificado y envía la salida a otro volumen:

`repair-bde {{C:}} {{D:}}`

- Intenta reparar un volumen especificado usando el archivo de clave de recuperación proporcionado:

`repair-bde {{C:}} -RecoveryKey {{ruta\al\archivo.bek}}`

- Intenta reparar un volumen especificado usando la contraseña numérica de recuperación proporcionada:

`repair-bde {{C:}} -RecoveryPassword {{contraseña}}`

- Intenta reparar un volumen especificado usando la contraseña proporcionada:

`repair-bde {{C:}} -Password {{contraseña}}`

- Intenta reparar un volumen especificado usando el paquete de claves proporcionado:

`repair-bde {{C:}} -KeyPackage {{ruta\al\directorio}}`

- Registra toda la salida en un archivo específico:

`repair-bde {{C:}} -LogFile {{ruta\al\archivo}}`

- Muestra la ayuda:

`repair-bde /?`
