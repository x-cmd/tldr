# choco apikey

> Gestiona claves API para fuentes de Chocolatey.
> Más información: <https://docs.chocolatey.org/en-us/create/commands/api-key/>.

- Muestra una lista de fuentes y sus claves API:

`choco apikey`

- Muestra una fuente específica y su clave API:

`choco apikey {{[-s|--source]}} "{{url_fuente}}"`

- Establece una clave API para una fuente:

`choco apikey {{[-s|--source]}} "{{url_fuente}}" {{[-k|--api-key]}} "{{clave_api}}"`

- Elimina una clave API para una fuente:

`choco apikey remove {{[-s|--source]}} "{{url_fuente}}"`
