# Get-Alias

> Lista y obtiene alias de comandos en la sesión actual de PowerShell.
> Este comando solo se puede ejecutar en PowerShell.
> Más información: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/get-alias>.

- Lista todos los alias en la sesión actual:

`Get-Alias`

- Obtiene el nombre del comando asociado al alias:

`Get-Alias {{alias_de_comando}}`

- Lista todos los alias asignados a un comando específico:

`Get-Alias -Definition {{comando}}`

- Lista alias que comienzan con `abc`, excluyendo aquellos que terminan en `def`:

`Get-Alias {{abc}}* -Exclude *{{def}}`
