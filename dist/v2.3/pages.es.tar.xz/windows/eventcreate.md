# eventcreate

> Crea entradas personalizadas en el registro de eventos.
> Los ID de evento pueden ser cualquier número entre 1 y 1000.
> Más información: <https://learn.microsoft.com/windows-server/administration/windows-commands/eventcreate>.

- Crea un nuevo evento con un ID dado (1-1000) en el registro:

`eventcreate /t {{success|error|warning|information}} /id {{1..1000}} /d "{{mensaje}}"`

- Crea un evento en un registro de eventos específico:

`eventcreate /l {{nombre_del_registro}} /t {{tipo}} /id {{id}} /d "{{mensaje}}"`

- Crea un evento con una fuente específica:

`eventcreate /so {{nombre_de_la_fuente}} /t {{tipo}} /id {{id}} /d "{{mensaje}}"`

- Crea un evento en el registro de eventos de una máquina remota:

`eventcreate /s {{nombre_del_host}} /u {{usuario}} /p {{contraseña}} /t {{tipo}} /id {{id}} /d "{{mensaje}}"`
