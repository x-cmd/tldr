# diskpart

> Administrador de discos, volúmenes y particiones.
> Más información: <https://learn.microsoft.com/windows-server/administration/windows-commands/diskpart>.

- Ejecuta diskpart por sí mismo en un símbolo del sistema administrativo para ingresar a su línea de comandos:

`diskpart`

- Lista todos los discos:

`list disk`

- Selecciona un volumen:

`select volume {{volúmen}}`

- Asigna una letra de unidad al volumen seleccionado:

`assign letter {{letra}}`

- Crea una nueva partición:

`create partition primary`

- Activa el volumen seleccionado:

`active`

- Sale de diskpart:

`exit`
