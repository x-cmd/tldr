# md5

> Calcula sumas de comprobación criptográficas MD5.
> Más información: <https://keith.github.io/xcode-man-pages/md5.1.html>.

- Calcula la suma de comprobación MD5 de un archivo:

`md5 {{ruta/al/archivo}}`

- Calcula sumas de comprobación MD5 para varios archivos:

`md5 {{ruta/al/archivo1 ruta/al/archivo2 ...}}`

- Obtén sólo la suma de comprobación MD5 (sin nombre de archivo):

`md5 -q {{ruta/al/archivo}}`

- Imprime una suma de comprobación de la cadena dada:

`md5 -s "{{cadena}}"`
