# tag

> Edita etiquetas en archivos de Mac OS X (10.9 Mavericks y superior).
> Más información: <https://github.com/jdberry/tag#usage>.

- Añade etiquetas a un archivo:

`tag {{[-a|--add]}} {{nombre_etiqueta1,nombre_etiqueta2,...}} {{ruta/al/archivo}}`

- Elimina una etiqueta:

`tag {{[-r|--remove]}} {{nombre_etiqueta}} {{ruta/al/archivo}}`

- Elimina todas las etiquetas de un archivo:

`tag {{[-r|--remove]}} \* {{ruta/al/archivo}}`

- Muestra todos los archivos con una etiqueta determinada:

`tag {{[-m|--match]}} {{nombre_de_la_etiqueta}}`
