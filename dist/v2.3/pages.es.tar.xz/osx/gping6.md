# gping6

> Este comando es un alias de `ping6`.

- Vea la documentación del comando original:

`tldr ping6`
