# llvm-g++

> Ova komanda je pseudonim za `clang++`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr clang++`
