# ypchfn

> 此命令为 `chpass` 的别名。

- 查看原命令的文档：

`tldr chpass`
