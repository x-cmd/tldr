# gcut

> 此命令为 `cut` 的别名。

- 查看原命令的文档：

`tldr {{[-p|--platform]}} common cut`
