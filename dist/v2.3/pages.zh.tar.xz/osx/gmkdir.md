# gmkdir

> 此命令为 `mkdir` 的别名。

- 查看原命令的文档：

`tldr mkdir`
