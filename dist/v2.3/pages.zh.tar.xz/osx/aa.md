# aa

> 此命令为 `yaa` 的别名。

- 查看原命令的文档：

`tldr yaa`
