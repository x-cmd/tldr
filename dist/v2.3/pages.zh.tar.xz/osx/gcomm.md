# gcomm

> 此命令为 `comm` 的别名。

- 查看原命令的文档：

`tldr comm`
