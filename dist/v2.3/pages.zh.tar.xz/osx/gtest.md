# gtest

> 此命令为 `test` 的别名。

- 查看原命令的文档：

`tldr test`
