# gstty

> 此命令为 `stty` 的别名。

- 查看原命令的文档：

`tldr stty`
