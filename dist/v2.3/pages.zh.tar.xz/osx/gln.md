# gln

> 此命令为 `ln` 的别名。

- 查看原命令的文档：

`tldr ln`
