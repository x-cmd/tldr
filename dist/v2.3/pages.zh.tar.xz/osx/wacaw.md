# wacaw

> 一个用于 macOS 的小命令行工具，允许您从连接的摄像头捕获静止图片和视频。
> 更多信息：<https://webcam-tools.sourceforge.net/#parameters>。

- 从网络摄像机拍照：

`wacaw {{文件名}}`

- 录制视频：

`wacaw --video {{文件名}} {{[-D|--duration]}} {{录制多少秒}}`

- 用自定义分辨率拍照：

`wacaw {{[-x|--width]}} {{宽}} {{[-y|--height]}} {{高}} {{文件名}}`

- 将刚拍摄的图像复制到剪贴板：

`wacaw --to-clipboard`

- 可用设备列表：

`wacaw {{[-L|--list-devices]}}`
