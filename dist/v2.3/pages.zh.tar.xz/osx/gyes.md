# gyes

> 此命令为 `yes` 的别名。

- 查看原命令的文档：

`tldr yes`
