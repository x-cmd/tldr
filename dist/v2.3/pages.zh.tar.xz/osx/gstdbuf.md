# gstdbuf

> 此命令为 `stdbuf` 的别名。

- 查看原命令的文档：

`tldr stdbuf`
