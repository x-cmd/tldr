# gdirname

> 此命令为 `dirname` 的别名。

- 查看原命令的文档：

`tldr dirname`
