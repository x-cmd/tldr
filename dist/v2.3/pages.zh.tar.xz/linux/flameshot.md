# flameshot

> 带有 GUI 界面的 Screenshot 工具。
> 支持基本的图像编辑，例如文本，形状，颜色和 imgur。
> 更多信息：<https://flameshot.org/docs/advanced/commandline-options/>。

- 全屏截图：

`flameshot full`

- 交互式截图：

`flameshot gui`

- 截图并保存到特定的路径：

`flameshot gui {{[-p|--path]}} {{路径/到/目录}}`

- 简单模式下交互式截图：

`flameshot launcher`

- 指定屏幕截图：

`flameshot screen {{[-n|--number]}} {{2}}`

- 截图并打印到标准输出：

`flameshot gui {{[-r|--raw]}}`

- 截图并复制到剪切板：

`flameshot gui {{[-c|--clipboard]}}`

- 延迟指定毫秒时间截图：

`flameshot full {{[-d|--delay]}} {{5000}}`
