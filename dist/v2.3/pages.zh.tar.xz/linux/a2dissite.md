# a2dissite

> 在基于 Debian 的操作系统上禁用 Apache 虚拟主机。
> 更多信息：<https://manned.org/a2dissite>。

- 禁用虚拟主机：

`sudo a2dissite {{虚拟主机名}}`

- 不显示信息性消息：

`sudo a2dissite {{[-q|--quiet]}} {{虚拟主机名}}`
