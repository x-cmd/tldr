# touch

> 创建文件并设置访问/修改时间。
> 更多信息：<https://www.gnu.org/software/coreutils/manual/html_node/touch-invocation.html>。

- 创建指定的文件：

`touch {{路径/到/文件1 路径/到/文件2 ...}}`

- 将文件的访问(a)或修改时间(m)设置为当前时间，如果文件不存在则不创建(-c)：

`touch {{[-c|--no-create]}} -{{a|m}} {{路径/到/文件1 路径/到/文件2 ...}}`

- 将文件时间(-t)设置为指定值，如果文件不存在则不创建(-c)：

`touch {{[-c|--no-create]}} -t {{YYYYMMDDHHMM.SS}} {{路径/到/文件1 路径/到/文件2 ...}}`

- 将文件时间设置为另一文件(-r,即文件 3)的时间，如果文件不存在则不创建(-c)：

`touch {{[-c|--no-create]}} {{[-r|--reference]}} {{路径/到/文件3}} {{路径/到/文件1 路径/到/文件2 ...}}`
