# autojump

> 快速跳转，访问次数最多的文件夹优先。
> 使用 `j`、`jc`、和 `jo` 作为别名。
> 另请参阅：`bashmarks`。
> 更多信息：<https://github.com/wting/autojump#name>。

- 跳转到包含指定通配符的目录：

`j {{通配符表达式}}`

- 跳转到包含指定通配符的目录的下一级：

`jc {{通配符表达式}}`

- 使用系统文件管理器，打开指定的目录：

`jo {{通配符表达式}}`

- 从 autojump 数据库中删除不存在的目录：

`j --purge`

- 展示 autojump 数据库数据：

`j {{[-s|--stat]}}`
