# yek

> 将一个代码仓库或目录序列化为适合 LLM 使用的单个文件（基于 Rust 的快速 repomapper 工具）。
> 更多信息：<https://github.com/bodo-run/yek#usage>。

- 序列化当前目录并将输出写入临时文件（打印文件路径）：

`yek`

- 序列化指定目录并将输出写入目标目录：

`yek {{路径/到/目录1 路径/到/目录2 ...}} --output-dir {{路径/到/输出目录}}`

- 处理多个文件或使用通配符模式（请用引号包裹通配符，以避免 shell 展开）：

`yek "{{路径/到/目录/**/*.rs}}" "{{路径/到/目录/**/*.md}}"`

- 将基于 token 的输出大小限制为 128k tokens：

`yek {{路径/到/目录}} --tokens 128k`

- 以字节为单位限制最大输出大小，并显式指定输出文件名：

`yek {{路径/到/目录}} --max-size {{100KB}} --output-name {{yek-output.txt}}`

- 以流式 JSON 格式输出：

`yek {{路径/到/目录}} --json`

- 在输出中包含目录树结构头部：

`yek {{路径/到/目录}} --tree-header`
