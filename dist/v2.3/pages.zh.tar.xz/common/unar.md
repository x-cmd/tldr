# unar

> 从归档文件中提取内容。
> 更多信息：<https://manned.org/unar>。

- 提取一个归档文件到当前目录：

`unar {{归档文件}}`

- 提取一个归档文件到指定目录：

`unar {{[-o|-output-directory]}} {{路径/到/目录}} {{归档文件}}`

- 如果要提取的文件已经存在，则总是覆盖：

`unar {{[-f|-force-overwrite]}} {{归档文件}}`

- 如果要提取的文件已经存在，则总是重命名：

`unar {{[-r|-force-rename]}} {{归档文件}}`

- 如果要提取的文件已经存在，则总是跳过：

`unar {{[-s|-force-skip]}} {{归档文件}}`
