# joe

> Joe 自己的文本编辑器。
> 更多信息：<https://joe-editor.sourceforge.io/4.6/man.html>。

- 在 JOE 中打开一个新文件：

`joe`

- 打开一个指定文件：

`joe {{路径/到/文件}}`

- 打开一个指定文件，并将光标定位在指定的行：

`joe +{{行号}} {{路径/到/文件}}`

- 以只读模式打开一个指定文件：

`joe -rdonly {{路径/到/文件}}`
