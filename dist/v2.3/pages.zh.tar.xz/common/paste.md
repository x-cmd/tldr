# paste

> 合并文件行。
> 更多信息：<https://www.gnu.org/software/coreutils/manual/html_node/paste-invocation.html>。

- 将所有行合并为一行，使用 tab 作为分隔符：

`paste {{[-s|--serial]}} {{路径/到/文件}}`

- 使用指定的分隔符将所有行合并为一行：

`paste {{[-s|--serial]}} {{[-d|--delimiters]}} {{分隔符}} {{路径/到/文件}}`

- 并排合并两个文件，每个文件以 tab 分隔为单独的列：

`paste {{路径/到/文件1}} {{路径/到/文件2}}`

- 并排合并两个文件，每个文件以指定的分隔符分隔为单独的列：

`paste {{[-d|--delimiters]}} {{分隔符}} {{路径/到/文件1}} {{路径/到/文件2}}`

- 将两个文件中的所有行，交替合并：

`paste {{[-d|--delimiters]}} '\n' {{路径/到/文件1}} {{路径/到/文件2}}`
