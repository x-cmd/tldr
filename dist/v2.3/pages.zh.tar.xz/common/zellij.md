# zellij

> 带有内置功能的终端复用器。
> 另请参阅：`tmux`, `screen`, `herdr`。
> 更多信息：<https://zellij.dev/documentation/>。

- 启动一个新的命名会话：

`zellij {{[-s|--session]}} {{名称}}`

- 列出现有会话：

`zellij {{[ls|list-sessions]}}`

- 附加到最近使用的会话：

`zellij {{[a|attach]}}`

- 打开一个新窗格（在 zellij 会话中）：

`<Alt n>`

- 从当前会话分离（在 zellij 会话中）：

`<Ctrl o><d>`
