# cargo doc

> 构建 Rust 软件包的文档。
> 更多信息：<https://doc.rust-lang.org/cargo/commands/cargo-doc.html>。

- 为当前项目及所有依赖项构建文档：

`cargo {{[d|doc]}}`

- 不为依赖项构建文档：

`cargo {{[d|doc]}} --no-deps`

- 构建并在浏览器中打开文档：

`cargo {{[d|doc]}} --open`

- 构建并查看特定软件包的文档：

`cargo {{[d|doc]}} --open {{[-p|--package]}} {{软件包}}`
