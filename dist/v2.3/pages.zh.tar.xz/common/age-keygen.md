# age-keygen

> 生成 `age` 密钥对。
> 另请参阅：`age`, `age-inspect`。
> 更多信息：<https://manned.org/age-keygen>。

- 生成密钥对，将其保存到未加密文件，并将公钥打印到标准输出：

`age-keygen {{[-o|--output]}} {{路径/到/文件}}`

- 将身份转换为接收者，并将公钥打印到标准输出：

`age-keygen -y {{路径/到/文件}}`
