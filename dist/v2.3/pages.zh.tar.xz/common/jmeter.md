# jmeter

> 开源的 Java 应用程序，旨在对功能行为进行负载测试并衡量性能。
> 更多信息：<https://jmeter.apache.org/usermanual/get-started.html#options>。

- 在非 GUI 模式下运行指定的测试计划：

`jmeter {{[-n|--nongui]}} {{[-t|--testfile]}} {{路径/到/文件.jmx}}`

- 在非 GUI 模式下使用指定的日志文件运行测试计划：

`jmeter {{[-n|--nongui]}} {{[-t|--testfile]}} {{路径/到/文件.jmx}} {{[-l|--logfile]}} {{路径/到/日志文件.jtl}}`

- 在非 GUI 模式下使用指定代理运行测试计划：

`jmeter {{[-n|--nongui]}} {{[-t|--testfile]}} {{路径/到/文件.jmx}} {{[-H-|--proxyHost]}} {{127.0.0.1}} {{[-P|--proxyPort]}} {{8888}}`

- 在非 GUI 模式下使用指定的 JMeter 属性运行测试计划：

`jmeter {{[-n|--nongui]}} {{[-t|--testfile]}} {{路径/到/文件.jmx}} {{[-J|--jmeterproperty]}} {{键}}='{{值}}'`
