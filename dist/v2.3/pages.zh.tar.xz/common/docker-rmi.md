# docker rmi

> 此命令为 `docker image rm` 的别名。

- 查看原命令的文档：

`tldr docker image rm`
