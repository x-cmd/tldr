# rmdir

> 删除一个目录。
> 另请参阅：`rm`。
> 更多信息：<https://www.gnu.org/software/coreutils/manual/html_node/rmdir-invocation.html>。

- 删除空目录，使用 `rm -r` 删除非空目录：

`rmdir {{路径/到/目录}}`

- 删除目标及其父目录（对嵌套的目录有用）：

`rmdir -p {{路径/到/目录}}`
