# minetestserver

> 此命令为 `luanti --server` 的别名。

- 查看原命令的文档：

`tldr luanti`
