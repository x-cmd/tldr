# bg

> 恢复被挂起的任务（如. 使用 `<Ctrl z>`），使它们在后台运行。
> 另请参阅：`jobs`, `fg`, `disown`。
> 更多信息：<https://www.gnu.org/software/bash/manual/bash.html#index-bg>。

- 恢复最近被挂起的任务，在后台运行：

`bg`

- 恢复特定的任务（使用 `jobs -l` 可以获取任务 ID）并在后台运行：

`bg %{{job_id}}`
