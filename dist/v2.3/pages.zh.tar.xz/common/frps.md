# frps

> 快速建立反向代理服务。
> 属于 `frp` 的一部分。
> 更多信息：<https://github.com/fatedier/frp>。

- 使用默认配置文件启动服务（假定当前目录中存在 `frps.ini`）：

`frps`

- 使用新的 TOML 配置文件启动服务：

`frps {{[-c|--config]}} {{路径/到/frps.toml}}`

- 使用指定的配置文件启动服务：

`frps {{[-c|--config]}} {{路径/到/文件}}`

- 检查配置文件的有效性：

`frps verify {{[-c|--config]}} {{路径/到/文件}}`

- 生成 Bash、fish、PowerShell 或 Zsh 的自动补全脚本：

`frps completion {{bash|fish|powershell|zsh}}`

- 显示版本：

`frps {{[-v|--version]}}`
