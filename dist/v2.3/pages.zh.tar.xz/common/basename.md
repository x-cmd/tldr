# basename

> 移除一个路径的目录部分字符。
> 另请参阅：`dirname`。
> 更多信息：<https://www.gnu.org/software/coreutils/manual/html_node/basename-invocation.html>。

- 仅显示文件名：

`basename {{路径/到/文件}}`

- 显示路径字符最右边表示目录的字符：

`basename {{路径/到/目录/}}`

- 展示无后缀的文件名称：

`basename {{路径/到/文件}} {{后缀}}`
