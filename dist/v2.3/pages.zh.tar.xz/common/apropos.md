# apropos

> 在 manpages 中搜索，例如查找一个新命令。
> 另请参阅：`man`。
> 更多信息：<https://manned.org/apropos>。

- 使用`regex`式搜索关键字：

`apropos {{正则表达式}}`

- 搜索时不限制输出到终端宽度：

`apropos {{[-l|--long]}} {{正则表达式}}`

- 搜索与给定的所有表达式都匹配的页面：

`apropos {{正则表达式_1}} {{[-a|--and]}} {{正则表达式_2}} {{[-a|--and]}} {{正则表达式_3}}`
