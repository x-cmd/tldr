# bashmarks

> 使用一个字母的命令，保存或者跳转到常用的目录。
> 另请参阅：`autojump`。
> 更多信息：<https://github.com/huyng/bashmarks#shell-commands>。

- 可访问书签清单：

`l`

- 保存当前目录到某书签里：

`s {{书签名}}`

- 跳转到指定书签：

`g {{书签名}}`

- 打印书签目录内容：

`p {{书签名}}`

- 删除书签：

`d {{书签名}}`
