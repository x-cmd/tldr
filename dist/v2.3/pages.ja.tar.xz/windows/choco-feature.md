# choco feature

> Chocolateyで機能を操作します。
> もっと詳しく: <https://docs.chocolatey.org/en-us/choco/commands/feature/>。

- 利用可能な機能のリストを表示します:

`choco feature list`

- 機能を有効にします:

`choco feature enable --name {{名}}`

- 機能を無効にします:

`choco feature disable --name {{名}}`
