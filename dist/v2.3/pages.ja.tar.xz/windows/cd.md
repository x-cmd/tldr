# cd

> 現在の作業ディレクトリの名前を表示するか、現在の作業ディレクトリを変更します。
> 詳細情報: <https://learn.microsoft.com/windows-server/administration/windows-commands/cd>。

- 同じドライブ内のディレクトリに移動します:

`cd {{ディレクトリパス}}`

- 現在のディレクトリの名前を表示します:

`cd`

- 現在のディレクトリの親に移動します:

`cd ..`

- 別のドライブのディレクトリに移動します:

`cd {{ディレクトリパス}} /d`
