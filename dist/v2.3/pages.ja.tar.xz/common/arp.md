# arp

> システムのARPキャッシュを表示し、操作します。
> 詳細情報: <https://manned.org/arp.8>。

- 現在のARPテーブルを表示する:

`arp -a`

- 特定のエントリを削除([d]elete)する:

`arp -d {{アドレス}}`

- ARPテーブルに新しいエントリを追加([s]et up)する:

`arp -s {{アドレス}} {{macアドレス}}`
