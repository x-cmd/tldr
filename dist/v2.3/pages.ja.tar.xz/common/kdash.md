# kdash

> ターミナル上でKubernetesのダッシュボードを作成するためのコマンドラインインターフェイス。
> 詳細情報: <https://github.com/kdash-rs/kdash/#usage>。

- ダッシュボードの起動:

`kdash`

- デバッグモードで起動しログをファイルに書き込む:

`kdash {{[-d|--debug]}}`

- ティックレートを設定する:

`kdash {{[-t|--tick-rate]}} {{100}}`

- ポーリングレートを設定する(ポーリングレートはティックレートの倍数である必要があります):

`kdash {{[-t|--tick-rate]}} {{200}} {{[-p|--poll-rate]}} {{400}}`
