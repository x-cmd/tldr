# claude

> コードベースを理解し、自然言語コマンドを通じてより速くコーディングできるようサポートするエージェント型コーディングツールです。
> 詳細情報: <https://code.claude.com/docs/en/cli-reference>。

- プロンプトを指定して実行する:

`claude prompt`

- `claude`を更新する:

`claude update`

- 設定されたMCPサーバ一覧を取得する:

`claude mcp list`

- 一つのコミットでコマンドを作成:

`claude commit`

- 設定を取得する:

`claude config list`
