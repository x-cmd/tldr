# uname

> 現在のマシンとその上で動作しているオペレーティングシステムの詳細を表示します。
> 参照: `lsb_release`。
> 詳細情報: <https://www.gnu.org/software/coreutils/manual/html_node/uname-invocation.html>。

- カーネル名を表示する:

`uname`

- システムアーキテクチャとプロセッサ情報を表示:

`uname --machine --processor`

- カーネル名、カーネルリリース名、カーネルバージョンを表示:

`uname --kernel-name --kernel-release --kernel-version`

- システムのホスト名を表示する:

`uname --nodename`

- 利用可能な全てのシステム情報を表示:

`uname --all`
