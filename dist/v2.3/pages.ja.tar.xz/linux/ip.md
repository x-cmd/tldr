# ip

> ルーティング、デバイス、ポリシールーティング、トンネルの表示/操作。
> `address` のようないくつかのサブコマンドには、使用方法についての独自のドキュメントがあります。
> 詳細情報: <https://manned.org/ip.8>。

- インターフェースの詳細情報を表示する:

`ip {{[a|address]}}`

- 簡単なネットワークレイヤの情報を持つインターフェースを一覧表示する:

`ip {{[-br|-brief]}} {{[a|address]}}`

- リンク層の簡単な情報を持つインターフェースを一覧表示する:

`ip {{[-br|-brief]}} {{[l|link]}}`

- ルーティングテーブルを表示する:

`ip {{[r|route]}}`

- ネイバー(ARP テーブル)を表示する:

`ip {{[n|neighbor]}}`

- インターフェースを up/down する:

`sudo ip {{[l|link]}} {{[s|set]}} {{インターフェース}} {{up|down}}`

- インターフェースに IP アドレスを追加/削除する:

`sudo ip {{[a|address]}} {{add|delete}} {{ip_address}}/{{mask}} dev {{インターフェース}}`

- デフォルトルートを追加する:

`sudo ip {{[r|route]}} {{[a|add]}} default via {{ip_address}} dev {{インターフェース}}`
