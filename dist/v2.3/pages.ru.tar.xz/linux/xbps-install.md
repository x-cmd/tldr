# xbps-install

> XBPS утилита по (пере)установке и обновлению пакетов.
> Смотрите также: `xbps`.
> Больше информации: <https://manned.org/xbps-install>.

- Установить новый пакет:

`xbps-install {{пакет}}`

- Синхронизировать и обновить все пакеты:

`xbps-install {{[-Su|--sync --update]}}`
