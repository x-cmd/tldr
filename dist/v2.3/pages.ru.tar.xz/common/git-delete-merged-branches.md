# git delete-merged-branches

> Удалять ветки, которые перечислены в `git branch --merged`, исключая master.
> Часть `git-extras`.
> Больше информации: <https://github.com/tj/git-extras/blob/main/Commands.md#git-delete-merged-branches>.

- Удалить слитые ветки:

`git delete-merged-branches`
