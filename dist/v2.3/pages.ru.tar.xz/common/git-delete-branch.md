# git delete-branch

> Удалять локальные и удалённые ветки Git.
> Часть `git-extras`. При удалении текущей ветки будет удалена только удалённая ветка.
> Больше информации: <https://github.com/tj/git-extras/blob/main/Commands.md#git-delete-branch>.

- Удалить одну или несколько локальных и удалённых веток Git:

`git delete-branch {{имя_ветки1 имя_ветки2 ...}}`
