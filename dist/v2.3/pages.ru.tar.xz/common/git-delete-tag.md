# git delete-tag

> Удалять существующие локальные и удалённые теги.
> Часть `git-extras`.
> Больше информации: <https://github.com/tj/git-extras/blob/main/Commands.md#git-delete-tag>.

- Удалить тег:

`git delete-tag {{версия_тега}}`
