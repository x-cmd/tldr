# fzf

> Komut satırı belirsiz bulucu.
> Sk'ya benzer.
> Daha fazla bilgi için: <https://github.com/junegunn/fzf#usage>.

- Belirtilen dizindeki tüm dosyalarda `fzf`'yi başlat:

`find {{dosya/yolu/dizin}} -type f | fzf`

- Çalışan süreçler için `fzf`'yi başlat:

`ps aux | fzf`

- `<Shift Tab>` ile birden çok dosya seç ve bir dosyaya yaz:

`find {{dosya/yolu/dizin}} -type f | fzf {{[-m|--multi]}} > {{dosya/yolu/dosya}}`

- `fzf`'yi belirli bir sorgu ile başlat:

`fzf {{[-q|--query]}} "{{sorgu}}"`

- `core` ile başlayan ve `go`, `rb` veya `py` ile biten girişlerde `fzf`'yi başlat:

`fzf {{[-q|--query]}} "^core go$ | rb$ | py$"`

- PYC ile eşleşmeyen ve Travis'e tam olarak eşleşen girişlerde `fzf`'yi başlat:

`fzf {{[-q|--query]}} '!pyc travis'`
