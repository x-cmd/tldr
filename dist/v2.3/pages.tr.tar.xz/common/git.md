# git

> Dağıtım sürüö kontrol sistemi.
> Daha fazla bilgi için: <https://git-scm.com/docs/git>.

- Bit Git alt komutunu çalıştır:

`git {{alt_komut}}`

- Bit Git alt komutunu belirtilen depoda çalıştır:

`git -C {{örnek/depo}} {{alt_komut}}`

- Bir Git alt komutunu belirtilen biçimlendirmeye uygun olarak çalıştır:

`git -c '{{config.key}}={{değer}}' {{alt_komut}}`

- Genel yardım sayfasını görüntüle:

`git --help`

- Bir Git alt komutu (`commit`, `log` gibi) için yardım sayfasını görüntüle:

`git help {{alt_komut}}`

- Git sürümünü kontrol et:

`git --version`
