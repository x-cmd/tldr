# go mod

> Modül yönetimi.
> Daha fazla bilgi için: <https://pkg.go.dev/cmd/go#hdr-Module_maintenance>.

- Mevcut dizinde yeni modül başlat:

`go mod init {{modül_ismi}}`

- Modülleri yerel önbelleğe yükle:

`go mod download`

- Kaybolan modülleri ekle ve kullanılmayanları sil:

`go mod tidy`

- Bağlılıkların beklenen içeriğe sahip olduklarını doğrula:

`go mod verify`

- Tüm bağlılıkların kaynaklarını satıcı dizine kopyala:

`go mod vendor`
