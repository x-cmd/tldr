# jco

> Bu komut `autojump` için bir takma addır.

- Asıl komutun dokümantasyonunu görüntüleyin:

`tldr autojump`
