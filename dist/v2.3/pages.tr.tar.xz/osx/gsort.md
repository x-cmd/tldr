# gsort

> Bu komut `sort` için bir takma addır.

- Asıl komutun dokümantasyonunu görüntüleyin:

`tldr sort`
