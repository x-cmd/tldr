# genv

> Bu komut `env` için bir takma addır.

- Asıl komutun dokümantasyonunu görüntüleyin:

`tldr env`
