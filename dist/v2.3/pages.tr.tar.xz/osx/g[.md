# g[

> Bu komut `[` için bir takma addır.

- Asıl komutun dokümantasyonunu görüntüleyin:

`tldr [`
