# gcp

> Bu komut `cp` için bir takma addır.

- Asıl komutun dokümantasyonunu görüntüleyin:

`tldr cp`
