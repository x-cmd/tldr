# a2disconf

> Debian tabanlı işletim sistemlerinde Apache konfigürasyon dosyasını devre dışı bırak.
> Daha fazla bilgi için: <https://manned.org/a2disconf>.

- Bir konfigürasyon dosyasını devre dışı bırak:

`sudo a2disconf {{konfigürasyon_dosyası}}`

- Bilgilendirici mesajı gösterme:

`sudo a2disconf {{[-q|--quiet]}} {{konfigürasyon_dosyası}}`
