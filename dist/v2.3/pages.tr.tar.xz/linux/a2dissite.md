# a2dissite

> Debian tabanlı işletim sistemlerinde bir Apache sanal hostunu devre dışı bırak.
> Daha fazla bilgi için: <https://manned.org/a2dissite>.

- Uzak hostu devre dışı bırak:

`sudo a2dissite {{sanal_host}}`

- Bilgilendirici mesajları gösterme:

`sudo a2dissite {{[-q|--quiet]}} {{sanal_host}}`
