# cowsay

> Genera un personaggio ASCII (di default una mucca) che dice o pensa qualcosa.
> Maggiori informazioni: <https://manned.org/cowsay>.

- Stampa una mucca ASCII che dice "Hello world":

`cowsay "Hello world"`

- Usa il testo da `stdin` per il fumetto:

`echo "Ciao" | cowsay`

- Elenca tutti i personaggi disponibili:

`cowsay -l`

- Stampa un drago ASCII che dice "Ciao":

`cowsay -f dragon "Ciao"`

- Stampa una mucca ASCII sballata che pensa:

`cowthink -s "Sono solo una mucca, non un grande pensatore..."`
