# agate

> Un semplice server per il protocollo di rete Gemini.
> Maggiori informazioni: <https://github.com/mbrubeck/agate>.

- Esegui e genera una chiave privata e un certificato:

`agate --content {{percorso/del/contenuto}}/ --addr {{[::]:1965}} --addr {{0.0.0.0:1965}} --hostname {{example.com}} --lang {{it-IT}}`

- Avvia server:

`agate {{percorso/del/file}}`

- Mostra l'aiuto:

`agate {{[-h|--help]}}`
