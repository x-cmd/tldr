# git rm

> Cancella file dall'indice del repository e dal filesystem locale.
> Maggiori informazioni: <https://git-scm.com/docs/git-rm>.

- Cancella un file dall'indice del repository e dal filesystem:

`git rm {{percorso/del/file}}`

- Cancella una directory:

`git rm -r {{percorso/della/directory}}`

- Cancella un file dall'indice del repository ma non dal filesystem locale:

`git rm --cached {{percorso/del/file}}`
