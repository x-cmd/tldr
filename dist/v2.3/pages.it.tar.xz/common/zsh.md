# zsh

> Z SHell.
> Inteprete da linea di comando compatibile con `bash` e `sh`.
> Vedi anche: `bash`, `!`, `^`.
> Maggiori informazioni: <https://zsh.sourceforge.io/Doc/Release/Invocation.html#Invocation>.

- Fai partire l'interprete interattivo da linea di comando:

`zsh`

- Esegui un comando passandolo come parametro:

`zsh -c {{comando}}`

- Esegui comandi da un file (script):

`zsh {{file}}`

- Esegui comandi da un file e stampali a schermo mentre vengono eseguiti:

`zsh -x {{file}}`
