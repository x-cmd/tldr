# id3tag

> Strumento per leggere, scrivere, e manipolare i tag (etichette) ID3v1 e ID3v2 di file MP3.
> Maggiori informazioni: <https://manned.org/id3tag>.

- Imposta l'etichetta dell'artista e del titolo in un file MP3:

`id3tag --artist {{artista}} --song {{titolo}} {{percorso/del/file.mp3}}`

- Imposta il titolo dell'album di tutti i file MP3 nella directory corrente:

`id3tag --album {{album}} {{*.mp3}}`

- Mostra l'aiuto:

`id3tag --help`
