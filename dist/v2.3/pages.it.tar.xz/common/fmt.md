# fmt

> Riformatta i paragrafi di un file di testo unendoli e limitando la larghezza delle righe a un dato numero di caratteri (di default 75).
> Maggiori informazioni: <https://www.gnu.org/software/coreutils/manual/html_node/fmt-invocation.html>.

- Riformatta un file:

`fmt {{percorso/del/file}}`

- Riformatta un file producendo linee di (al massimo) `n` caratteri:

`fmt {{[-w|--width]}} {{n}} {{percorso/del/file}}`

- Riformatta un file senza unire assieme le linee più corte della data larghezza:

`fmt {{[-s|--split-only]}} {{percorso/del/file}}`

- Riformatta un file usando una spaziatura uniforme (1 spazio tra due parole e 2 spazi tra due paragrafi):

`fmt {{[-u|--uniform-spacing]}} {{percorso/del/file}}`
