# brew rm

> Questo comando è un alias per `brew uninstall`.

- Consulta la documentazione del comando originale:

`tldr brew uninstall`
