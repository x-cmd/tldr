# axel

> Downloader accelerato.
> Supporta HTTP, HTTPS e FTP.
> Vedi anche: `aria2c`.
> Maggiori informazioni: <https://manned.org/axel>.

- Scarica un file da un URL:

`axel {{url}}`

- Scarica specificando il nome del file da creare:

`axel {{url}} {{[-o|--output]}} {{filename}}`

- Scarica sfruttando connessioni multiple:

`axel {{[-n|--num-connections]}} {{numero_connessioni}} {{url}}`

- Cerca dei mirror:

`axel {{[-S|--search=]}}{{numero_mirror}} {{url}}`

- Limita la velocità di download (in bytes al secondo):

`axel {{[-s|--max-speed]}} {{limite_velocità}} {{url}}`
