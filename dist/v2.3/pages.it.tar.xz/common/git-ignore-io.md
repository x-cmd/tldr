# git ignore-io

> Genera file `.gitignore` usando template predefiniti.
> Parte di `git-extras`.
> Maggiori informazioni: <https://github.com/tj/git-extras/blob/main/Commands.md#git-ignore-io>.

- Elenca i template disponibili:

`git ignore-io list`

- Genera un template `.gitignore`:

`git ignore-io {{elemento_a,elemento_b,elemento_n}}`
