# opera

> Questo comando è un alias per `chromium`.
> Maggiori informazioni: <https://www.opera.com/>.

- Visualizza la documentazione per il comando originale:

`tldr chromium`
