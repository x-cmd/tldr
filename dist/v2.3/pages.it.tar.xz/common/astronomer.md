# astronomer

> Strumento per individuare star illegittime da account bot su progetti GitHub.
> Maggiori informazioni: <https://github.com/Ullaakut/astronomer#arguments-and-options>.

- Scannerizza una repository:

`astronomer {{tldr-pages/tldr-node-client}}`

- Scannerizza le star di una repository fino ad un massimo di 50:

`astronomer {{tldr-pages/tldr-node-client}} {{[-s|--stars]}} {{50}}`

- Scannerizza una repository includendo report comparativi:

`astronomer {{tldr-pages/tldr-node-client}} {{[-v|--verbose]}}`
