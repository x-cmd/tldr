# couchdb

> Interfaccia da linea di comando per il server di database Apache CouchDB.
> Maggiori informazioni: <https://manned.org/couchdb>.

- Avvia couchdb:

`couchdb`

- Avvia una shell couchdb interattiva:

`couchdb -i`

- Avvia couchdb come processo in background:

`couchdb -b`

- Termina il processo in background (nota: si riavvierà da solo se necessario):

`couchdb -k`

- Disattiva il processo in background:

`couchdb -d`
