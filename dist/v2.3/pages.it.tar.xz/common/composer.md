# composer

> Un gestore di dipendenze a pacchetti per progetti PHP.
> Maggiori informazioni: <https://getcomposer.org/doc/03-cli.md>.

- Aggiungi un pacchetto come dipendenza per questo progetto, aggiungendolo a `composer.json`:

`composer require {{user/nome_pacchetto}}`

- Installa tutte le dipendenze listate nel `composer.json` di questo progetto:

`composer install`

- Disinstalla un pacchetto da questo progetto, rimuovendolo come dipendenza da `composer.json`:

`composer remove {{user/nome_pacchetto}}`

- Aaggiorna tutte le dipendenze nel `composer.json` di questo progetto:

`composer update`

- Aggiorna composer alla versione più recente:

`composer self-update`
