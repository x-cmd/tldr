# docker container cp

> Copia file o directory tra il filesystem di un container e quello locale (host).
> Maggiori informazioni: <https://docs.docker.com/reference/cli/docker/container/cp/>.

- Copia un file o una directory dall'host a un container:

`docker {{[cp|container cp]}} {{percorso/del/file_o_directory_su_host}} {{nome_container}}:{{percorso/del/file_o_directory_su_container}}`

- Copia un file o una directory da un container all'host:

`docker {{[cp|container cp]}} {{nome_container}}:{{percorso/del/file_o_directory_su_container}} {{percorso/del/file_o_directory_su_host}}`

- Copia un file o una directory dall'host a un container, seguendo un link simbolico (non copiare il link simbolico, ma direttamente il file da lui referenziato):

`docker {{[cp|container cp]}} {{[-L|--follow-link]}} {{percorso/del/link_simbolico_su_host}} {{nome_container}}:{{percorso/del/file_o_directory_su_container}}`
