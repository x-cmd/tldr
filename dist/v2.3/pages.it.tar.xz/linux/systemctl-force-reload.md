# systemctl force-reload

> Questo comando è un alias per `systemctl try-reload-or-restart`.

- Consulta la documentazione del comando originale:

`tldr systemctl try-reload-or-restart`
