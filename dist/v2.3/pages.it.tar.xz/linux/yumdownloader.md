# yumdownloader

> Download storici pacchetti YUM per installazioni Fedora; ora deprecato.
> Questo comando è un alias per `dnf download`.

- Visualizza la documentazione per il comando originale:

`tldr dnf download`
