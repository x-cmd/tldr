# radeontop

> Mostra Utilizzo di AMD GPUs.
> Vedi anche: `nvtop`, `amdgpu_top`.
> Maggiori informazioni: <https://github.com/clbr/radeontop/blob/master/radeontop.asc>.

- Mostra utilizzo del AMD GPU principale:

`radeontop`

- Inizia output con colore:

`radeontop {{[-c|--color]}}`

- Scegli un GPU specifico (il numero del bus è il primo numero nell'output di `lspci`):

`radeontop {{[-b|--bus]}} {{bus_numero}}`

- Specifica la frequenza di aggiornamento del display (più alto aggiunge più sovraccarico al GPU):

`radeontop {{[-t|--ticks]}} {{aggiornamenti_per_secondo}}`
