# bleachbit

> ഈ കമാൻഡ് `bleachbit_console` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr bleachbit_console`
