# SaRAcmd ExpertExperienceAdminTask

> ഈ കമാൻഡ് `GetHelpCmd.exe -S ExpertExperienceAdminTask` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr gethelpcmd-expertexperienceadmintask`
