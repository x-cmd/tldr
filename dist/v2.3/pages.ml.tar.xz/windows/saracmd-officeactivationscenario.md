# SaRAcmd OfficeActivationScenario

> ഈ കമാൻഡ് `GetHelpCmd.exe -S OfficeActivationScenario` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr gethelpcmd-officeactivationscenario`
