# SaRAcmd OutlookCalendarCheckTask

> ഈ കമാൻഡ് `GetHelpCmd.exe -S OutlookCalendarCheckTask` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr gethelpcmd-outlookcalendarchecktask`
