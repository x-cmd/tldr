# pwsh where

> ഈ കമാൻഡ് `Where-Object` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr Where-Object`
