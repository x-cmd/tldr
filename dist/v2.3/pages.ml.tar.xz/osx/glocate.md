# glocate

> ഈ കമാൻഡ് GNU `locate` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr {{[-p|--platform]}} linux locate`
