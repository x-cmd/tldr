# gdnsdomainname

> ഈ കമാൻഡ് GNU `dnsdomainname` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr {{[-p|--platform]}} linux dnsdomainname`
