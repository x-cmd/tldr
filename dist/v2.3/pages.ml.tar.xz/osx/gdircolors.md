# gdircolors

> ഈ കമാൻഡ് GNU `dircolors` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr dircolors`
