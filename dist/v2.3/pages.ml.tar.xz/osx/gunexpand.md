# gunexpand

> ഈ കമാൻഡ് GNU `unexpand` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr unexpand`
