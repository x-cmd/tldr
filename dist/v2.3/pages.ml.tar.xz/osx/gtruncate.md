# gtruncate

> ഈ കമാൻഡ് GNU `truncate` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr truncate`
