# gtraceroute

> ഈ കമാൻഡ് GNU `traceroute` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr traceroute`
