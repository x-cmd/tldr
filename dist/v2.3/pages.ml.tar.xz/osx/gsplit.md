# gsplit

> ഈ കമാൻഡ് GNU `split` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr {{[-p|--platform]}} common split`
