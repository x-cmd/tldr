# gmknod

> ഈ കമാൻഡ് GNU `mknod` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr {{[-p|--platform]}} linux mknod`
