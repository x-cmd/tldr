# gindent

> ഈ കമാൻഡ് GNU `indent` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr {{[-p|--platform]}} common indent`
