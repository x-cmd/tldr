# gupdatedb

> ഈ കമാൻഡ് GNU `updatedb` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr {{[-p|--platform]}} linux updatedb`
