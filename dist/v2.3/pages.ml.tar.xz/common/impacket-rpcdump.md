# impacket-rpcdump

> ഈ കമാൻഡ് `rpcdump.py` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr rpcdump.py`
