# impacket-GetNPUsers

> ഈ കമാൻഡ് `GetNPUsers.py` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr GetNPUsers.py`
