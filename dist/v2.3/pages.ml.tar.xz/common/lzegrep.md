# lzegrep

> ഈ കമാൻഡ് `xzgrep --extended-regexp` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr xzgrep`
