# bzfgrep

> ഈ കമാൻഡ് `bzgrep --fixed-strings` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr bzgrep`
