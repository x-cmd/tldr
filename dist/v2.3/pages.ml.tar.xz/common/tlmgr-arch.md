# tlmgr arch

> ഈ കമാൻഡ് `tlmgr platform` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr tlmgr platform`
