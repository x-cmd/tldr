# pnmtoplainpnm

> ഈ കമാൻഡ് `pamtopnm -plain` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr pamtopnm`
