# jira sprints

> ഈ കമാൻഡ് `jira sprint` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr jira sprint`
