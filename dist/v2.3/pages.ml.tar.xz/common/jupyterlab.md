# jupyterlab

> ഈ കമാൻഡ് `jupyter lab` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr jupyter lab`
