# jupyterlab

> ഈ കമാൻഡ് `jupyter lab` എന്നത്തിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr jupyter lab`
