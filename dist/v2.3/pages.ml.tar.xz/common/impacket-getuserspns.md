# impacket-GetUserSPNs

> ഈ കമാൻഡ് `GetUserSPNs.py` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr GetUserSPNs.py`
