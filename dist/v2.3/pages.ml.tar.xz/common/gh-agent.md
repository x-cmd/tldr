# gh agent

> ഈ കമാൻഡ് `gh agent-task` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr gh agent-task`
