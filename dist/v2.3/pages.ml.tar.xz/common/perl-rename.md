# perl-rename

> ഈ കമാൻഡ് `rename` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr {{[-p|--platform]}} common rename`
