# impacket-getArch

> ഈ കമാൻഡ് `getArch.py` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr getArch.py`
