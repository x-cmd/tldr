# impacket-rdp_check

> ഈ കമാൻഡ് `rdp_check.py` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr rdp_check.py`
