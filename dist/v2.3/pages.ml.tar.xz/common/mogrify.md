# mogrify

> ഈ കമാൻഡ് `magick mogrify` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr magick mogrify`
