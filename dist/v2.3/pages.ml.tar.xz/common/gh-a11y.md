# gh a11y

> ഈ കമാൻഡ് `gh accessibility` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr gh accessibility`
