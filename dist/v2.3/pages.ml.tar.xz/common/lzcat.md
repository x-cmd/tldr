# lzcat

> ഈ കമാൻഡ് `xz --format lzma --decompress --stdout` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr xz`
