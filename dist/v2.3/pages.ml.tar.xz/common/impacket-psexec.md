# impacket-psexec

> ഈ കമാൻഡ് `psexec.py` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr psexec.py`
