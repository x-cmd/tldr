# rustup install

> ഈ കമാൻഡ് `rustup toolchain install` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr rustup toolchain`
