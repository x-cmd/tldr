# impacket-ticketConverter

> ഈ കമാൻഡ് `ticketConverter.py` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr ticketConverter.py`
