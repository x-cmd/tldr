# bzegrep

> ഈ കമാൻഡ് `bzgrep --extended-regexp` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr bzgrep`
