# fmtutil-user

> ഈ കമാൻഡ് `fmtutil --user` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr fmtutil`
