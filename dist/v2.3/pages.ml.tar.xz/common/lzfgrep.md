# lzfgrep

> ഈ കമാൻഡ് `xzgrep --fixed-strings` എന്നത്തിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr xzgrep`
