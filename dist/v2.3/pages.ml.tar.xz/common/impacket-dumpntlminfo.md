# impacket-DumpNTLMInfo

> ഈ കമാൻഡ് `DumpNTLMInfo.py` എന്നത്തിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr DumpNTLMInfo.py`
