# pulumi stack hist

> ഈ കമാൻഡ് `pulumi stack history` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr pulumi stack history`
