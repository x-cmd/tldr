# impacket-smbclient

> ഈ കമാൻഡ് `smbclient.py` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr smbclient.py`
