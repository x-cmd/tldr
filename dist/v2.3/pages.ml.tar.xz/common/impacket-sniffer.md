# impacket-sniffer

> ഈ കമാൻഡ് `sniffer.py` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr sniffer.py`
