# zstdcat

> ഈ കമാൻഡ് `zstd --decompress --stdout --force` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr zstd`
