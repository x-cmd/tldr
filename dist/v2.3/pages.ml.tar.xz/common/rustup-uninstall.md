# rustup uninstall

> ഈ കമാൻഡ് `rustup toolchain uninstall` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr rustup toolchain`
