# pulumi update

> ഈ കമാൻഡ് `pulumi up` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr pulumi up`
