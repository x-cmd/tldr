# fossil forget

> ഈ കമാൻഡ് `fossil rm` എന്നതിന്റെ അപരനാമമാണ്.
> കൂടുതൽ വിവരങ്ങൾ: <https://fossil-scm.org/home/help/forget>.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr fossil rm`
