# impacket-addcomputer

> ഈ കമാൻഡ് `addcomputer.py` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr addcomputer.py`
