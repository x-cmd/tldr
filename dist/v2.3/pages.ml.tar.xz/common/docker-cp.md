# docker cp

> ഈ കമാൻഡ് `docker container cp` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr docker container cp`
