# gnmic sub

> ഈ കമാൻഡ് `gnmic subscribe` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr gnmic subscribe`
