# impacket-getTGT

> ഈ കമാൻഡ് `getTGT.py` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr getTGT.py`
