# impacket-rpcmap

> ഈ കമാൻഡ് `rpcmap.py` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr rpcmap.py`
