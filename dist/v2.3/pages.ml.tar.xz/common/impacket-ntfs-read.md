# impacket-ntfs-read

> ഈ കമാൻഡ് `ntfs-read.py` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr ntfs-read.py`
