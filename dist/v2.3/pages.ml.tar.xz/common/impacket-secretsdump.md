# impacket-secretsdump

> ഈ കമാൻഡ് `secretsdump.py` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr secretsdump.py`
