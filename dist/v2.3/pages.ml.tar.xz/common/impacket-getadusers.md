# impacket-GetADUsers

> ഈ കമാൻഡ് `GetADUsers.py` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr GetADUsers.py`
