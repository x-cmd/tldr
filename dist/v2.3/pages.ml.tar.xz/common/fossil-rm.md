# fossil rm

> ഈ കമാൻഡ് `fossil delete` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr fossil delete`
