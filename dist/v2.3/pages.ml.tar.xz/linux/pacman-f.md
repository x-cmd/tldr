# pacman -F

> ഈ കമാൻഡ് `pacman --files` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr pacman files`
