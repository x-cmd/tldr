# pacman -U

> ഈ കമാൻഡ് `pacman --upgrade` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr pacman upgrade`
