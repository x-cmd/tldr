# pacman -R

> ഈ കമാൻഡ് `pacman --remove` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr pacman remove`
