# systemd-umount

> ഈ കമാൻഡ് `systemd-mount --umount` എന്നത്തിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr systemd-mount`
