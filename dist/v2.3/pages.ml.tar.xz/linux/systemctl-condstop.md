# systemctl condstop

> ഈ കമാൻഡ് `systemctl stop` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr systemctl stop`
