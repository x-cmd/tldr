# pacinstall

> ഈ കമാൻഡ് `pactrans --install` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr pactrans`
