# ip6tables-restore

> ഈ കമാൻഡ് IPv6 ഫയർവാളിനായുള്ള `iptables-restore` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr iptables-restore`
