# edit

> ഈ കമാൻഡ് `run-mailcap --action=edit` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr run-mailcap`
