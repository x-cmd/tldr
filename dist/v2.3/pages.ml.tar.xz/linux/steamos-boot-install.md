# steamos-boot-install

> ഈ കമാൻഡ് `steamos-finalize-install` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr steamos-finalize-install`
