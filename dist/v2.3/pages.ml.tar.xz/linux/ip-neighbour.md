# ip neighbour

> ഈ കമാൻഡ് `ip neighbor` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr ip neighbor`
