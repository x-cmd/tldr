# systemctl force-reload

> ഈ കമാൻഡ് `systemctl try-reload-or-restart` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr systemctl try-reload-or-restart`
