# pacman -Q

> ഈ കമാൻഡ് `pacman --query` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr pacman query`
