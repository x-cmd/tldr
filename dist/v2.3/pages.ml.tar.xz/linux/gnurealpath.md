# gnurealpath

> ഈ കമാൻഡ് GNU `realpath` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr realpath`
