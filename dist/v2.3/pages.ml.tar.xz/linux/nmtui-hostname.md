# nmtui-hostname

> ഈ കമാൻഡ് `nmtui hostname` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr nmtui`
