# yum config-manager

> ഈ കമാൻഡ് `dnf config-manager` എന്നത്തിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr dnf config-manager`
