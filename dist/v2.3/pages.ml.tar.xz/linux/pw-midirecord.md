# pw-midirecord

> ഈ കമാൻഡ് `pw-cat --record --midi` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr pw-cat`
