# avahi-resolve-host-name

> ഈ കമാൻഡ് `avahi-resolve --name` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr avahi-resolve`
