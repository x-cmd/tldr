# pw-encplay

> ഈ കമാൻഡ് `pw-cat --playback --encoded` എന്നത്തിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr pw-cat`
