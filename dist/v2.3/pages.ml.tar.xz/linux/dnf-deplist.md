# dnf deplist

> ഈ കമാൻഡ് `dnf repoquery --deplist` എന്നതിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr dnf repoquery`
