# apt-add-repository

> ഈ കമാൻഡ് `add-apt-repository` എന്നത്തിന്റെ അപരനാമമാണ്.

- യഥാർത്ഥ കമാൻഡിനായി ഡോക്യുമെന്റേഷൻ കാണുക:

`tldr add-apt-repository`
